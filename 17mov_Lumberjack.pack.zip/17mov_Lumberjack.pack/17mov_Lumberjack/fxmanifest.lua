fx_version "cerulean"
game "gta5"
author "Malizniak - 17Movement"
lua54 "yes"
this_is_a_map 'yes'
version "2.0.75"

dependency "17mov_Lumberjack_assets"

files {
    "web/**/*.**",
    "web/*.**",
}

ui_page "web/index.html"

shared_script "Config.lua"

server_scripts {
    "server/functions.lua",
    "server/server.lua",
}

client_scripts {
    "client/functions.lua",
    "client/target.lua",
    "client/client.lua",
    "client/crane.lua",
}
