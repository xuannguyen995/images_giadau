Cranes = {}

CraneModels = {
    {
        model = 1597396577,
        replace = 915866835,
        attachOffset = vector3(0.0, 0.0, -2.6),
        attachRotation = vector3(0.0, 0.0, 0.0),
        attachDistance = 3.0,
        tempOffset = vector3(0.0, -10.0, 0.45),
        tempRotation = vector3(0.0, 0.0, 0.0),
        trailerPostions = {
            {
                offset = vector3(0.0, -2.5, 0.45),
                rotation = vector3(0.0, 0.0, 0.0)
            },
            {
                offset = vector3(0.0, -6.4, 0.45),
                rotation = vector3(0.0, 0.0, 0.0)
            },
            {
                offset = vector3(0.0, -2.5, 1.515),
                rotation = vector3(0.0, 0.0, 0.0)
            },
            {
                offset = vector3(0.0, -6.4, 1.515),
                rotation = vector3(0.0, 0.0, 0.0)
            }
        }
    },
    {
        model = -1937513394,
        replace = 1242069632,
        attachOffset = vector3(0.0, 0.0, -3.95),
        attachRotation = vector3(0.0, 0.0, 0.0),
        attachDistance = 3.0,
        tempOffset = vector3(0.0, -10.0, 0.42),
        tempRotation = vector3(0.0, 0.0, 0.0),
        trailerPostions = {
            {
                offset = vector3(0.0, -2.5, 0.42),
                rotation = vector3(0.0, 0.0, 0.0)
            },
            {
                offset = vector3(0.0, -6.9, 0.42),
                rotation = vector3(0.0, 0.0, 0.0)
            }
        }
    },
    {
        model = (Config.Props.logs.hash or 1366334172),
        attachOffset = vector3(0.0, 0.0, -1.0),
        attachRotation = vector3(0.0, 0.0, 0.0),
        attachDistance = 1.0,
        tempOffset = vector3(0.0, -10.0, 0.8),
        tempRotation = vector3(0.0, 0.0, 0.0),
        trailerPostions = {
            { offset = vector3(-0.9, -2.5, 0.7),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -2.5, 0.7),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -2.5, 0.7),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -2.5, 0.7),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -2.5, 1.25), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -2.5, 1.25), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -2.5, 1.25),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -2.5, 1.25),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -2.5, 1.8),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -2.5, 1.8),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -2.5, 1.8),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -2.5, 1.8),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -2.5, 2.35), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -2.5, 2.35), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -2.5, 2.35),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -2.5, 2.35),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -6.7, 0.7),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -6.7, 0.7),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -6.7, 0.7),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -6.7, 0.7),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -6.7, 1.25), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -6.7, 1.25), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -6.7, 1.25),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -6.7, 1.25),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -6.7, 1.8),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -6.7, 1.8),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -6.7, 1.8),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -6.7, 1.8),   rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.9, -6.7, 2.35), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(-0.3, -6.7, 2.35), rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.3, -6.7, 2.35),  rotation = vector3(0.0, 0.0, 0.0) },
            { offset = vector3(0.9, -6.7, 2.35),  rotation = vector3(0.0, 0.0, 0.0) }
        }
    }
}

local CRANE_CONTROL_PANEL_MODEL = -1436027651
local CRANE_BASE_MODEL = 91512090
local CRANE_BOOM_MODEL = -844957414
local CRANE_STICK1_MODEL = -203303706
local CRANE_STICK2_MODEL = 103545210
local CRANE_STICK3_MODEL = 1135801411
local CRANE_HOOK_MODEL = -1277810458
local CRANE_GRAB1_MODEL = 2069585976
local CRANE_GRAB2_MODEL = 687258484

local function IsModelAttachedToVehicle(vehicle, modelHash)
    for _, object in ipairs(GetGamePool("CObject")) do
        if IsEntityAttachedToEntity(object, vehicle) then
            if GetEntityModel(object) == modelHash then
                return true
            end
        end
    end
    return false
end

local function CreateCrane(vehicle, vehicleNetId, craneId)
    local craneData = {}
    craneData.id = craneId
    craneData.objects = {}
    craneData.onceControls = {}
    craneData.onceControlsTimers = {}
    craneData.attachedToHook = false
    craneData.CreatedAt = GetGameTimer()
    craneData.controling = false
    craneData.HeightSpeed = 20.0
    craneData.RotateSpeed = 32.0
    craneData.StickLengthSpeed = 2.4
    craneData.RotateHookSpeed = 160.0
    craneData.HookGripSpeed = 24.0
    craneData.Dict = "17mov@radioanim"
    craneData.Anim = "17mov_radioanim"
    craneData.LoadedObjects = {}
    craneData.ExtraObjects = {}
    craneData.Models = CraneModels


    if not CraneControls then
        CraneControls = {
            LeftMouseButton = 24,
            INPUT_MOVE_LR = 30,
            INPUT_MOVE_UD = 31,
            W = 32,
            S = 33,
            A = 34,
            D = 35,
            E = 38,
            Q = 44,
            ArrowDown = 187,
            ArrowUp = 188,
            ArrowLeft = 189,
            ArrowRight = 190,
            ESC = 200,
            INPUT_VEH_MOVE_LR = 59,
            INPUT_VEH_MOVE_LEFT_ONLY = 63,
            INPUT_VEH_MOVE_RIGHT_ONLY = 64,
            INPUT_VEH_ACCELERATE = 71,
            INPUT_VEH_BRAKE = 72,
            INPUT_VEH_NEXT_RADIO = 85,
        }
    end
    craneData.Controls = CraneControls

    local vehicleDeadline = GetGameTimer() + 10000
    while not DoesEntityExist(vehicle) and GetGameTimer() < vehicleDeadline do Wait(50) end
    if not DoesEntityExist(vehicle) then return nil end

    local requiredModels = {
        CRANE_CONTROL_PANEL_MODEL,
        CRANE_BASE_MODEL,
        CRANE_BOOM_MODEL,
        CRANE_STICK1_MODEL,
        CRANE_STICK2_MODEL,
        CRANE_STICK3_MODEL,
        CRANE_HOOK_MODEL,
        CRANE_GRAB1_MODEL,
        CRANE_GRAB2_MODEL,
    }
    for _, modelHash in ipairs(requiredModels) do
        if not LoadModelWithTimeout(modelHash) then return nil end
    end

    craneData.vehicle = vehicle
    craneData.vehicleNetId = vehicleNetId
    table.insert(craneData.objects, craneData.vehicle)

    craneData.coords = GetEntityCoords(vehicle)

    craneData.controlOffset = vector3(-1.35, 0.3, 0.4)
    craneData.controlOffsetToPed = vector3(0.16, 0.05, -0.11)
    craneData.controlRotation = vector3(0.0, 90.0, 270.0)
    craneData.controlRotationToPed = vector3(-5.0, 40.0, -140.0)

    craneData.baseOffset = vector3(0.0, 0.5, 0.4)
    craneData.baseRotation = vector3(0.0, 0.0, 177.0)
    craneData.baseRotationDefault = craneData.baseRotation

    craneData.stick1Offset = vector3(0.0, 0.0, 3.5)
    craneData.stick1Rotation = vector3(16.5, 0.0, 180.0)
    craneData.stick1RotationDefault = craneData.stick1Rotation
    craneData.stick1RotationUnfolded = vector3(0.0, 0.0, 180.0)
    craneData.stick1MinRotation = -15.0
    craneData.stick1MaxRotation = 30.0

    craneData.stick2Offset = vector3(0.5, -7.68, 0.42)
    craneData.stick2Rotation = vector3(0.0, 0.0, 180.0)

    craneData.stick3Offset = vector3(0.0, 2.64, -0.09)
    craneData.stick3OffsetDefault = craneData.stick3Offset
    craneData.stick3MinOffset = 2.64
    craneData.stick3MaxOffset = 6.6

    craneData.hookOffset = vector3(0.0, 0.0, -0.4)
    craneData.hookAttachOffset = vector3(0.0, 0.0, -2.0)
    craneData.hookRotation = vector3(0.0, 0.0, 0.0)
    craneData.hookRotationDefault = craneData.hookRotation

    craneData.grabOffset = vector3(0.35, 0.0, -0.25)
    craneData.grabRotation = vector3(0.0, 0.0, 0.0)
    craneData.grabRotationDefault = craneData.grabRotation
    craneData.grabMinRotation = 0
    craneData.grabMaxRotation = 40.0

    if not DoesEntityExist(craneData.control) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_CONTROL_PANEL_MODEL) then
            if not LoadModelWithTimeout(CRANE_CONTROL_PANEL_MODEL) then return end
            craneData.control = CreateObject(CRANE_CONTROL_PANEL_MODEL, craneData.coords.x, craneData.coords.y,
                craneData.coords.z, false, true, false)
            AttachEntityToEntity(craneData.control, craneData.vehicle, 0,
                craneData.controlOffset.x, craneData.controlOffset.y, craneData.controlOffset.z,
                craneData.controlRotation.x, craneData.controlRotation.y, craneData.controlRotation.z,
                false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.control)
        end
    end

    if not DoesEntityExist(craneData.base) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_BASE_MODEL) then
            if not LoadModelWithTimeout(CRANE_BASE_MODEL) then return end
            craneData.base = CreateObject(CRANE_BASE_MODEL, craneData.coords.x, craneData.coords.y, craneData.coords.z,
                false, true, false)
            AttachEntityToEntity(craneData.base, craneData.vehicle, 0,
                craneData.baseOffset.x, craneData.baseOffset.y, craneData.baseOffset.z,
                craneData.baseRotation.x, craneData.baseRotation.y, craneData.baseRotation.z,
                false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.base)
        end
    end

    if not DoesEntityExist(craneData.boom) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_BOOM_MODEL) then
            if not LoadModelWithTimeout(CRANE_BOOM_MODEL) then return end
            craneData.boom = CreateObject(CRANE_BOOM_MODEL, craneData.coords.x, craneData.coords.y, craneData.coords.z,
                false, true, false)
            AttachEntityToEntity(craneData.boom, craneData.base, 0, 0, 0, 0, 0, 0, 0, false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.boom)
        end
    end

    if not DoesEntityExist(craneData.stick1) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_STICK1_MODEL) then
            if not LoadModelWithTimeout(CRANE_STICK1_MODEL) then return end
            craneData.stick1 = CreateObject(CRANE_STICK1_MODEL, craneData.coords.x + 2.0, craneData.coords.y + 2.0,
                craneData.coords.z, false, true, false)
            AttachEntityToEntity(craneData.stick1, craneData.base, 0,
                craneData.stick1Offset.x, craneData.stick1Offset.y, craneData.stick1Offset.z,
                craneData.stick1Rotation.x, craneData.stick1Rotation.y, craneData.stick1Rotation.z,
                false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.stick1)
        end
    end

    if not DoesEntityExist(craneData.stick2) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_STICK2_MODEL) then
            if not LoadModelWithTimeout(CRANE_STICK2_MODEL) then return end
            craneData.stick2 = CreateObject(CRANE_STICK2_MODEL, craneData.coords.x, craneData.coords.y,
                craneData.coords.z, false, true, false)
            AttachEntityToEntity(craneData.stick2, craneData.stick1, 0,
                craneData.stick2Offset.x, craneData.stick2Offset.y, craneData.stick2Offset.z,
                craneData.stick2Rotation.x, craneData.stick2Rotation.y, craneData.stick2Rotation.z,
                false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.stick2)
        end
    end

    if not DoesEntityExist(craneData.stick3) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_STICK3_MODEL) then
            if not LoadModelWithTimeout(CRANE_STICK3_MODEL) then return end
            craneData.stick3 = CreateObject(CRANE_STICK3_MODEL, craneData.coords.x, craneData.coords.y,
                craneData.coords.z, false, true, false)
            AttachEntityToEntity(craneData.stick3, craneData.stick2, 0,
                craneData.stick3Offset.x, craneData.stick3Offset.y, craneData.stick3Offset.z,
                0, 0, 0, false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.stick3)
        end
    end

    if not DoesEntityExist(craneData.hook) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_HOOK_MODEL) then
            if not LoadModelWithTimeout(CRANE_HOOK_MODEL) then return end
            craneData.hook = CreateObject(CRANE_HOOK_MODEL, craneData.coords.x, craneData.coords.y, craneData.coords.z,
                false, true, false)
            AttachEntityToEntity(craneData.hook, craneData.stick3, 0,
                craneData.hookOffset.x, craneData.hookOffset.y, craneData.hookOffset.z,
                craneData.hookRotation.x, craneData.hookRotation.y, craneData.hookRotation.z,
                false, true, true, false, 2, false)
            table.insert(craneData.objects, craneData.hook)
        end
    end

    if not DoesEntityExist(craneData.grab1) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_GRAB1_MODEL) then
            if not LoadModelWithTimeout(CRANE_GRAB1_MODEL) then return end
            craneData.grab1 = CreateObject(CRANE_GRAB1_MODEL, craneData.coords.x, craneData.coords.y, craneData.coords.z,
                false, true, false)
            AttachEntityToEntity(craneData.grab1, craneData.hook, 0,
                craneData.grabOffset.x, craneData.grabOffset.y, craneData.grabOffset.z,
                craneData.grabRotation.x, craneData.grabRotation.y, craneData.grabRotation.z,
                false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.grab1)
        end
    end

    if not DoesEntityExist(craneData.grab2) then
        if not IsModelAttachedToVehicle(craneData.vehicle, CRANE_GRAB2_MODEL) then
            if not LoadModelWithTimeout(CRANE_GRAB2_MODEL) then return end
            craneData.grab2 = CreateObject(CRANE_GRAB2_MODEL, craneData.coords.x, craneData.coords.y, craneData.coords.z,
                false, true, false)
            AttachEntityToEntity(craneData.grab2, craneData.hook, 0,
                craneData.grabOffset.x * -1, craneData.grabOffset.y, craneData.grabOffset.z,
                craneData.grabRotation.x, craneData.grabRotation.y * -1, craneData.grabRotation.z,
                false, true, false, false, 2, true)
            table.insert(craneData.objects, craneData.grab2)
        end
    end

    craneData.MoveVectorTowards = function(from, to, maxDistance)
        local dx = to.x - from.x
        local dy = to.y - from.y
        local dz = to.z - from.z
        local distance = math.sqrt(dx * dx + dy * dy + dz * dz)
        if maxDistance > distance then
            return vector3(to.x, to.y, to.z)
        end
        local nx = dx / distance
        local ny = dy / distance
        local nz = dz / distance
        return vector3(from.x + nx * maxDistance, from.y + ny * maxDistance, from.z + nz * maxDistance)
    end

    craneData.Action = function(actionName, ...)
        if craneData[actionName] then
            craneData[actionName](...)
        end
    end

    craneData.Fold = function()
        while true do
            if not Cranes[craneId] then
                break
            end
            if not Cranes[craneId].crane then
                break
            end
            local crane = Cranes[craneId].crane

            crane.baseRotation = crane.MoveVectorTowards(crane.baseRotation, crane.baseRotationDefault,
                crane.RotateSpeed * GetFrameTime())
            AttachEntityToEntity(crane.base, crane.vehicle, 0,
                crane.baseOffset.x, crane.baseOffset.y, crane.baseOffset.z,
                crane.baseRotation.x, crane.baseRotation.y, crane.baseRotation.z,
                false, true, false, false, 2, true)

            crane.hookRotation = crane.MoveVectorTowards(crane.hookRotation, crane.hookRotationDefault,
                crane.RotateHookSpeed * GetFrameTime())
            AttachEntityToEntity(crane.hook, crane.stick3, 0,
                crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
                crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
                false, true, true, false, 2, false)

            crane.stick1Rotation = crane.MoveVectorTowards(crane.stick1Rotation, crane.stick1RotationDefault,
                crane.HeightSpeed * GetFrameTime())
            AttachEntityToEntity(crane.stick1, crane.boom, 0,
                crane.stick1Offset.x, crane.stick1Offset.y, crane.stick1Offset.z,
                crane.stick1Rotation.x, crane.stick1Rotation.y, crane.stick1Rotation.z,
                false, true, false, false, 2, true)

            crane.stick3Offset = crane.MoveVectorTowards(crane.stick3Offset, crane.stick3OffsetDefault,
                crane.StickLengthSpeed * GetFrameTime())
            AttachEntityToEntity(crane.stick3, crane.stick2, 0,
                crane.stick3Offset.x, crane.stick3Offset.y, crane.stick3Offset.z,
                0, 0, 0, false, true, false, false, 2, true)

            crane.grabRotation = crane.MoveVectorTowards(crane.grabRotation, crane.grabRotationDefault,
                crane.HookGripSpeed * GetFrameTime())
            AttachEntityToEntity(crane.grab1, crane.hook, 0,
                crane.grabOffset.x, crane.grabOffset.y, crane.grabOffset.z,
                crane.grabRotation.x, crane.grabRotation.y, crane.grabRotation.z,
                false, true, false, false, 2, true)
            AttachEntityToEntity(crane.grab2, crane.hook, 0,
                crane.grabOffset.x * -1, crane.grabOffset.y, crane.grabOffset.z,
                crane.grabRotation.x, crane.grabRotation.y * -1, crane.grabRotation.z,
                false, true, false, false, 2, true)

            if crane.baseRotation == crane.baseRotationDefault
                and crane.hookRotation == crane.hookRotationDefault
                and crane.stick1Rotation == crane.stick1RotationDefault
                and crane.stick3Offset == crane.stick3OffsetDefault
                and crane.grabRotation == crane.grabRotationDefault
            then
                break
            end

            Wait(0)
        end
    end

    craneData.Unfold = function()
        while true do
            if not Cranes[craneId] then
                break
            end
            if not Cranes[craneId].crane then
                break
            end
            local crane = Cranes[craneId].crane

            crane.stick1Rotation = crane.MoveVectorTowards(crane.stick1Rotation, crane.stick1RotationUnfolded,
                crane.HeightSpeed * GetFrameTime())
            AttachEntityToEntity(crane.stick1, crane.boom, 0,
                crane.stick1Offset.x, crane.stick1Offset.y, crane.stick1Offset.z,
                crane.stick1Rotation.x, crane.stick1Rotation.y, crane.stick1Rotation.z,
                false, true, false, false, 2, true)

            if crane.stick1Rotation == crane.stick1RotationUnfolded then
                break
            end

            Wait(0)
        end
    end

    craneData.Rotate = function(direction)
        if type(direction) ~= "number" then
            return
        end
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        local frameTime = GetFrameTime()

        crane.baseRotation = vector3(crane.baseRotation.x, crane.baseRotation.y,
            (crane.baseRotation.z + direction * frameTime) % 360)
        AttachEntityToEntity(crane.base, crane.vehicle, 0,
            crane.baseOffset.x, crane.baseOffset.y, crane.baseOffset.z,
            crane.baseRotation.x, crane.baseRotation.y, crane.baseRotation.z,
            false, true, false, false, 2, true)

        crane.hookRotation = vector3(crane.hookRotation.x, crane.hookRotation.y,
            (crane.hookRotation.z + direction * frameTime) % 360)
        AttachEntityToEntity(crane.hook, crane.stick3, 0,
            crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
            crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
            false, true, true, false, 2, false)
    end

    craneData.SetRotate = function(baseRotation, hookRotation)
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        crane.baseRotation = baseRotation
        AttachEntityToEntity(crane.base, crane.vehicle, 0,
            crane.baseOffset.x, crane.baseOffset.y, crane.baseOffset.z,
            crane.baseRotation.x, crane.baseRotation.y, crane.baseRotation.z,
            false, true, false, false, 2, true)

        crane.hookRotation = hookRotation
        AttachEntityToEntity(crane.hook, crane.stick3, 0,
            crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
            crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
            false, true, true, false, 2, false)
    end

    craneData.AdjustHeight = function(delta)
        if type(delta) ~= "number" then
            return
        end
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        local newAngle = crane.stick1Rotation.x + delta * GetFrameTime() * 1.0
        if newAngle < crane.stick1MaxRotation and newAngle > crane.stick1MinRotation then
            crane.stick1Rotation = vector3(newAngle, crane.stick1Rotation.y, crane.stick1Rotation.z)
            AttachEntityToEntity(crane.stick1, crane.boom, 0,
                crane.stick1Offset.x, crane.stick1Offset.y, crane.stick1Offset.z,
                crane.stick1Rotation.x, crane.stick1Rotation.y, crane.stick1Rotation.z,
                false, true, false, false, 2, true)
        end
    end

    craneData.SetHeight = function(rotation)
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        crane.stick1Rotation = rotation
        AttachEntityToEntity(crane.stick1, crane.boom, 0,
            crane.stick1Offset.x, crane.stick1Offset.y, crane.stick1Offset.z,
            crane.stick1Rotation.x, crane.stick1Rotation.y, crane.stick1Rotation.z,
            false, true, false, false, 2, true)
    end

    craneData.ControlStickLength = function(delta)
        if type(delta) ~= "number" then
            return
        end
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        local newOffset = crane.stick3Offset.y + delta * GetFrameTime()
        if newOffset < crane.stick3MaxOffset and newOffset > crane.stick3MinOffset then
            crane.stick3Offset = vector3(crane.stick3Offset.x, newOffset, crane.stick3Offset.z)
            AttachEntityToEntity(crane.stick3, crane.stick2, 0,
                crane.stick3Offset.x, crane.stick3Offset.y, crane.stick3Offset.z,
                0, 0, 0, false, true, false, false, 2, true)
        end
    end

    craneData.SetStickLength = function(offset)
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        crane.stick3Offset = offset
        AttachEntityToEntity(crane.stick3, crane.stick2, 0,
            crane.stick3Offset.x, crane.stick3Offset.y, crane.stick3Offset.z,
            0, 0, 0, false, true, false, false, 2, true)
    end

    craneData.RotateHook = function(direction)
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        crane.hookRotation = vector3(crane.hookRotation.x, crane.hookRotation.y,
            (crane.hookRotation.z + direction * GetFrameTime()) % 360)
        AttachEntityToEntity(crane.hook, crane.stick3, 0,
            crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
            crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
            false, true, true, false, 2, false)
    end

    craneData.SetHookRotation = function(rotation)
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        crane.hookRotation = rotation
        AttachEntityToEntity(crane.hook, crane.stick3, 0,
            crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
            crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
            false, true, true, false, 2, false)
    end

    craneData.ControlHookGrip = function(delta)
        if type(delta) ~= "number" then
            return
        end
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        local newAngle = crane.grabRotation.y + delta * GetFrameTime()
        if newAngle < crane.grabMaxRotation then
            if newAngle > crane.grabMinRotation then

            end
        end
    end

    craneData.SetHookGrip = function(rotation)
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        crane.grabRotation = rotation
    end

    craneData.UpdateCrane = function()
        local nearbyPlayers = {}
        local myCoords = GetEntityCoords(PlayerPedId())

        for _, player in pairs(GetActivePlayers()) do
            local playerCoords = GetEntityCoords(GetPlayerPed(player))
            if #(playerCoords - myCoords) < 200.0 then
                table.insert(nearbyPlayers, GetPlayerServerId(player))
            end
        end

        TriggerServerEvent("17mov_Lumberjack:UpdateCrane", craneData.id,
            Cranes[craneData.id].hasControl,
            Cranes[craneId].crane.baseRotation,
            Cranes[craneId].crane.hookRotation,
            Cranes[craneId].crane.stick1Rotation,
            Cranes[craneId].crane.stick3Offset,
            Cranes[craneId].crane.grabRotation,
            nearbyPlayers)
    end

    craneData.ControllerAnimation = function()
        CreateThread(function()
            while true do
                if craneId == nil then
                    break
                end
                if Cranes[craneId] == nil then
                    break
                end
                if Cranes[craneId].hasControl ~= PedToNet(PlayerPedId()) then
                    break
                end

                local playerPed = PlayerPedId()
                if not IsEntityPlayingAnim(playerPed, Cranes[craneId].crane.Dict, Cranes[craneId].crane.Anim, 3) then
                    if not LoadAnimDictWithTimeout(Cranes[craneId].crane.Dict) then break end
                    TaskPlayAnim(playerPed, Cranes[craneId].crane.Dict, Cranes[craneId].crane.Anim, 3.5, -8, -1, 33, 0,
                        false, false, false)
                end

                SetCurrentPedWeapon(playerPed, -1569615261, true)
                Wait(10)
            end

            ClearPedTasks(PlayerPedId())
        end)
    end

    craneData.Destroy = function()
        if not Cranes[craneId] then
            return
        end
        local crane = Cranes[craneId].crane
        if not crane then
            return
        end

        DeleteEntity(crane.boom)
        DeleteEntity(crane.base)
        DeleteEntity(crane.stick1)
        DeleteEntity(crane.stick2)
        DeleteEntity(crane.stick3)
        DeleteEntity(crane.hook)
        DeleteEntity(crane.grab1)
        DeleteEntity(crane.grab2)
        DeleteEntity(crane.control)

        for _, object in pairs(crane.objects) do
            DeleteEntity(object)
        end

        for _, object in pairs(crane.LoadedObjects) do
            DeleteEntity(object)
        end

        for parentObject, childObjects in pairs(crane.ExtraObjects) do
            DeleteEntity(parentObject)
            for i = 1, #childObjects, 1 do
                DeleteEntity(childObjects[i])
            end
        end

        TriggerServerEvent("17mov_Lumberjack:DeleteCrane", craneId)
    end

    return craneData
end

local function GetNearbyPlayerServerIds()
    local nearby = {}
    local myCoords = GetEntityCoords(PlayerPedId())
    for _, player in pairs(GetActivePlayers()) do
        if #(GetEntityCoords(GetPlayerPed(player)) - myCoords) < 200.0 then
            table.insert(nearby, GetPlayerServerId(player))
        end
    end
    return nearby
end

CreateThread(function()
    Wait(5000)
    TriggerServerEvent("17mov_Lumberjack:RequestCranes")

    local hookIsStowed = false

    local function HandleHoldControl(crane, craneId, controlId, actionName, param, now)
        if IsDisabledControlPressed(0, controlId) then
            if not crane.onceControls[controlId] then
                local nearby = GetNearbyPlayerServerIds()
                TriggerServerEvent("17mov_Lumberjack:StartCraneAction", craneId, actionName, nearby, param)
                crane.onceControls[controlId] = true
            end
            crane[actionName](param)
            crane.onceControlsTimers[controlId] = now
        else
            if crane.onceControls[controlId] then
                if now - crane.onceControlsTimers[controlId] > 100 then
                    crane.UpdateCrane()
                    TriggerServerEvent("17mov_Lumberjack:StopCraneAction", craneId, actionName)
                    crane.onceControls[controlId] = nil
                    crane.onceControlsTimers[controlId] = nil
                end
            end
        end
    end

    local function ProcessCraneTick(craneId, craneEntry, myVehicle, myNetId, myCoords)
        if not craneEntry then
            return
        end
        local crane = craneEntry.crane
        if not crane then
            return
        end

        local vehicleEntity = NetToVeh(craneEntry.netId)
        if vehicleEntity ~= 0 then
            if GetEntityModel(vehicleEntity) == -184773924 then
                crane.vehicle = vehicleEntity
            end
        else
            crane.vehicle = 0
        end

        if crane.vehicle == 0 then
            return
        end
        if not DoesEntityExist(crane.vehicle) then
            return
        end

        if #(GetEntityCoords(crane.vehicle) - myCoords) >= 250 then
            DeleteEntity(crane.boom)
            DeleteEntity(crane.base)
            DeleteEntity(crane.stick1)
            DeleteEntity(crane.stick2)
            DeleteEntity(crane.stick3)
            DeleteEntity(crane.hook)
            DeleteEntity(crane.grab1)
            DeleteEntity(crane.grab2)
            DeleteEntity(crane.control)

            for _, object in pairs(crane.objects) do
                if object ~= crane.vehicle then
                    DeleteEntity(object)
                end
            end

            for extraParent, extraChildren in pairs(Cranes[crane.id].crane.ExtraObjects) do
                DeleteEntity(extraParent)
                for i = 1, #extraChildren, 1 do
                    DeleteEntity(extraChildren[i])
                end
                Cranes[crane.id].crane.LoadedObjects[extraParent] = nil
            end

            for loadedKey, loadedObject in pairs(Cranes[crane.id].crane.LoadedObjects) do
                DeleteEntity(loadedObject)
                Cranes[crane.id].crane.LoadedObjects[loadedKey] = nil
            end

            return
        end

        if GetGameTimer() - crane.CreatedAt >= 5000 then
            if not DoesEntityExist(crane.control) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_CONTROL_PANEL_MODEL) then
                    if not LoadModelWithTimeout(CRANE_CONTROL_PANEL_MODEL) then return end
                    crane.control = CreateObject(CRANE_CONTROL_PANEL_MODEL, crane.coords.x, crane.coords.y,
                        crane.coords.z, false, true, false)
                    AttachEntityToEntity(crane.control, crane.vehicle, 0,
                        crane.controlOffset.x, crane.controlOffset.y, crane.controlOffset.z,
                        crane.controlRotation.x, crane.controlRotation.y, crane.controlRotation.z,
                        false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.control)
                end
            end

            if not DoesEntityExist(crane.base) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_BASE_MODEL) then
                    if not LoadModelWithTimeout(CRANE_BASE_MODEL) then return end
                    crane.base = CreateObject(CRANE_BASE_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.base, crane.vehicle, 0,
                        crane.baseOffset.x, crane.baseOffset.y, crane.baseOffset.z,
                        crane.baseRotation.x, crane.baseRotation.y, crane.baseRotation.z,
                        false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.base)
                end
            end

            if not DoesEntityExist(crane.boom) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_BOOM_MODEL) then
                    if not LoadModelWithTimeout(CRANE_BOOM_MODEL) then return end
                    crane.boom = CreateObject(CRANE_BOOM_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.boom, crane.base, 0, 0, 0, 0, 0, 0, 0, false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.boom)
                end
            end

            if not DoesEntityExist(crane.stick1) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_STICK1_MODEL) then
                    if not LoadModelWithTimeout(CRANE_STICK1_MODEL) then return end
                    crane.stick1 = CreateObject(CRANE_STICK1_MODEL, crane.coords.x + 2.0, crane.coords.y + 2.0,
                        crane.coords.z, false, true, false)
                    AttachEntityToEntity(crane.stick1, crane.base, 0,
                        crane.stick1Offset.x, crane.stick1Offset.y, crane.stick1Offset.z,
                        crane.stick1Rotation.x, crane.stick1Rotation.y, crane.stick1Rotation.z,
                        false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.stick1)
                end
            end

            if not DoesEntityExist(crane.stick2) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_STICK2_MODEL) then
                    if not LoadModelWithTimeout(CRANE_STICK2_MODEL) then return end
                    crane.stick2 = CreateObject(CRANE_STICK2_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.stick2, crane.stick1, 0,
                        crane.stick2Offset.x, crane.stick2Offset.y, crane.stick2Offset.z,
                        crane.stick2Rotation.x, crane.stick2Rotation.y, crane.stick2Rotation.z,
                        false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.stick2)
                end
            end

            if not DoesEntityExist(crane.stick3) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_STICK3_MODEL) then
                    if not LoadModelWithTimeout(CRANE_STICK3_MODEL) then return end
                    crane.stick3 = CreateObject(CRANE_STICK3_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.stick3, crane.stick2, 0,
                        crane.stick3Offset.x, crane.stick3Offset.y, crane.stick3Offset.z,
                        0, 0, 0, false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.stick3)
                end
            end

            if not DoesEntityExist(crane.hook) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_HOOK_MODEL) then
                    if not LoadModelWithTimeout(CRANE_HOOK_MODEL) then return end
                    crane.hook = CreateObject(CRANE_HOOK_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.hook, crane.stick3, 0,
                        crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
                        crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
                        false, true, true, false, 2, false)
                    table.insert(crane.objects, crane.hook)
                end
            end

            if not DoesEntityExist(crane.grab1) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_GRAB1_MODEL) then
                    if not LoadModelWithTimeout(CRANE_GRAB1_MODEL) then return end
                    crane.grab1 = CreateObject(CRANE_GRAB1_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.grab1, crane.hook, 0,
                        crane.grabOffset.x, crane.grabOffset.y, crane.grabOffset.z,
                        crane.grabRotation.x, crane.grabRotation.y, crane.grabRotation.z,
                        false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.grab1)
                end
            end

            if not DoesEntityExist(crane.grab2) then
                if not IsModelAttachedToVehicle(crane.vehicle, CRANE_GRAB2_MODEL) then
                    if not LoadModelWithTimeout(CRANE_GRAB2_MODEL) then return end
                    crane.grab2 = CreateObject(CRANE_GRAB2_MODEL, crane.coords.x, crane.coords.y, crane.coords.z, false,
                        true, false)
                    AttachEntityToEntity(crane.grab2, crane.hook, 0,
                        crane.grabOffset.x * -1, crane.grabOffset.y, crane.grabOffset.z,
                        crane.grabRotation.x, crane.grabRotation.y * -1, crane.grabRotation.z,
                        false, true, false, false, 2, true)
                    table.insert(crane.objects, crane.grab2)
                end
            end
        end

        local isPlayerAllowed = false
        for i = 1, #craneEntry.players, 1 do
            if craneEntry.players[i] == myNetId then
                isPlayerAllowed = true
            end
        end

        if #crane.LoadedObjects < craneEntry.contentQuantity then
            if craneEntry.contentType ~= nil then
                local remainingToLoad = craneEntry.contentQuantity - #crane.LoadedObjects
                for _, modelEntry in pairs(crane.Models) do
                    if modelEntry.model == craneEntry.contentType then
                        for chipIndex = 1, remainingToLoad, 1 do
                            if not LoadModelWithTimeout(modelEntry.model) then return end
                            local vehicleDeadline = GetGameTimer() + 5000
                            while not DoesEntityExist(crane.vehicle) and GetGameTimer() < vehicleDeadline do
                                Citizen.Wait(100)
                            end
                            if not DoesEntityExist(crane.vehicle) then return end

                            local vehicleCoords = GetEntityCoords(crane.vehicle)
                            local loadedObject = CreateObject(modelEntry.model, vehicleCoords.x, vehicleCoords.y,
                                vehicleCoords.z, false, true, false)

                            local trailerPosition = modelEntry.trailerPostions and
                            modelEntry.trailerPostions[#crane.LoadedObjects + 1]
                            local offset = trailerPosition and trailerPosition.offset
                            local rotation = trailerPosition and trailerPosition.rotation

                            if offset and rotation then
                                DecorSetBool(loadedObject, "isCraneContent", true)
                                DecorSetBool(loadedObject, "entityOnForks", true)
                                AttachEntityToEntity(loadedObject, crane.vehicle, 0,
                                    offset.x, offset.y, offset.z,
                                    rotation.x, rotation.y, rotation.z,
                                    false, true, true, false, 2, true)
                                table.insert(crane.LoadedObjects, loadedObject)
                                crane.ExtraObjects[loadedObject] = {}

                                if modelEntry.model == -1937513394 then
                                    local chipsPile = CreateObject(-195941584, vehicleCoords.x, vehicleCoords.y,
                                        vehicleCoords.z, false, true, false)
                                    DecorSetBool(chipsPile, "isCraneContent", true)
                                    AttachEntityToEntity(chipsPile, loadedObject, 0,
                                        craneEntry.chipsData[chipIndex].x, craneEntry.chipsData[chipIndex].y,
                                        craneEntry.chipsData[chipIndex].z,
                                        0.0, 0.0, 0.0, false, true, false, false, 2, true)
                                    table.insert(crane.ExtraObjects[loadedObject], chipsPile)
                                end
                            end
                        end
                    end
                end
            end
        elseif #crane.LoadedObjects > craneEntry.contentQuantity then
            local lastIndex = #crane.LoadedObjects
            local lastObject = crane.LoadedObjects[lastIndex]
            DeleteEntity(lastObject)
            crane.LoadedObjects[lastIndex] = nil
            if crane.ExtraObjects[lastObject] then
                for _, extra in pairs(crane.ExtraObjects[lastObject]) do
                    DeleteEntity(extra)
                end
                crane.ExtraObjects[lastObject] = nil
            end
        end

        if craneEntry.hasControl == nil then
            if crane.vehicle == myVehicle then
                if not hookIsStowed then
                    AttachEntityToEntity(crane.hook, crane.stick3, 0,
                        crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
                        crane.stick1Rotation.x, 0.0, 0.0,
                        false, true, false, false, 2, true)
                    hookIsStowed = true
                end
            elseif hookIsStowed then
                local hookRotation = GetEntityRotation(crane.hook)
                crane.hookRotation = vector3(crane.hookRotation.x, crane.hookRotation.y, hookRotation.z)
                AttachEntityToEntity(crane.hook, crane.stick3, 0,
                    crane.hookOffset.x, crane.hookOffset.y, crane.hookOffset.z,
                    crane.hookRotation.x, crane.hookRotation.y, crane.hookRotation.z,
                    false, true, true, false, 2, false)
                hookIsStowed = false
            end
        end

        if not isPlayerAllowed then
            return
        end
        if craneEntry.hasControl ~= nil then
            if craneEntry.hasControl ~= myNetId then
                return
            end
        end

        local controlPanelOffset = GetOffsetFromEntityInWorldCoords(crane.vehicle, crane.controlOffset.x,
            crane.controlOffset.y, crane.controlOffset.z)
        local distanceToControlPanel = #(myCoords - controlPanelOffset)
        if not (distanceToControlPanel < 40) then
            return
        end

        local now = GetGameTimer()
        local tickWaitMs = 500

        if not crane.controling then
            if distanceToControlPanel < 1 then
                if craneEntry.hasControl == myNetId then
                    ShowHelpNotification(Config.Lang.putDownController)
                    if IsControlJustReleased(0, crane.Controls.E or 38) then
                        CurrentHoldingController = nil
                        craneEntry.hasControl = nil
                        crane.UpdateCrane()
                        TriggerServerEvent("17mov_Lumberjack:RunCraneAction", crane.id, "Fold")
                        crane.Fold()
                    end
                end
                if craneEntry.hasControl == nil then
                    ShowHelpNotification(Config.Lang.getController)
                    if IsControlJustReleased(0, crane.Controls.E or 38) then
                        local grantedPromise = promise.new()
                        TriggerServerCallback("17mov_Lumberjack:RequestCraneControl", function(granted)
                            grantedPromise:resolve(granted)
                        end, crane.id, myNetId)
                        if Citizen.Await(grantedPromise) then
                            CurrentHoldingController = crane.id
                            craneEntry.hasControl = myNetId
                            crane.UpdateCrane()
                            crane.ControllerAnimation()
                            TriggerServerEvent("17mov_Lumberjack:RunCraneAction", crane.id, "Unfold")
                            crane.Unfold()
                        else
                            Notify(Config.Lang.alreadyTakenControl)
                        end
                    end
                end
                tickWaitMs = 0
            else
                if craneEntry.hasControl == myNetId then
                    ShowHelpNotification(Config.Lang.controlCrane)
                    if IsControlJustReleased(0, 38) then
                        crane.controling = true
                    end
                end
                tickWaitMs = 0
            end
        else
            ShowHelpNotification(Config.Lang.controlingCrane)
            for _, controlId in pairs(crane.Controls) do
                DisableControlAction(0, controlId, true)
            end

            HandleHoldControl(crane, crane.id, crane.Controls.W, "AdjustHeight", crane.HeightSpeed * -1, now)
            HandleHoldControl(crane, crane.id, crane.Controls.S, "AdjustHeight", crane.HeightSpeed, now)
            HandleHoldControl(crane, crane.id, crane.Controls.A, "Rotate", crane.RotateSpeed, now)
            HandleHoldControl(crane, crane.id, crane.Controls.D, "Rotate", crane.RotateSpeed * -1, now)
            HandleHoldControl(crane, crane.id, crane.Controls.Q, "ControlStickLength", crane.StickLengthSpeed * -1, now)
            HandleHoldControl(crane, crane.id, crane.Controls.E, "ControlStickLength", crane.StickLengthSpeed, now)
            HandleHoldControl(crane, crane.id, crane.Controls.ArrowLeft, "RotateHook", crane.RotateHookSpeed, now)
            HandleHoldControl(crane, crane.id, crane.Controls.ArrowRight, "RotateHook", crane.RotateHookSpeed * -1, now)

            if IsDisabledControlJustReleased(0, crane.Controls.ESC) then
                crane.controling = false
            end

            if not crane.AttachedProp and not crane.attachedToHook then
                local hookGrabPoint = GetEntityCoords(crane.hook) - crane.hookAttachOffset

                local nearestObject = nil
                local nearestDistance = 100
                local nearestModelEntry = nil
                local nearestObjectCoords = vector3(0.0, 0.0, 0.0)

                local worldObjects = GetGamePool("CObject")
                for i = 1, #worldObjects, 1 do
                    local candidate = worldObjects[i]
                    if not DecorGetBool(candidate, "entityOnForks") then
                        local candidateModel = GetEntityModel(candidate)

                        local alreadyLoaded = false
                        for j = 1, #crane.LoadedObjects, 1 do
                            if crane.LoadedObjects[j] == candidate then
                                alreadyLoaded = true
                            end
                        end

                        if not alreadyLoaded then
                            for _, modelEntry in pairs(crane.Models) do
                                if modelEntry.model == candidateModel then
                                    local isValidCandidate = true

                                    if candidateModel == Config.Props.logs.hash then
                                        if Entity(candidate).state["17mov_Lumberjack:LogOwnedBy"] ~= CurrentLobbyHost then
                                            isValidCandidate = false
                                        end
                                    end

                                    if isValidCandidate and candidateModel == 1597396577 then
                                        local myIndex = Entity(candidate).state.myIndex
                                        if myIndex == nil then
                                            isValidCandidate = false
                                        elseif PlanksSpawnPoints[myIndex].haveAbove then
                                            isValidCandidate = false
                                        end
                                    end

                                    if isValidCandidate and candidateModel == -1937513394 then
                                        if ChipsThreadRunning then
                                            isValidCandidate = false
                                        else
                                            local myIndex = Entity(candidate).state.myIndex
                                            if not SkipsSpawnPoints[myIndex].currActiveSkip then
                                                isValidCandidate = false
                                            elseif not (SkipsSpawnPoints[myIndex].percentage > 0) then
                                                isValidCandidate = false
                                            end
                                        end
                                    end

                                    if isValidCandidate and crane.LoadedObjects[1] ~= nil then
                                        if GetEntityModel(crane.LoadedObjects[1]) ~= candidateModel then
                                            isValidCandidate = false
                                        end
                                    end

                                    if isValidCandidate then
                                        local candidateCoords = GetEntityCoords(candidate)
                                        local horizontalDistance = #(hookGrabPoint.xy - candidateCoords.xy)

                                        SetEntityDrawOutline(candidate, false)

                                        if nearestDistance > horizontalDistance then
                                            nearestObject = candidate
                                            nearestDistance = horizontalDistance
                                            nearestModelEntry = modelEntry
                                            nearestObjectCoords = candidateCoords
                                        end
                                    end
                                end
                            end
                        end
                    end
                end

                if nearestObject and DoesEntityExist(nearestObject) then
                    if nearestDistance < nearestModelEntry.attachDistance then
                        if math.abs(hookGrabPoint.z - 2.0 - nearestObjectCoords.z) < 2.0 then
                            SetEntityDrawOutline(nearestObject, true)
                            SetEntityDrawOutlineShader(1)
                            SetEntityDrawOutlineColor(50, 255, 50, 200)

                            if IsDisabledControlJustReleased(0, crane.Controls.LeftMouseButton) then
                                SetEntityDrawOutline(nearestObject, false)
                                crane.attachedToHook = true


                                local chipsAttachOffset = nil
                                if Entity(nearestObject).state.type == "skips" then
                                    chipsAttachOffset = SkipsSpawnPoints[Entity(nearestObject).state.myIndex]
                                    .chipsAttachOffset
                                end

                                local attachSucceeded = true
                                local networkId = 0

                                if NetworkGetEntityIsNetworked(nearestObject) then
                                    local waitStart = GetGameTimer()
                                    while networkId == 0 or networkId == nearestObject do
                                        networkId = NetworkGetNetworkIdFromEntity(nearestObject)
                                        if GetGameTimer() - waitStart > 5000 then
                                            break
                                        end
                                        Wait(100)
                                    end

                                    if DoesEntityExist(nearestObject) then
                                        if NetworkHasControlOfNetworkId(networkId) then
                                            DeleteEntity(nearestObject)
                                        else
                                            TriggerServerEvent("17mov_Lumberjack:RemoveLog", networkId)
                                        end
                                    else
                                        attachSucceeded = false
                                    end
                                else
                                    local entityType = Entity(nearestObject).state.type
                                    if entityType == "skips" or entityType == "planks" then
                                        TriggerServerEvent("17mov_Lumberjack:DeleteEntity", entityType,
                                            Entity(nearestObject).state.myIndex)
                                    end

                                    DeleteEntity(nearestObject)
                                    if DoesEntityExist(nearestObject) then
                                        FreezeEntityPosition(nearestObject, true)
                                        SetEntityCoords(nearestObject, 0, 0, 0, false, false, false, false)
                                    end
                                end

                                if attachSucceeded then
                                    TriggerServerCallback("17mov_Lumberjack:AttachPropToHook", function(granted)
                                        if not granted then
                                            crane.attachedToHook = false
                                            return Notify(Config.Lang.failedToAttach)
                                        end

                                        if not LoadModelWithTimeout(nearestModelEntry.model) then return end

                                        local vehicleCoords = GetEntityCoords(crane.vehicle)
                                        crane.TempProp = CreateObject(nearestModelEntry.model, vehicleCoords.x,
                                            vehicleCoords.y, vehicleCoords.z, false, true, false)
                                        SetEntityVisible(crane.TempProp, false, false)
                                        SetEntityCollision(crane.TempProp, false, false)
                                        SetEntityDrawOutline(crane.TempProp, true)
                                        SetEntityDrawOutlineShader(1)
                                        SetEntityDrawOutlineColor(255, 50, 50, 200)
                                        AttachEntityToEntity(crane.TempProp, crane.vehicle, 0,
                                            nearestModelEntry.tempOffset.x, nearestModelEntry.tempOffset.y,
                                            nearestModelEntry.tempOffset.z,
                                            nearestModelEntry.tempRotation.x, nearestModelEntry.tempRotation.y,
                                            nearestModelEntry.tempRotation.z,
                                            false, true, false, false, 2, true)
                                        crane.UpdateCrane()
                                    end, crane.id, nearestModelEntry.model, chipsAttachOffset, networkId)
                                end
                            end
                        end
                    end
                end
            elseif crane.AttachedProp and crane.AttachedPropData then
                local attachedCoords = GetEntityCoords(crane.AttachedProp)
                local tempPropCoords = GetEntityCoords(crane.TempProp)
                local distanceToTarget = #(attachedCoords - tempPropCoords)

                SetEntityDrawOutlineColor(255, 50, 50, 200)

                if distanceToTarget < 1.0 then
                    SetEntityDrawOutlineColor(50, 255, 50, 200)

                    if IsDisabledControlJustReleased(0, crane.Controls.LeftMouseButton) then
                        local releasedProp = crane.AttachedProp

                        local callbackArgs = { crane.id, crane.AttachedPropData.model }
                        if crane.AttachedPropData.model == 1242069632 or crane.AttachedPropData.model == -1937513394 then
                            table.insert(callbackArgs, crane.chipsOffset)
                        end

                        crane.AttachedProp = nil

                        TriggerServerCallback("17mov_Lumberjack:AttachPropToTrailer", function(granted)
                            crane.AttachedProp = releasedProp
                            DeleteEntity(crane.TempProp)
                            crane.TempProp = nil
                            crane.attachedToHook = false

                            if not granted then
                                return Notify(Config.Lang.failedToAttach)
                            end

                            crane.UpdateCrane()
                        end, table.unpack(callbackArgs))
                    end
                end
            end

            tickWaitMs = 0
        end

        return tickWaitMs
    end

    while true do
        local playerPed = PlayerPedId()
        local myCoords = GetEntityCoords(playerPed)
        local myVehicle = GetVehiclePedIsIn(playerPed, false)
        local myNetId = PedToNet(PlayerPedId())

        local netIdFetchStart = GetGameTimer()
        while true do
            if myNetId ~= 0 then
                if myNetId ~= PlayerPedId() then
                    break
                end
            end
            myNetId = PedToNet(PlayerPedId())
            Citizen.Wait(10)
            if GetGameTimer() - netIdFetchStart > 350 then
                print("CANNOT FETCH PlayerPedId() Net Id's")
                break
            end
        end

        local tickWaitMs = 1000
        for craneId, craneEntry in pairs(Cranes) do
            local overrideWait = ProcessCraneTick(craneId, craneEntry, myVehicle, myNetId, myCoords)
            if overrideWait then
                tickWaitMs = overrideWait
            end
        end

        Wait(tickWaitMs)
    end
end)

RegisterNetEvent("17mov_Lumberjack:RefreshCranes")
AddEventHandler("17mov_Lumberjack:RefreshCranes", function(newCranes)
    for craneId, _ in pairs(Cranes) do
        if newCranes[craneId] == nil then
            if Cranes[craneId].crane then
                if Cranes[craneId].crane.id ~= nil then
                    Cranes[craneId].crane.Destroy()
                end
            end
            Cranes[craneId] = nil
        end
    end

    for craneId, craneData in pairs(newCranes) do
        if not (Cranes[craneId] ~= nil and Cranes[craneId].crane ~= nil) then
            Cranes[craneId] = craneData

            local vehicleWaitStart = GetGameTimer()
            local vehicle = 0
            while true do
                if vehicle ~= 0 then
                    if vehicle ~= craneData.netId then
                        break
                    end
                end
                if NetworkDoesNetworkIdExist(craneData.netId) then
                    vehicle = NetworkGetEntityFromNetworkId(craneData.netId)
                end
                if GetGameTimer() - vehicleWaitStart > 5000 then
                    break
                end
                Wait(100)
            end

            if DoesEntityExist(vehicle) then
                if GetEntityModel(vehicle) == GetHashKey(Config.JobVehicleModel) then
                    Cranes[craneId].crane = CreateCrane(vehicle, craneData.netId, craneId)
                    TriggerEvent("17mov_Lumberjack:UpdateCrane", nil, craneId, craneData)
                end
            end
        end
    end
end)

local CraneSyncFields = {
    { data = "hookRotation",   action = "RotateHook",         handler = "SetHookRotation", key = "z", speed = "RotateHookSpeed" },
    { data = "baseRotation",   action = "Rotate",             handler = "SetRotate",       key = "z", speed = "RotateSpeed" },
    { data = "stick1Rotation", action = "AdjustHeight",       handler = "SetHeight",       key = "x", speed = "HeightSpeed" },
    { data = "stick3Offset",   action = "ControlStickLength", handler = "SetStickLength",  key = "y", speed = "StickLengthSpeed" },
    { data = "grabRotation",   action = "ControlHookGrip",    handler = "SetHookGrip",     key = "y", speed = "HookGripSpeed" },
}

local ActiveSyncTokens = {}
local SharedChipsPileEntity = 0

RegisterNetEvent("17mov_Lumberjack:UpdateCrane")
AddEventHandler("17mov_Lumberjack:UpdateCrane", function(senderId, craneId, updateData)
    if not Cranes[craneId] then
        return
    end
    if not Cranes[craneId].crane then
        return
    end

    local previousValues = {}
    for _, field in pairs(CraneSyncFields) do
        local value = nil
        if Cranes[craneId] and Cranes[craneId].crane then
            local axisVector = Cranes[craneId].crane[field.data]
            if axisVector then
                value = axisVector[field.key]
            end
        end
        previousValues[field.data] = value
    end

    for key, value in pairs(updateData) do
        Cranes[craneId][key] = value
    end

    Cranes[craneId].AttachedProp = updateData.AttachedProp
    Cranes[craneId].attachedProp = updateData.attachedProp
    Cranes[craneId].hasControl = updateData.hasControl

    if updateData.hasControl ~= nil then
        SetEntityDrawOutline(Cranes[craneId].crane.control, false)

        local controllerPed = NetToPed(Cranes[craneId].hasControl)
        if DoesEntityExist(controllerPed) then
            AttachEntityToEntity(Cranes[craneId].crane.control, controllerPed, GetPedBoneIndex(controllerPed, 57005),
                Cranes[craneId].crane.controlOffsetToPed.x, Cranes[craneId].crane.controlOffsetToPed.y,
                Cranes[craneId].crane.controlOffsetToPed.z,
                Cranes[craneId].crane.controlRotationToPed.x, Cranes[craneId].crane.controlRotationToPed.y,
                Cranes[craneId].crane.controlRotationToPed.z,
                false, true, false, false, 2, true)
        end
    else
        local attachDeadline = GetGameTimer() + 2500
        while GetGameTimer() < attachDeadline do
            if IsEntityAttachedToAnyVehicle(Cranes[craneId].crane.control) then
                break
            end

            Citizen.Wait(10)

            AttachEntityToEntity(Cranes[craneId].crane.control, Cranes[craneId].crane.vehicle, 0,
                Cranes[craneId].crane.controlOffset.x, Cranes[craneId].crane.controlOffset.y,
                Cranes[craneId].crane.controlOffset.z,
                Cranes[craneId].crane.controlRotation.x, Cranes[craneId].crane.controlRotation.y,
                Cranes[craneId].crane.controlRotation.z,
                false, true, false, false, 2, true)
        end
    end

    if updateData.attachedProp ~= nil then
        if not Cranes[craneId].crane.AttachedProp then
            local modelEntry = nil
            for _, entry in pairs(Cranes[craneId].crane.Models) do
                if entry.model == updateData.attachedProp then
                    modelEntry = entry
                end
            end

            if modelEntry then
                if modelEntry.replace then
                    updateData.attachedProp = modelEntry.replace
                end

                if not LoadModelWithTimeout(updateData.attachedProp) then return end

                local hookCoords = GetEntityCoords(Cranes[craneId].crane.hook)
                local spawnedProp = CreateObject(updateData.attachedProp, hookCoords.x, hookCoords.y, hookCoords.z, false,
                    true, false)
                DecorSetBool(spawnedProp, "entityOnForks", true)

                if updateData.attachedProp == 1242069632 or updateData.attachedProp == -1937513394 then
                    local chipsProp = CreateObject(-195941584, hookCoords.x, hookCoords.y, hookCoords.z, false, true,
                        true)
                    updateData.chipsObj = chipsProp
                    SharedChipsPileEntity = chipsProp

                    FreezeEntityPosition(updateData.chipsObj, true)
                    AttachEntityToEntity(updateData.chipsObj, spawnedProp, 0,
                        updateData.chipsOffset.x, updateData.chipsOffset.y, updateData.chipsOffset.z,
                        0.0, 0.0, 0.0, false, false, false, false, 2, true)
                end

                Cranes[craneId].crane.AttachedProp = spawnedProp
                Cranes[craneId].crane.chipsObj = updateData.chipsObj
                Cranes[craneId].crane.chipsOffset = updateData.chipsOffset
                Cranes[craneId].crane.AttachedPropData = modelEntry

                AttachEntityToEntity(spawnedProp, Cranes[craneId].crane.hook, 0,
                    modelEntry.attachOffset.x, modelEntry.attachOffset.y, modelEntry.attachOffset.z,
                    modelEntry.attachRotation.x, modelEntry.attachRotation.y, modelEntry.attachRotation.z,
                    false, true, false, false, 2, true)

                AttachEntityToEntity(Cranes[craneId].crane.grab1, Cranes[craneId].crane.hook, 0,
                    Cranes[craneId].crane.grabOffset.x, Cranes[craneId].crane.grabOffset.y,
                    Cranes[craneId].crane.grabOffset.z,
                    Cranes[craneId].crane.grabRotation.x, Cranes[craneId].crane.grabMaxRotation,
                    Cranes[craneId].crane.grabRotation.z,
                    false, true, false, false, 2, true)

                AttachEntityToEntity(Cranes[craneId].crane.grab2, Cranes[craneId].crane.hook, 0,
                    Cranes[craneId].crane.grabOffset.x * -1, Cranes[craneId].crane.grabOffset.y,
                    Cranes[craneId].crane.grabOffset.z,
                    Cranes[craneId].crane.grabRotation.x, Cranes[craneId].crane.grabMaxRotation * -1,
                    Cranes[craneId].crane.grabRotation.z,
                    false, true, false, false, 2, true)
            end
        end
    elseif Cranes[craneId].crane.AttachedProp then
        local deleteDeadline = GetGameTimer() + 1000
        while GetGameTimer() < deleteDeadline do
            if not DoesEntityExist(Cranes[craneId].crane.AttachedProp) then
                break
            end
            DeleteEntity(Cranes[craneId].crane.AttachedProp)
            Citizen.Wait(10)
        end

        if Cranes[craneId].crane.chipsObj then
            DeleteEntity(Cranes[craneId].crane.chipsObj)
            DeleteEntity(SharedChipsPileEntity)
            Cranes[craneId].crane.chipsObj = nil
            SharedChipsPileEntity = 0
        end

        AttachEntityToEntity(Cranes[craneId].crane.grab1, Cranes[craneId].crane.hook, 0,
            Cranes[craneId].crane.grabOffset.x, Cranes[craneId].crane.grabOffset.y, Cranes[craneId].crane.grabOffset.z,
            Cranes[craneId].crane.grabRotation.x, Cranes[craneId].crane.grabMinRotation,
            Cranes[craneId].crane.grabRotation.z,
            false, true, false, false, 2, true)

        AttachEntityToEntity(Cranes[craneId].crane.grab2, Cranes[craneId].crane.hook, 0,
            Cranes[craneId].crane.grabOffset.x * -1, Cranes[craneId].crane.grabOffset.y,
            Cranes[craneId].crane.grabOffset.z,
            Cranes[craneId].crane.grabRotation.x, Cranes[craneId].crane.grabMinRotation * -1,
            Cranes[craneId].crane.grabRotation.z,
            false, true, false, false, 2, true)

        for _, worldObject in pairs(GetGamePool("CObject")) do
            local objModel = GetEntityModel(worldObject)
            local isOnHook = IsEntityAttachedToEntity(worldObject, Cranes[craneId].crane.hook)
            if not isOnHook then
                isOnHook = IsEntityAttachedToEntity(Cranes[craneId].crane.hook, worldObject)
            end
            if isOnHook and objModel ~= 2069585976 and objModel ~= 687258484 and objModel ~= 1135801411 then
                DeleteEntity(worldObject)
            end
        end

        Cranes[craneId].crane.AttachedProp = nil
        Cranes[craneId].crane.AttachedPropData = nil
    end

    local crane = Cranes[craneId].crane
    if #crane.LoadedObjects < updateData.contentQuantity then
        if updateData.contentType ~= nil then
            local remainingToLoad = updateData.contentQuantity - #crane.LoadedObjects
            for _, modelEntry in pairs(crane.Models) do
                if modelEntry.model == updateData.contentType then
                    for chipIndex = 1, remainingToLoad, 1 do
                        if not LoadModelWithTimeout(modelEntry.model) then return end
                        local vehicleDeadline = GetGameTimer() + 5000
                        while not DoesEntityExist(crane.vehicle) and GetGameTimer() < vehicleDeadline do
                            Citizen.Wait(100)
                        end
                        if not DoesEntityExist(crane.vehicle) then return end

                        local vehicleCoords = GetEntityCoords(crane.vehicle)
                        local loadedObject = CreateObject(modelEntry.model, vehicleCoords.x, vehicleCoords.y,
                            vehicleCoords.z, false, true, false)

                        local trailerPosition = modelEntry.trailerPostions[#crane.LoadedObjects + 1]

                        DecorSetBool(loadedObject, "isCraneContent", true)
                        DecorSetBool(loadedObject, "entityOnForks", true)
                        AttachEntityToEntity(loadedObject, crane.vehicle, 0,
                            trailerPosition.offset.x, trailerPosition.offset.y, trailerPosition.offset.z,
                            trailerPosition.rotation.x, trailerPosition.rotation.y, trailerPosition.rotation.z,
                            false, true, true, false, 2, true)
                        table.insert(crane.LoadedObjects, loadedObject)
                        crane.ExtraObjects[loadedObject] = {}

                        if modelEntry.model == -1937513394 then
                            local chipsPile = CreateObject(-195941584, vehicleCoords.x, vehicleCoords.y, vehicleCoords.z,
                                false, true, false)
                            DecorSetBool(chipsPile, "isCraneContent", true)
                            AttachEntityToEntity(chipsPile, loadedObject, 0,
                                updateData.chipsData[chipIndex].x, updateData.chipsData[chipIndex].y,
                                updateData.chipsData[chipIndex].z,
                                0.0, 0.0, 0.0, false, true, false, false, 2, true)
                            table.insert(crane.ExtraObjects[loadedObject], chipsPile)
                        end
                    end
                end
            end
        end
    elseif #crane.LoadedObjects > updateData.contentQuantity then
        local lastIndex = #crane.LoadedObjects
        local lastObject = crane.LoadedObjects[lastIndex]
        DeleteEntity(lastObject)
        crane.LoadedObjects[lastIndex] = nil
        if crane.ExtraObjects[lastObject] then
            for _, extra in pairs(crane.ExtraObjects[lastObject]) do
                DeleteEntity(extra)
            end
            crane.ExtraObjects[lastObject] = nil
        end
    end

    Wait(50)

    local rotateSyncPending = false
    for _, field in pairs(CraneSyncFields) do
        if Cranes[craneId][field.data] then
            local shouldRun = true
            if Cranes[craneId].doingActions ~= nil then
                if Cranes[craneId].doingActions[field.action] ~= nil then
                    if Cranes[craneId].doingActions[field.action].runs ~= nil then
                        if not (Cranes[craneId].doingActions[field.action].runs < 1) then
                            shouldRun = false
                        end
                    end
                end
            end

            if shouldRun then
                if field.action == "Rotate" then
                    rotateSyncPending = true
                    break
                end
            end
        end
    end

    if GetPlayerServerId(PlayerId()) ~= senderId then
        if Cranes[craneId].crane then
            for _, field in pairs(CraneSyncFields) do
                if Cranes[craneId][field.data] then
                    local shouldRun = true
                    if Cranes[craneId].doingActions ~= nil then
                        if Cranes[craneId].doingActions[field.action] ~= nil then
                            if Cranes[craneId].doingActions[field.action].runs ~= nil then
                                if not (Cranes[craneId].doingActions[field.action].runs < 1) then
                                    shouldRun = false
                                end
                            end
                        end
                    end

                    if shouldRun then
                        if field.action ~= "RotateHook" or not rotateSyncPending then
                            local fromValue = previousValues[field.data]
                            local toValue = updateData[field.data] and updateData[field.data][field.key]

                            local speedRaw = nil
                            if Cranes[craneId] and Cranes[craneId].crane then
                                speedRaw = Cranes[craneId].crane[field.speed]
                            end
                            speedRaw = speedRaw or 0
                            local speedPerFrame = speedRaw * GetFrameTime()

                            if fromValue and toValue and speedRaw then
                                local token = math.random(1000000)
                                ActiveSyncTokens[field.action] = token

                                CreateThread(function()
                                    local delta = toValue - fromValue
                                    local direction = 1
                                    if not (delta > 0) then
                                        direction = -1
                                    end

                                    local steps = math.abs(delta) / speedPerFrame
                                    if steps > 0 then
                                        for _ = 1, math.floor(steps), 1 do
                                            if ActiveSyncTokens[field.action] ~= token then
                                                return
                                            end
                                            Cranes[craneId].crane[field.action](speedRaw * direction)
                                            Citizen.Wait(0)
                                        end


                                        local remainder = steps - math.floor(steps)
                                        local remainderScaled = math.abs(remainder) / speedPerFrame
                                        if remainderScaled > 0 then
                                            if ActiveSyncTokens[field.action] == token then
                                                Cranes[craneId].crane[field.action](remainderScaled * direction)
                                            end
                                        end
                                    end
                                end)
                            end
                        end
                    end
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:RunCraneAction")
AddEventHandler("17mov_Lumberjack:RunCraneAction", function(senderId, craneId, actionName, ...)
    if senderId ~= GetPlayerServerId(PlayerId()) then
        if Cranes[craneId] then
            if Cranes[craneId].crane then
                Cranes[craneId].crane[actionName](...)
            end
        end
    end
end)

function StartAction(craneId, actionName)
    CreateThread(function()
        while true do
            local craneEntry = Cranes[craneId]
            local action = craneEntry and craneEntry.doingActions and craneEntry.doingActions[actionName]
            if action == nil or action.runs <= 0 or craneEntry.crane == nil
                or type(craneEntry.crane[actionName]) ~= "function" then
                break
            end
            craneEntry.crane[actionName](table.unpack(action.data))
            Wait(0)
        end
    end)
end

RegisterNetEvent("17mov_Lumberjack:StartCraneAction")
AddEventHandler("17mov_Lumberjack:StartCraneAction", function(senderId, craneId, actionName, ...)
    if senderId ~= GetPlayerServerId(PlayerId()) then
        if Cranes[craneId] then
            if Cranes[craneId].crane then
                if not Cranes[craneId].doingActions then
                    Cranes[craneId].doingActions = {}
                end
                if not Cranes[craneId].doingActions[actionName] then
                    Cranes[craneId].doingActions[actionName] = { runs = 0, data = {} }
                end

                local wasIdle = Cranes[craneId].doingActions[actionName].runs < 1
                Cranes[craneId].doingActions[actionName].runs = Cranes[craneId].doingActions[actionName].runs + 1
                Cranes[craneId].doingActions[actionName].data = table.pack(...)

                if wasIdle then
                    StartAction(craneId, actionName)
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:StopCraneAction")
AddEventHandler("17mov_Lumberjack:StopCraneAction", function(senderId, craneId, actionName)
    if senderId ~= GetPlayerServerId(PlayerId()) then
        if Cranes[craneId] then
            if Cranes[craneId].crane then
                if not Cranes[craneId].doingActions then
                    Cranes[craneId].doingActions = {}
                end
                if not Cranes[craneId].doingActions[actionName] then
                    Cranes[craneId].doingActions[actionName] = { runs = 0, data = {} }
                else
                    Cranes[craneId].doingActions[actionName].runs = Cranes[craneId].doingActions[actionName].runs - 1
                end
            end
        end
    end
end)

RegisterNetEvent("onResourceStop")
AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    for _, craneEntry in pairs(Cranes) do
        if craneEntry.crane then
            craneEntry.crane.Destroy()
        end
    end
end)
