InitDone = false
PlayerData = nil
TreesData = {}
OnDuty = false
PlanksProcessed = false

PendingSkipObjForVehicle1 = 0
PendingChipsObjForVehicle1 = 0
PendingSkipObjForVehicle2 = 0
PendingChipsObjForVehicle2 = 0

TreeFallTutorialShown = false
UiActionBusy = false
AfterSkipFullLoadShown = false
ClothesIsWork = false

CallbackRegistry = {}
CallbackCounter = 0

HeldPlankObject = 0
HeldSkipObject = 0
CurrentCraneId = nil

VehicleAttachedCargo = {}
LobbyMembers = {}

MyServerId = GetPlayerServerId(PlayerId())

MenuOpen = true
CurrentUiActionId = ""

CurrentFallingTreeId = 0
local LocalTreeFallSuppression = {}
CurrentLobbyHost = nil
Carrying3DBox = false
ChipsThreadRunning = false
CurrentLogCounter = 0
CurrentHoldingController = nil

ChipsRatePerDelivery = 0
ChipsActionBusy = false
HeldLogObject = 0
ProcessedPlanksCount = 0

PickupActionBusy = false
PickupActionObject = 0
IsCuttingTree = false

JobVehicles = {}
JobVehicleNetIds = {}

NuiLoaded = false

local NativeRegisterNUICallback = RegisterNUICallback
local RegisteredNuiCallbacks = {}
function RegisterSafeNUICallback(name, handler)
    if RegisteredNuiCallbacks[name] then
        print(("[17mov_Lumberjack] ignored duplicate NUI callback registration: %s"):format(name))
        return
    end
    RegisteredNuiCallbacks[name] = true

    NativeRegisterNUICallback(name, function(data, callback)
        local replied = false
        local function reply(payload)
            if replied then return end
            replied = true
            callback(payload == nil and { ok = true } or payload)
        end

        SetTimeout(15000, function()
            if not replied then reply({ ok = false, error = "timeout" }) end
        end)

        local ok, keepOpen = pcall(handler, data or {}, reply)
        if not ok then
            print(("[17mov_Lumberjack] NUI callback '%s' failed: %s"):format(name, tostring(keepOpen)))
            reply({ ok = false, error = "internal_error" })
        elseif keepOpen ~= true then
            reply({ ok = true })
        end
    end)
end

local PlanksAttachmentsState = {}
for attachmentKey, attachmentCoords in pairs(Config.PlanksAttachments) do
    PlanksAttachmentsState[attachmentKey] = { coords = attachmentCoords }
end

local NativeNetToObj = NetToObj
function NetToObj(netId)
    if NetworkDoesNetworkIdExist(netId) then
        return NativeNetToObj(netId)
    else
        return 0
    end
end

local function WaitForNetworkObject(netId, timeoutMs)
    if type(netId) ~= "number" or netId <= 0 then return 0 end

    local deadline = GetGameTimer() + (timeoutMs or 5000)
    repeat
        local object = NetToObj(netId)
        if object ~= 0 and object ~= netId and DoesEntityExist(object) then
            return object
        end
        Wait(50)
    until GetGameTimer() >= deadline

    return 0
end

local function RequestEntityControl(entity, timeoutMs)
    if not DoesEntityExist(entity) then return false end

    local deadline = GetGameTimer() + (timeoutMs or 1000)
    repeat
        if NetworkHasControlOfEntity(entity) then return true end
        NetworkRequestControlOfEntity(entity)
        Wait(0)
    until GetGameTimer() >= deadline or not DoesEntityExist(entity)

    return DoesEntityExist(entity) and NetworkHasControlOfEntity(entity)
end

local NativeNetToVeh = NetToVeh
function NetToVeh(netId)
    if NetworkDoesNetworkIdExist(netId) then
        return NativeNetToVeh(netId)
    else
        return 0
    end
end

local NativeNetworkGetNetworkIdFromEntity = NetworkGetNetworkIdFromEntity
function NetworkGetNetworkIdFromEntity(entity)
    if DoesEntityExist(entity) then
        return NativeNetworkGetNetworkIdFromEntity(entity)
    else
        return 0
    end
end

CreateThread(function()
    if not Config.EnableVehicleLegacyMode then
        Config.Locations.rentForklift = nil
        Config.Locations.WithdrawTruck = nil
        Config.Locations.ReturnLogCar = nil
    end

    while SetVehicle == nil do
        Wait(1000)
    end

    RealSetVehicle = SetVehicle

    local ProcessedVehicleHandles = {}
    SetVehicle = function(vehicle)
        if ProcessedVehicleHandles[vehicle] == true then
            return
        end
        ProcessedVehicleHandles[vehicle] = true
        CreateThread(function()
            RealSetVehicle(vehicle)
        end)
    end
end)

function DeepCopy(value)
    local result
    if type(value) == "table" then
        result = {}
        for key, innerValue in next, value do
            result[DeepCopy(key)] = DeepCopy(innerValue)
        end
        setmetatable(result, DeepCopy(getmetatable(value)))
    else
        result = value
    end
    return result
end

Config.ForksAttachment2 = DeepCopy(Config.ForksAttachment)

local TrailerLogsAttachmentsState = {}
for attachmentKey, attachmentCoords in pairs(Config.TrailerLogsAttachments) do
    TrailerLogsAttachmentsState[attachmentKey] = { coords = attachmentCoords }
end

local TrailerSkipsAttachmentsState = {}
for attachmentKey, attachmentCoords in pairs(Config.TrailerSkipsAttachments) do
    TrailerSkipsAttachmentsState[attachmentKey] = { coords = attachmentCoords }
end

local SkipAttachOffset = {
    coords = vec3(0.5, 0.6, 0.3),
    rotation = vec3(0.0, 0.0, 90.0),
}

local SkipDumpsterModels = {
    {
        model = 1246111104,
        coords = vec3(-521.8718, 5301.853, 82.514946),
        rotation = vec3(0.0, 0.0, -20.0),
    },
    {
        model = 1016859180,
        coords = vec3(-521.7263, 5301.88, 78.44211),
        rotation = vec3(0.0, 0.0, -20.0),
    },
    {
        model = 1941403770,
        coords = vec3(-523.6604, 5298.72168, 71.68133),
        rotation = vec3(0.0, 0.0, -20.0),
    },
}

SkipsSpawnPoints = {
    {
        coords = vec3(-523.7699, 5298.66357, 73.4215),
        rotation = vec3(0.0, 0.0, 70.0),
        percentage = 0,
        liftProgress = 0,
        currActiveSkip = true,
    },
    {
        coords = vec3(-523.5898, 5285.729, 73.5347),
        rotation = vec3(0.0, 0.0, -20.0),
        percentage = 0,
        liftProgress = 0,
        currActiveSkip = false,
    },
    {
        coords = vec3(-525.6033, 5280.098, 73.5606461),
        rotation = vec3(0.0, 0.0, -20.0),
        percentage = 0,
        liftProgress = 0,
        currActiveSkip = false,
    },
}

for index = 1, #Config.SkipsSpawnPoints do
    if SkipsSpawnPoints[index] then
        SkipsSpawnPoints[index].coords = Config.SkipsSpawnPoints[index].coords
        SkipsSpawnPoints[index].rotation = Config.SkipsSpawnPoints[index].rotation
    end
end

local SkipsSpawnPointsDefault = DeepCopy(SkipsSpawnPoints)

PlanksSpawnPoints = {
    {
        coords = vec3(-509.68, 5274.88152, 79.62286),
        rotation = vec3(1.0, 0.0, 69.0),
        haveAbove = false,
        aboveId = 3,
    },
    {
        coords = vec3(-506.085431, 5273.48, 79.62991),
        rotation = vec3(0.0, 0.0, 69.0),
        haveAbove = false,
        aboveId = 4,
    },
    {
        coords = vec3(-509.68, 5274.88152, 80.742286),
        rotation = vec3(0.0, 0.0, 69.0),
    },
    {
        coords = vec3(-506.085431, 5273.48, 80.742991),
        rotation = vec3(0.0, 0.0, 69.0),
    },
    {
        coords = vec3(-510.2854, 5273.289, 79.62286),
        rotation = vec3(0.0, 0.0, 69.0),
        haveAbove = false,
        aboveId = 7,
    },
    {
        coords = vec3(-506.6802, 5271.88355, 79.6247),
        rotation = vec3(0.0, 0.0, 69.0),
        haveAbove = false,
        aboveId = 8,
    },
    {
        coords = vec3(-510.2854, 5273.289, 80.73),
        rotation = vec3(1.0, 0.0, 69.0),
    },
    {
        coords = vec3(-506.6802, 5271.88355, 80.73),
        rotation = vec3(0.0, 0.0, 69.0),
    },
    {
        coords = vec3(-509.615021, 5269.62, 79.73364),
        rotation = vec3(1.0, 0.0, 69.0),
    },
}

local WoodPileWaypoints = {
    { coords = vec3(-499.269531, 5348.296, 80.46913), rotation = vec3(0.0, 0.0, -20.0), duration = 4200 },
    { coords = vec3(-476.9089, 5312.707, 82.61991), rotation = vec3(0.0, 0.0, -30.0) },
    { coords = vec3(-479.388, 5309.986, 82.61991), rotation = vec3(0.0, 0.0, -55.0) },
    { coords = vec3(-482.739075, 5308.51465, 82.61991), rotation = vec3(0.0, 0.0, -80.0) },
    { coords = vec3(-486.665039, 5308.75146, 82.61991), rotation = vec3(0.0, 0.0, -105.0) },
    { coords = vec3(-490.864777, 5310.1333, 82.61991), rotation = vec3(0.0, 0.0, -110.0) },
    { coords = vec3(-508.974335, 5316.72461, 82.61991), rotation = vec3(0.0, 0.0, -110.0) },
    { coords = vec3(-512.9911, 5318.18652, 81.99616), rotation = vec3(12.0, 0.0, -110.0) },
    { coords = vec3(-538.119751, 5327.333, 76.7822342), rotation = vec3(12.0, 0.0, -110.0) },
    { coords = vec3(-542.2347, 5328.777, 76.4439), rotation = vec3(0.0, 0.0, -110.0) },
    { coords = vec3(-550.8362, 5331.867, 74.01255), rotation = vec3(0.0, 0.0, -110.0) },
}

local WoodPileDebrisEffects = {
    {
        coords = vec3(-499.269531, 5348.296, 80.46913),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 1250,
        fxName = "scr_reconstructionaccident",
        particle = "scr_reconstruct_pipefall_debris",
        rotate = true,
        totalRotations = 3,
        speed = 3.0,
    },
    {
        coords = vec3(-504.431183, 5350.17432, 77.15405),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 1150,
        fxName = "scr_reconstructionaccident",
        particle = "scr_reconstruct_pipefall_debris",
        rotate = true,
        totalRotations = 4,
        speed = 7.0,
    },
    {
        coords = vec3(-546.569336, 5365.511, 73.11546),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 4350,
        rotate = true,
        totalRotations = 15,
        speed = 10.0,
    },
    {
        coords = vec3(-547.5741, 5365.877, 71.327095),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 350,
        fxName = "scr_reconstructionaccident",
        particle = "scr_reconstruct_pipefall_debris",
        speed = 6.0,
    },
    {
        coords = vec3(-553.25116, 5350.279, 71.6394348),
        rotation = vec3(-2.0, 0.0, -20.0),
        duration = 1500,
        speed = 4.2,
    },
    {
        coords = vec3(-554.9821, 5345.52344, 71.95936),
        rotation = vec3(-4.0, 0.0, -20.0),
        duration = 500,
    },
    {
        coords = vec3(-558.4586, 5335.972, 72.67014),
        rotation = vec3(-4.0, 0.0, -20.0),
        duration = 1000,
    },
    {
        coords = vec3(-559.9132, 5331.976, 72.85535),
        rotation = vec3(-0.0, 0.0, -20.0),
        duration = 200,
    },
    {
        coords = vec3(-564.3689, 5319.73438, 72.92417),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 1500,
    },
    {
        coords = vec3(-560.5875, 5318.055, 72.82756),
        rotation = vec3(0.0, 0.0, -20.0),
        changeObjectTo = "17mov_woodpile",
        duration = 1500,
    },
    {
        coords = vec3(-560.5875, 5318.055, 72.82756),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 250,
        fxName = "core",
        particle = "bul_wood_splinter_heli",
    },
    {
        coords = vec3(-564.666565, 5319.42529, 72.59955),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 3000,
    },
    {
        coords = vec3(-568.9402, 5307.68359, 72.59955),
        rotation = vec3(0.0, 0.0, -20.0),
        duration = 2000,
    },
    {
        coords = vec3(-571.137634, 5300.18945, 73.30044),
        rotation = vec3(-0.0, 0.0, -20.0),
        duration = 1000,
    },
    {
        coords = vec3(-571.1599, 5299.695, 73.41406),
        rotation = vec3(-0.0, 0.0, -15.0),
        duration = 1000,
    },
    {
        coords = vec3(-571.11554, 5298.871, 73.4609451),
        rotation = vec3(-2.0, 0.0, -5.0),
        duration = 1000,
    },
    {
        coords = vec3(-571.0464, 5297.026, 73.74979),
        rotation = vec3(-2.4, 0.0, 10.14),
        duration = 1000,
    },
    {
        coords = vec3(-570.7378, 5296.00146, 73.86721),
        rotation = vec3(-2.4, 0.21, 15.14),
        duration = 1000,
    },
    {
        coords = vec3(-570.3104, 5294.84668, 73.91799),
        rotation = vec3(-2.4, 0.42, 20.15),
        duration = 1000,
    },
    {
        coords = vec3(-569.026, 5292.643, 74.20371),
        rotation = vec3(-5.06, 0.42, 35.15),
        duration = 1000,
    },
    {
        coords = vec3(-568.5745, 5291.96045, 74.27566),
        rotation = vec3(-5.14, 0.42, 45.15),
        duration = 1000,
    },
    {
        coords = vec3(-565.8897, 5290.079, 74.56706),
        rotation = vec3(-4.84, 1.74, 65.46),
        duration = 1000,
    },
    {
        coords = vec3(-565.8897, 5290.079, 74.56706),
        rotation = vec3(-4.84, 1.74, 65.46),
        duration = 750,
    },
    {
        coords = vec3(-561.927734, 5288.62, 74.91401),
        rotation = vec3(-5.67, 1.18, 70.67),
        duration = 600,
    },
    {
        coords = vec3(-557.7101, 5287.139, 75.27876),
        rotation = vec3(-5.67, 1.18, 70.67),
        duration = 600,
    },
    {
        coords = vec3(-521.032654, 5274.03027, 78.74946),
        rotation = vec3(-5.67, 1.18, 70.67),
        duration = 5500,
    },
    {
        coords = vec3(-517.233459, 5272.67, 79.20782),
        rotation = vec3(-9.67, 2.18, 70.67),
        duration = 650,
    },
    {
        coords = vec3(-513.583557, 5271.35938, 79.57278),
        rotation = vec3(0.32, 2.15, 70.29),
        duration = 650,
    },
}

CreateThread(function()
    for i = 2, #WoodPileDebrisEffects - 1 do
        local current = WoodPileDebrisEffects[i]
        local nextPoint = WoodPileDebrisEffects[i + 1]
        local dx = nextPoint.coords.x - current.coords.x
        local dy = nextPoint.coords.y - current.coords.y
        local dz = nextPoint.coords.z - current.coords.z
        local distance = math.sqrt(dx * dx + dy * dy + dz * dz)
        local speed = current.speed or 4.0
        current.duration = (distance / speed) * 1000
    end

    for i = 2, #WoodPileWaypoints - 1 do
        local current = WoodPileWaypoints[i]
        local nextPoint = WoodPileWaypoints[i + 1]
        local dx = nextPoint.coords.x - current.coords.x
        local dy = nextPoint.coords.y - current.coords.y
        local dz = nextPoint.coords.z - current.coords.z
        local distance = math.sqrt(dx * dx + dy * dy + dz * dz)
        local speed = current.speed or 4.0
        current.duration = (distance / speed) * 1000
    end
end)

RegisterSafeNUICallback("nuiLoaded", function()
    NuiLoaded = true
end)

local function CreateTreeObject(tree)
    local obj = CreateObject(
        Config.Props.tree.hash,
        tree.coords.x,
        tree.coords.y,
        tree.coords.z + Config.Props.tree.zOffset,
        false, true, true
    )
    tree.obj = obj
    FreezeEntityPosition(tree.obj, true)
end

local function DeleteTreeObject(tree)
    if DoesEntityExist(tree.obj) then
        DeleteEntity(tree.obj)
        tree.obj = nil
    end
end

CreateThread(function()
    DecorRegister("entityOnForks", 2)
    DecorRegister("isCraneContent", 2)
    DecorRegister("entityIsNeeded", 2)

    Wait(3500)

    TriggerServerCallback("17mov_lumberjack:GetTreesData", function(treesData)
        if type(treesData) ~= "table" then return end
        TreesData = treesData

        if not LoadModelWithTimeout(Config.Props.tree.hash) then return end

        for _, tree in ipairs(TreesData) do
            if tree.isAvalible then
                CreateTreeObject(tree)
            end
        end

        CreateThread(function()
            while true do
                local playerCoords = GetEntityCoords(PlayerPedId())
                for _, tree in ipairs(TreesData) do
                    if tree.isAvalible then
                        local distance = #(playerCoords - vec3(tree.coords.x, tree.coords.y, tree.coords.z))
                        if distance < 100.0 then
                            if tree.obj == nil then
                                CreateTreeObject(tree)
                            end
                        else
                            if tree.obj ~= nil then
                                DeleteTreeObject(tree)
                            end
                        end
                    end
                end
                Wait(1000)
            end
        end)

        if Config.ClearPeds then
            while true do
                Wait(2000)
                ClearNonPlayerPeds(vector3(-560.76, 5320.68, 73.6), 100)
            end
        end
    end)
end)

function ClearNonPlayerPeds(coords, radius)
    local nearbyPeds = GetNearbyPeds(coords, radius)
    for _, ped in ipairs(nearbyPeds) do
        if not IsPedAPlayer(ped) then
            if not DecorGetBool(ped, "entityIsNeeded") then
                if not IsPedSittingInAnyVehicle(ped) then
                    DeletePed(ped)
                end
            end
        end
    end
end

function GetNearbyPeds(coords, radius)
    local peds = {}
    local allPeds = GetGamePool("CPed")
    for i = 1, #allPeds do
        local ped = allPeds[i]
        local distance = #(coords - GetEntityCoords(ped))
        if radius >= distance then
            table.insert(peds, ped)
        end
    end
    return peds
end

CreateThread(function()
    local deadline = GetGameTimer() + 15000
    while not NuiLoaded and GetGameTimer() < deadline do
        Wait(100)
    end
    if not NuiLoaded then
        return print("[17mov_Lumberjack] NUI did not become ready within 15 seconds")
    end

    SendNUIMessage({
        action = "setProgressBarAlign",
        align = Config.ProgressBarAlign,
        offset = Config.ProgressBarOffset,
    })

    if not Config.EnableCloakroom then
        SendNUIMessage({ action = "hideCloakroom" })
    end

    if Config.letBossSplitReward then
        RegisterSafeNUICallback("checkIfThisRewardIsFine", function(data, cb)
            local rawValue = tonumber(data.value)
            local plyId = tonumber(data.plyId)
            if rawValue == nil or rawValue ~= rawValue or rawValue == math.huge or rawValue == -math.huge
                or plyId == nil then
                cb(false)
                return
            end
            local value = math.floor(rawValue)

            if value > 100 or value < 0 then
                Notify(Config.Lang.wrongReward1)
                cb(false)
                return
            end

            TriggerServerCallback("17mov_lumberjack:CheckThisReward", function(isValid)
                if isValid then
                    cb(true)
                else
                    cb(false)
                    Notify(Config.Lang.wrongReward2)
                end
            end, value, plyId)
            return true
        end)
    else
        SendNUIMessage({ action = "hideManageRewards" })
    end
end)

RegisterSafeNUICallback("tutorialClosed", function()
    SetNuiFocus(false, false)
    UiActionBusy = false
    CurrentUiActionId = ""
    DisableControlAction(0, 30, false)
    DisableControlAction(0, 31, false)
    DisableControlAction(0, 32, false)
    DisableControlAction(0, 33, false)
    DisableControlAction(0, 34, false)
    DisableControlAction(0, 35, false)
end)

RegisterSafeNUICallback("menuClosed", function()
    MenuOpen = false
    SetNuiFocus(false, false)
end)

RegisterSafeNUICallback("dontShowTutorialAgain", function()
    SetResourceKvpInt("17mov_Tutorials:" .. CurrentUiActionId, 1)
end)

RegisterNetEvent("17mov_lumberjack:SetMyReward", function(reward)
    SendNUIMessage({ action = "updateMyReward", reward = reward })
end)

RegisterNetEvent("17mov_lumberjack:UpdateHostPercentages", function(reward)
    SendNUIMessage({ action = "updateHostRewards", value = reward })
end)

RegisterNetEvent("17mov_lumberjack:clearMyLobby", function()
    LobbyMembers = {}

    TriggerServerCallback("17mov_lumberjack:init", function(data)
        SendNUIMessage({ action = "Init", name = data.name, myId = data.source })
        InitDone = true
    end)
end)

RegisterNetEvent("17mov_lumberjack:RefreshMugs")
AddEventHandler("17mov_lumberjack:RefreshMugs", function(members)
    local deadline = GetGameTimer() + 15000
    while not InitDone and GetGameTimer() < deadline do
        Wait(100)
    end
    if not InitDone or type(members) ~= "table" then return end

    for _, member in pairs(members) do
        SendNUIMessage({ action = "DeleteNearbyPlayer", id = member.id })

        if LobbyMembers[member.id] == nil then
            if MyServerId == member.id then
                LobbyMembers[member.id] = {
                    name = member.name,
                    id = member.id,
                    isHost = member.isHost,
                    rewardPercent = member.rewardPercent,
                    itsMe = true,
                }
            else
                LobbyMembers[member.id] = {
                    name = member.name,
                    id = member.id,
                    isHost = member.isHost,
                    rewardPercent = member.rewardPercent,
                    itsMe = false,
                }
            end

            SendNUIMessage({
                action = "addNewMember",
                name = member.name,
                id = member.id,
                isHost = member.isHost,
                rewardPercent = member.rewardPercent,
                showQuitBtn = LobbyMembers[member.id].itsMe,
            })
        end
    end

    local stillInLobbyCount = 0
    for memberId, memberData in pairs(LobbyMembers) do
        local stillPresent = false
        for _, member in pairs(members) do
            if member.id == memberData.id then
                stillPresent = true
                break
            end
        end

        if not stillPresent then
            LobbyMembers[memberId] = nil
            SendNUIMessage({ action = "DeletePlayer", id = memberData.id })
        else
            stillInLobbyCount = stillInLobbyCount + 1
        end
    end

    if stillInLobbyCount == 1 then
        TriggerServerCallback("17mov_lumberjack:init", function(data)
            SendNUIMessage({ action = "Init", name = data.name, myId = data.source })
            InitDone = true
        end)
    end

    TriggerServerCallback("17mov_lumberjack:IfPlayerOwnsTeam", function(isOwner)
        SendNUIMessage({ action = "ToggleHostHUD", boolean = isOwner })
    end)
end)

_ENV.TriggerServerCallback = function(callbackName, callback, ...)
    CallbackCounter = CallbackCounter + 1
    if CallbackCounter > 2147483646 then CallbackCounter = 1 end
    local callbackId = CallbackCounter
    CallbackRegistry[callbackId] = { name = callbackName, callback = callback }
    TriggerServerEvent("17mov_Callbacks:GetResponse" .. GetCurrentResourceName(), callbackName, callbackId, ...)

    SetTimeout(10000, function()
        local pending = CallbackRegistry[callbackId]
        if pending == nil then return end
        CallbackRegistry[callbackId] = nil
        pending.callback(nil, "timeout")
    end)
end

RegisterNetEvent("17mov_Callbacks:receiveData" .. GetCurrentResourceName(), function(callbackName, callbackId, ...)
    local pending = CallbackRegistry[callbackId]
    if pending == nil or pending.name ~= callbackName then return end
    CallbackRegistry[callbackId] = nil
    pending.callback(...)
end)

MarkersActive = false

LastStation = nil
LastPart = nil
LastPartNum = nil
HasAlreadyEnteredMarker = false

_ENV.StartMarkers = function(playerData)
    if MarkersActive then
        return
    end

    if Config.RequiredJob ~= "none" then
        if playerData == nil or playerData.job == nil or playerData.job.name ~= Config.RequiredJob then
            MarkersActive = false
            return
        end
    end

    MarkersActive = true

    local useTarget = Config.UseTarget and IsLumberjackTargetAvailable()
    if useTarget then
        SpawnPeds()

        Config.Locations2 = {
            FinishJob = Config.Locations.FinishJob,
            ReturnLogCar = Config.Locations.ReturnLogCar,
        }

        while MarkersActive do
            Wait(0)
            local playerCoords = GetEntityCoords(PlayerPedId())

            local hasEnteredAny = false
            local exitedSomething = false
            local shouldWaitLong = true
            local stationId, partId, partNum = nil, nil, nil

            if Config.RequiredJob == "none" or (playerData.job and playerData.job.name == Config.RequiredJob) then
                for locationId, location in pairs(Config.Locations2) do

                    if not location.turnedOff and (OnDuty or location.type == "duty") then
                        for _, coords in pairs(location.Coords) do
                            local distance = #(playerCoords - coords)
                            if distance < 50 then
                                if distance > location.scale.x then
                                    DrawMarker(6, coords.x, coords.y, coords.z - 1, 0.0, 0.0, 0.0, -90.0, 0.0, 0.0,
                                        location.scale.x, location.scale.y, location.scale.z,
                                        Config.MarkerSettings.UnActive.r, Config.MarkerSettings.UnActive.g,
                                        Config.MarkerSettings.UnActive.b, Config.MarkerSettings.UnActive.a,
                                        false, false, 2, false, false, false, false)
                                    shouldWaitLong = false
                                elseif distance < location.scale.x then
                                    shouldWaitLong = false
                                    DrawMarker(6, coords.x, coords.y, coords.z - 1, 0.0, 0.0, 0.0, -90.0, 0.0, 0.0,
                                        location.scale.x, location.scale.y, location.scale.z,
                                        Config.MarkerSettings.Active.r, Config.MarkerSettings.Active.g,
                                        Config.MarkerSettings.Active.b, Config.MarkerSettings.Active.a,
                                        false, false, 2, false, false, false, false)
                                    hasEnteredAny = true

                                    stationId = locationId
                                    partId = locationId
                                    partNum = Iterator
                                end
                            end
                        end
                    end
                end

                if hasEnteredAny then
                    local sameMarkerAsBefore = HasAlreadyEnteredMarker
                        and LastStation == stationId
                        and LastPart == partId
                        and LastPartNum == partNum

                    if not sameMarkerAsBefore then
                        if LastStation and LastPart and LastPartNum then
                            if not (LastStation == stationId and LastPart == partId and LastPartNum == partNum) then
                                TriggerEvent("17mov_lumberjack:ExitedMarker", LastStation, LastPart, LastPartNum)
                                exitedSomething = true
                            end
                        end

                        HasAlreadyEnteredMarker = true
                        LastStation = stationId
                        LastPart = partId
                        LastPartNum = partNum
                        TriggerEvent("17mov_lumberjack:EnteredMarker", partId)
                    end
                end

                if not exitedSomething and not hasEnteredAny then
                    if HasAlreadyEnteredMarker then
                        HasAlreadyEnteredMarker = false
                        TriggerEvent("17mov_lumberjack:ExitedMarker", LastStation, LastPart, LastPartNum)
                    end
                end

                if shouldWaitLong then
                    Wait(500)
                end
            end
        end

        if DeleteTargetPeds then DeleteTargetPeds() end
    else
        while MarkersActive do
            Wait(0)
            local playerCoords = GetEntityCoords(PlayerPedId())

            local hasEnteredAny = false
            local exitedSomething = false
            local shouldWaitLong = true
            local stationId, partId, partNum = nil, nil, nil

            if Config.RequiredJob == "none" or (playerData.job and playerData.job.name == Config.RequiredJob) then
                for locationId, location in pairs(Config.Locations) do
                    if not location.turnedOff and (OnDuty or location.type == "duty") then
                        for _, coords in pairs(location.Coords) do
                            local distance = #(playerCoords - coords)
                            if distance < 50 then
                                if distance > location.scale.x then
                                    DrawMarker(6, coords.x, coords.y, coords.z - 1, 0.0, 0.0, 0.0, -90.0, 0.0, 0.0,
                                        location.scale.x, location.scale.y, location.scale.z,
                                        Config.MarkerSettings.UnActive.r, Config.MarkerSettings.UnActive.g,
                                        Config.MarkerSettings.UnActive.b, Config.MarkerSettings.UnActive.a,
                                        false, false, 2, false, false, false, false)
                                    shouldWaitLong = false
                                elseif distance < location.scale.x then
                                    shouldWaitLong = false
                                    DrawMarker(6, coords.x, coords.y, coords.z - 1, 0.0, 0.0, 0.0, -90.0, 0.0, 0.0,
                                        location.scale.x, location.scale.y, location.scale.z,
                                        Config.MarkerSettings.Active.r, Config.MarkerSettings.Active.g,
                                        Config.MarkerSettings.Active.b, Config.MarkerSettings.Active.a,
                                        false, false, 2, false, false, false, false)
                                    hasEnteredAny = true
                                    stationId = locationId
                                    partId = locationId
                                    partNum = Iterator
                                end
                            end
                        end
                    end
                end

                if hasEnteredAny then
                    local sameMarkerAsBefore = HasAlreadyEnteredMarker
                        and LastStation == stationId
                        and LastPart == partId
                        and LastPartNum == partNum

                    if not sameMarkerAsBefore then
                        if LastStation and LastPart and LastPartNum then
                            if not (LastStation == stationId and LastPart == partId and LastPartNum == partNum) then
                                TriggerEvent("17mov_lumberjack:ExitedMarker", LastStation, LastPart, LastPartNum)
                                exitedSomething = true
                            end
                        end

                        HasAlreadyEnteredMarker = true
                        LastStation = stationId
                        LastPart = partId
                        LastPartNum = partNum
                        TriggerEvent("17mov_lumberjack:EnteredMarker", partId)
                    end
                end

                if not exitedSomething and not hasEnteredAny then
                    if HasAlreadyEnteredMarker then
                        HasAlreadyEnteredMarker = false
                        TriggerEvent("17mov_lumberjack:ExitedMarker", LastStation, LastPart, LastPartNum)
                    end
                end

                if shouldWaitLong then
                    Wait(500)
                end
            end
        end
    end
end

CreateThread(function()

    PlayerData = GetPlayerData()

    while not (PlayerData ~= nil and PlayerData.job ~= nil) do
        PlayerData = GetPlayerData()
        Wait(1000)
    end

    if Config.RestrictBlipToRequiredJob then
        if Config.RequiredJob == PlayerData.job.name then
            MakeBlip()
        end
    else
        MakeBlip()
    end

    StartMarkers(PlayerData)
end)

BlipsActive = false

_ENV.MakeBlip = function()
    if BlipsActive then
        return
    end
    BlipsActive = true

    for _, blipData in pairs(Config.Blips) do
        blipData.blip = AddBlipForCoord(blipData.Pos.x, blipData.Pos.y, blipData.Pos.z)
        SetBlipSprite(blipData.blip, blipData.Sprite)
        SetBlipDisplay(blipData.blip, 4)
        SetBlipScale(blipData.blip, blipData.Scale)
        SetBlipColour(blipData.blip, blipData.Color)
        SetBlipAsShortRange(blipData.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(blipData.Label)
        EndTextCommandSetBlipName(blipData.blip)
    end
end

_ENV.DeleteBlip = function()
    BlipsActive = false
    for _, blipData in pairs(Config.Blips) do
        RemoveBlip(blipData.blip)
        blipData.blip = nil
    end
end

local function RefreshJobAccess(job)
    local jobName = job and job.name or "unknown"
    local allowed = Config.RequiredJob == "none" or jobName == Config.RequiredJob

    if not Config.RestrictBlipToRequiredJob or allowed then
        MakeBlip()
    else
        DeleteBlip()
    end

    if allowed then
        StartMarkers(PlayerData or { job = { name = jobName } })
    else
        MarkersActive = false
    end
end

ScriptInitialized = false

_ENV.InitalizeScript = function(skipStartupDelay)
    if ScriptInitialized then
        return
    end

    local deadline = GetGameTimer() + 15000
    while not NuiLoaded and GetGameTimer() < deadline do
        Wait(100)
    end
    if not NuiLoaded then
        return print("[17mov_Lumberjack] initialization stopped because the NUI is unavailable")
    end

    PlayerData = GetPlayerData()

    if not skipStartupDelay then
        Wait(5500)
    end

    ScriptInitialized = true

    RefreshJobAccess(PlayerData and PlayerData.job)

    TriggerServerCallback("17mov_lumberjack:init", function(data)
        SendNUIMessage({ action = "Init", name = data.name, myId = data.source })
        InitDone = true
    end)
end

RegisterNetEvent("QBCore:Client:OnPlayerLoaded", function()
    InitalizeScript()
end)

RegisterNetEvent("esx:playerLoaded", function()
    InitalizeScript()
end)

RegisterNetEvent("QBCore:Client:OnJobUpdate")
AddEventHandler("QBCore:Client:OnJobUpdate", function(job)
    PlayerData = GetPlayerData()
    PlayerData.job = job or PlayerData.job
    RefreshJobAccess(PlayerData.job)
end)

RegisterNetEvent("esx:setJob")
AddEventHandler("esx:setJob", function(job)
    while not (PlayerData ~= nil and PlayerData.job ~= nil) do
        PlayerData = GetPlayerData()
        Wait(1000)
    end

    PlayerData.job = job
    RefreshJobAccess(PlayerData.job)
end)

local function HandlePlayerUnload()
    TriggerServerEvent("17mov_Lumberjack:PlayerUnloaded")
    RemoveKeys()
    OnDuty = false
    MarkersActive = false
    ScriptInitialized = false
    InitDone = false
    PlayerData = nil
    LobbyMembers = {}
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "CloseAll" })
end

RegisterNetEvent("QBCore:Client:OnPlayerUnload", HandlePlayerUnload)
RegisterNetEvent("esx:onPlayerLogout", HandlePlayerUnload)

AddEventHandler("17mov_lumberjack:EnteredMarker", function(stationKey)
    CurrentAction = Config.Locations[stationKey].CurrentAction
    CurrentActionMsg = Config.Locations[stationKey].CurrentActionMsg
    CurrentActionStation = stationKey
end)

CreateThread(function()
    while true do
        if CurrentActionMsg ~= nil then
            ShowHelpNotification(CurrentActionMsg)
            Wait(0)
        else
            Wait(250)
        end
    end
end)

AddEventHandler("17mov_lumberjack:ExitedMarker", function()
    CurrentAction = nil
    CurrentActionMsg = nil
    CurrentActionStation = nil
end)

RegisterCommand("+17MovLumberjackJobStartMarkerAction", function()
end, false)

RegisterCommand("-17MovLumberjackJobStartMarkerAction", function()
    if CurrentAction ~= nil then
        if CurrentAction == "open_dutyToggle" then
            OpenDutyMenu()
        elseif CurrentAction == "finish_job" then
            TriggerServerCallback("17mov_lumberjack:IfPlayerIsHost", function(isHost)
                if isHost then
                    EndJob()
                else
                    Notify(Config.Lang.no_permission)
                end
            end)
        elseif CurrentAction == "return_logcar" then
            HideLogCar()
        elseif CurrentAction == "withdraw_truck" then
            OpenPanel("rentTruck")
        elseif CurrentAction == "rent_forklift" then
            OpenPanel("rentForklift")
        end
    end
end, false)

RegisterSafeNUICallback("rentForklift", function(_, reply)
    SetNuiFocus(false, false)

    TriggerServerCallback("17mov_lumberjack:CheckIfCanRentForklift", function(canRent)
        reply({ ok = canRent == true })
        if canRent then
            if Config.EnableVehicleTeleporting then
                DoScreenFadeOut(250)
                Wait(500)
            end

            local vehicle, netId = SpawnVehicle(Config.JobForkliftModel, Config.SpawnPointForklift, true)
            if vehicle then TriggerServerEvent("17mov_lumberjack:SendVehicleToClients", "JobForklift", netId) end

            if Config.EnableVehicleTeleporting then
                Wait(1500)
                DoScreenFadeIn(250)
            end
        end
    end)
    return true
end)

RegisterSafeNUICallback("rentTruck", function(_, reply)
    SetNuiFocus(false, false)

    TriggerServerCallback("17mov_lumberjack:CheckIfCanWithdrawTruck", function(canWithdraw)
        reply({ ok = canWithdraw == true })
        if canWithdraw then
            if Config.EnableVehicleTeleporting then
                DoScreenFadeOut(250)
                Wait(500)
            end

            local vehicle, netId = SpawnVehicle(Config.JobTruckModel, Config.SpawnPointTruck, true)
            if vehicle then TriggerServerEvent("17mov_lumberjack:SendVehicleToClients", "JobTruck", netId) end

            if Config.EnableVehicleTeleporting then
                Wait(1500)
                DoScreenFadeIn(250)
            end
        end
    end)
    return true
end)

_ENV.HideLogCar = function()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)

    if GetEntityModel(vehicle) == GetHashKey(Config.LegacyJobVehicleModel)
        or GetEntityModel(vehicle) == GetHashKey(Config.JobVehicleModel) then
        if GetPedInVehicleSeat(vehicle, -1) == PlayerPedId() then
            if GetVehicleTrailerVehicle(vehicle) == 1 then
                return Notify(Config.Lang.CantWithTrailer)
            end

            Config.Locations.ReturnLogCar.turnedOff = true
            TriggerServerEvent("17mov_lumberjack:logCarHidden")
        else
            Notify(Config.Lang.notDriverOrValidModel)
        end
    else
        Notify(Config.Lang.notDriverOrValidModel)
    end
end

TriggerEvent("chat:removeSuggestion", "/+17MovLumberjackJobStartMarkerAction")
TriggerEvent("chat:removeSuggestion", "/-17MovLumberjackJobStartMarkerAction")

RegisterKeyMapping(
    "+17MovLumberjackJobStartMarkerAction",
    Config.Lang.keybind,
    "keyboard",
    "E"
)

NearbyPlayersTracked = {}

_ENV.OpenDutyMenu = function()
    if not ScriptInitialized then
        InitalizeScript(true)
        print("SCRIPT NOT READY - WAIT UNTIL SCRIPT PROPERLY LOAD")
        return
    end

    if not InitDone then
        TriggerServerCallback("17mov_lumberjack:init", function(data)
            SendNUIMessage({ action = "Init", name = data.name, myId = data.source })
            InitDone = true
        end)
        print("SCRIPT NOT READY - WAIT UNTIL SCRIPT PROPERLY LOAD")
        return
    end

    SendNUIMessage({ action = "OpenWorkMenu" })
    SetNuiFocus(true, true)

    MenuOpen = true

    local nearbyTabReady = false
    local hidingNearbyTab = false
    local isTrackingAnyone = false

    CreateThread(function()
        while MenuOpen do
            local activePlayers = GetActivePlayers()
            local myCoords = GetEntityCoords(PlayerPedId())
            local nearbyPlayerIds = {}
            local newNearbyPlayerFound = false

            for _, playerHandle in pairs(activePlayers) do
                if PlayerId() ~= playerHandle then
                    local distance = #(myCoords - GetEntityCoords(GetPlayerPed(playerHandle)))
                    if distance < 10.0 then
                        table.insert(nearbyPlayerIds, GetPlayerServerId(playerHandle))
                    end
                end
            end

            if #nearbyPlayerIds > 0 or isTrackingAnyone then
                TriggerServerCallback("17mov_lumberjack:GetPlayersNames", function(playersData)
                    for playerKey, playerInfo in pairs(playersData) do
                        if NearbyPlayersTracked[playerInfo.id] == nil then
                            newNearbyPlayerFound = true

                            NearbyPlayersTracked[playerInfo.id] = { id = playerInfo.id, name = playerInfo.name }

                            SendNUIMessage({ action = "addNewNearbyPlayer", id = playerInfo.id, name = playerInfo.name })
                        else
                            playersData[playerKey] = nil
                        end
                    end

                    isTrackingAnyone = false
                    for trackedId, trackedPlayer in pairs(NearbyPlayersTracked) do
                        isTrackingAnyone = true
                        local stillNearby = false

                        for _, playerInfo in pairs(playersData) do
                            if playerInfo.id == trackedPlayer.id then
                                stillNearby = true
                                break
                            end
                        end

                        if not stillNearby then
                            NearbyPlayersTracked[trackedId] = nil
                            hidingNearbyTab = true
                            SendNUIMessage({ action = "DeleteNearbyPlayer", id = trackedPlayer.id })

                            CreateThread(function()
                                Wait(250)
                                hidingNearbyTab = false
                            end)
                        end
                    end

                    if not newNearbyPlayerFound then
                        if nearbyTabReady then
                            CreateThread(function()
                                while hidingNearbyTab do
                                    Wait(10)
                                end

                                SendNUIMessage({ action = "hideNearbyPlayersTab" })

                                CreateThread(function()
                                    Wait(250)
                                    nearbyTabReady = false
                                end)
                            end)
                        end
                    else
                        if isTrackingAnyone then
                            if not nearbyTabReady then
                                SendNUIMessage({ action = "showNearbyPlayersTab" })

                                CreateThread(function()
                                    Wait(250)
                                    nearbyTabReady = true
                                end)
                            end
                        end
                    end
                end, nearbyPlayerIds)
            end

            Wait(2500)
        end
    end)
end

RegisterSafeNUICallback("changeClothes", function(data)
    if data.type == "work" then
        ClothesIsWork = true
        ChangeClothes("work")
    else
        ClothesIsWork = false
        ChangeClothes("citizen")
    end
end)

RegisterSafeNUICallback("requestReacted", function(data)
    SetNuiFocus(false, false)
    TriggerServerEvent("17mov_lumberjack:ClientReactRequest", data.boolean)
end)

RegisterSafeNUICallback("sendRequest", function(data)
    if OnDuty then
        Notify(Config.Lang.cantInvite)
        return
    end
    TriggerServerEvent("17mov_lumberjack:SendRequestToClient_sv", tonumber(data.id))
end)

RegisterSafeNUICallback("kickPlayerFromLobby", function(data)
    local kickedId = tonumber(data.id)
    Notify(string.format(Config.Lang.kicked, LobbyMembers[kickedId].name))
    TriggerServerEvent("17mov_lumberjack:KickPlayerFromLobby", kickedId, true)
end)

RegisterSafeNUICallback("focusOff", function()
    SetNuiFocus(false, false)
end)

RegisterSafeNUICallback("notify", function(data)
    Notify(data.msg)
end)

RegisterNetEvent("17mov_lumberjack:SendRequestToClient_cl")
AddEventHandler("17mov_lumberjack:SendRequestToClient_cl", function(fromName, extra)
    SetNuiFocus(true, true)
    SendNUIMessage({ action = "ShowInviteBox", name = fromName })
end)

_ENV.IsSpawnPointClear = function()
    local spawnPointCoords = vec3(Config.SpawnPoint.x, Config.SpawnPoint.y, Config.SpawnPoint.z)
    local flatbedSpawnCoords = vec3(Config.SpawnPointFlatbed.x, Config.SpawnPointFlatbed.y, Config.SpawnPointFlatbed.z)

    local vehiclePool = GetGamePool("CVehicle")
    if vehiclePool == nil or type(vehiclePool) ~= "table" then
        print("FAILED TO FETCH GAMEPOOL - Returning CLEAR")
        return true
    end

    for _, poolVehicle in pairs(vehiclePool) do
        if #(GetEntityCoords(poolVehicle) - spawnPointCoords) < 3.1
            or #(GetEntityCoords(poolVehicle) - flatbedSpawnCoords) < 3.1 then
            Notify(Config.Lang.spawnpointOccupied)
            return false
        end
    end

    return true
end

_ENV.AreAllPlayesrClose = function()
    if not Config.RequiredAllPlayerClose.enabled then
        return true
    end

    local myCoords = GetEntityCoords(PlayerPedId())
    local awaiter = promise.new()

    TriggerServerCallback("17mov_Lumberjack:GetAllPlayersClose", function(allClose)
        if not allClose then
            Notify(Config.Lang.notAllPlayersClose)
        end
        awaiter:resolve(allClose)
    end, myCoords)

    return Citizen.Await(awaiter)
end

RegisterSafeNUICallback("startJob", function(data)
    if not OnDuty then
        if IsSpawnPointClear() then
            if AreAllPlayesrClose() then
                TriggerServerEvent("17mov_lumberjack:StartJob_sv")
            end
        end
    else
        Notify(Config.Lang.alreadyWorking)
    end
end)

RegisterSafeNUICallback("leaveLobby", function(data)
    if OnDuty then
        Notify(Config.Lang.cantLeaveLobby)
        return
    end

    local targetId = tonumber(data.id)
    TriggerServerEvent("17mov_lumberjack:KickPlayerFromLobby", targetId, false, GetPlayerServerId(PlayerId()))
    Notify(Config.Lang.quit)
end)

_ENV.SpawnVehicle = function(model, coords, teleportPlayerIn, skipSetVehicleHook, minimalSetup)
    PrepeareVehicle()
    local modelHash = type(model) == "string" and GetHashKey(model) or model
    if not LoadModelWithTimeout(modelHash, 25000) then
        Notify(Config.Lang.wentWrong)
        return nil, 0
    end

    if not coords.w then
        coords = vector4(coords.x, coords.y, coords.z, GetEntityHeading(PlayerPedId()))
    end

    local vehicleHandle, netId
    for _ = 1, 3 do
        vehicleHandle = CreateVehicle(modelHash, coords.x, coords.y, coords.z, coords.w, true, false)
        netId = 0
        local waitStartTime = GetGameTimer()
        while DoesEntityExist(vehicleHandle) and (netId == 0 or netId == vehicleHandle)
            and GetGameTimer() - waitStartTime <= 5000 do
            netId = NetworkGetNetworkIdFromEntity(vehicleHandle)
            Wait(100)
        end
        if DoesEntityExist(vehicleHandle) and netId ~= 0 and netId ~= vehicleHandle then break end
        if DoesEntityExist(vehicleHandle) then DeleteEntity(vehicleHandle) end
        vehicleHandle, netId = nil, 0
    end
    if vehicleHandle == nil then
        SetModelAsNoLongerNeeded(modelHash)
        Notify(Config.Lang.wentWrong)
        return nil, 0
    end

    NetworkSetObjectForceStaticBlend(vehicleHandle, true)
    SetNetworkEnableVehiclePositionCorrection(vehicleHandle, true)
    NetworkUseHighPrecisionBlending(netId, true)

    if teleportPlayerIn then
        if Config.EnableVehicleTeleporting then
            TaskWarpPedIntoVehicle(PlayerPedId(), vehicleHandle, -1)
        end
    end

    if not minimalSetup then
        SetEntityAsMissionEntity(vehicleHandle, true, true)
        SetVehicleNeedsToBeHotwired(vehicleHandle, false)
        SetVehRadioStation(vehicleHandle, "OFF")
        SetVehicleFuelLevel(vehicleHandle, 100.0)

        SetVehicleDirtLevel(vehicleHandle, 0.0)
        SetModelAsNoLongerNeeded(modelHash)

        if not skipSetVehicleHook then
            SetVehicle(vehicleHandle)
        end
    else
        SetVehicleDamageModifier(vehicleHandle, 0)
    end

    return vehicleHandle, netId
end

_ENV.AddBlip = function(label, sprite, coords, color, scale)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)

    if sprite ~= nil then
        SetBlipSprite(blip, sprite)
    end

    if scale == nil then
        scale = 0.6
    end

    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, scale)
    SetBlipColour(blip, color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(label)
    EndTextCommandSetBlipName(blip)

    return blip
end

RegisterNetEvent("17mov_Lumberjack:DeleteThisID", function(treeId)
    TreesData[treeId].isAvalible = false
    RemoveBlip(TreesData[treeId].blip)
end)

RegisterNetEvent("17mov_Lumberjack:RespawnThisTree", function(treeId)
    local tree = TreesData[treeId]
    if tree == nil then return end
    tree.isAvalible = true

    if not LoadModelWithTimeout(Config.Props.tree.hash) then return end

    tree.obj = CreateObject(
        Config.Props.tree.hash,
        tree.coords.x, tree.coords.y, tree.coords.z + Config.Props.tree.zOffset,
        false, true, true
    )
    SetEntityVisible(tree.obj, false, false)
    FreezeEntityPosition(tree.obj, true)
    SetEntityVisible(tree.obj, true, false)
end)

local function AwaitServerCallback(callbackName, ...)
    local resultPromise = promise.new()
    TriggerServerCallback(callbackName, function(result)
        resultPromise:resolve(result == true)
    end, ...)
    return Citizen.Await(resultPromise)
end

_ENV.CutDownTree = function(treeId)
    if IsCuttingTree then
        return
    end

    if CurrentHoldingController then
        return
    end

    local tree = TreesData[treeId]
    if tree == nil or not tree.isAvalible then return end

    if CurrentLogCounter >= 12 then
        Notify(Config.Lang.tooManyLogs)
    else
        if not AwaitServerCallback("17mov_Lumberjack:ReserveTree", treeId) then return end
        IsCuttingTree = true

        if ChainsawAnimation(tree.obj) then
            CurrentFallingTreeId = treeId
            local heading = GetEntityHeading(PlayerPedId())
            LocalTreeFallSuppression[treeId] = true
            if AwaitServerCallback("17mov_Lumberjack:CompleteTree", treeId, heading) then
                StartFallAnim(tree.obj, false, heading)
            else
                LocalTreeFallSuppression[treeId] = nil
                TriggerServerEvent("17mov_Lumberjack:CancelTreeReservation", treeId)
            end

            CurrentFallingTreeId = 0
        else
            TriggerServerEvent("17mov_Lumberjack:CancelTreeReservation", treeId)
        end

        CreateThread(function()
            Wait(1000)
            IsCuttingTree = false
        end)
    end
end

RegisterNetEvent("17mov_Lumberjack:DeleteEntity", function(entityType, id)
    if entityType == "skips" then
        local skip = SkipsSpawnPoints[id]
        if skip ~= nil then
            skip.hasBeenLifted = true
            skip.currActiveSkip = false

            if DoesEntityExist(skip.chipsObj) then
                DeleteEntity(skip.chipsObj)
            else
                local allObjects = GetGamePool("CObject")
                for i = 1, #allObjects do
                    local obj = allObjects[i]
                    if IsEntityAttachedToEntity(obj, skip.obj) then
                        DeleteEntity(obj)
                    end
                end
            end

            DeleteEntity(skip.obj)

            CreateThread(function()
                Wait(3500)
                for skipId, otherSkip in pairs(SkipsSpawnPoints) do
                    if not otherSkip.currActiveSkip then
                        if skipId ~= id then
                            if otherSkip.hasBeenLifted == nil then
                                SetEntityCoords(otherSkip.obj,
                                    SkipsSpawnPoints[1].coords.x, SkipsSpawnPoints[1].coords.y, SkipsSpawnPoints[1].coords.z,
                                    false, false, false, false)
                                SetEntityRotation(otherSkip.obj,
                                    SkipsSpawnPoints[1].rotation.x, SkipsSpawnPoints[1].rotation.y, SkipsSpawnPoints[1].rotation.z,
                                    0, false)
                                SetEntityCollision(otherSkip.obj, true, true)
                                otherSkip.currActiveSkip = true
                                break
                            end
                        end
                    end
                end
            end)
        end
    elseif entityType == "planks" then
        local plank = PlanksSpawnPoints[id]
        if plank ~= nil then
            DeleteEntity(plank.obj)
            plank.obj = nil

            for _, otherPlank in pairs(PlanksSpawnPoints) do
                if otherPlank.aboveId ~= nil then
                    if otherPlank.aboveId == id then
                        otherPlank.haveAbove = false
                    end
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:RemoteCreated", function(craneId)
    if craneId == nil then
        return
    end

    local deadline = GetGameTimer() + 10000
    while not (Cranes ~= nil and Cranes[craneId] ~= nil and Cranes[craneId].crane ~= nil)
        and GetGameTimer() < deadline do
        Citizen.Wait(100)
    end

    if Cranes == nil or Cranes[craneId] == nil or Cranes[craneId].crane == nil then return end

    CurrentCraneId = craneId

    while not DoesEntityExist(Cranes[craneId].crane.control) and GetGameTimer() < deadline do
        Citizen.Wait(10)
    end

    if not DoesEntityExist(Cranes[craneId].crane.control) then return end

    local craneControl = Cranes[craneId].crane.control
    SetEntityDrawOutlineColor(171, 91, 41, 200)
    SetEntityDrawOutlineShader(1)
    SetEntityDrawOutline(craneControl, true)
end)

TreeTargetsAdded = {}

RegisterNetEvent("17mov_lumberjack:StartJob_cl")
AddEventHandler("17mov_lumberjack:StartJob_cl", function(hostId, myId, lobbySize, pickupRoleId, secondVehicleRoleId)
    CurrentLogCounter = 0
    CurrentLobbyHost = hostId

    if Config.EnableVehicleLegacyMode then
        Config.Locations.ReturnLogCar.turnedOff = false
    end

    PlanksProcessed = false
    Carrying3DBox = false
    HeldLogObject = 0
    HeldPlankObject = 0
    HeldSkipObject = 0
    ProcessedPlanksCount = 0
    ChipsActionBusy = false

    PlanksAttachmentsState = {}
    for attachmentId, coords in pairs(Config.PlanksAttachments) do
        PlanksAttachmentsState[attachmentId] = { coords = coords }
    end

    local logPropHash = -1937513394
    if not LoadModelWithTimeout(logPropHash) then return end

    local chipsPropHash = -195941584
    if not LoadModelWithTimeout(chipsPropHash) then return end

    OnDuty = true

    SkipsSpawnPoints = DeepCopy(SkipsSpawnPointsDefault)

    for skipId, skip in pairs(SkipsSpawnPoints) do

        local strayLog = nil
        local strayChips = nil

        while strayLog ~= 0 do
            strayLog = GetClosestLog(vec3(skip.coords.x, skip.coords.y, skip.coords.z), 1.0, logPropHash)
            strayChips = GetClosestLog(vec3(skip.coords.x, skip.coords.y, skip.coords.z), 3.0, chipsPropHash)

            if strayLog ~= 0 then
                DeleteEntity(strayLog)
            end
            if strayChips ~= 0 then
                DeleteEntity(strayChips)
            end

            Wait(100)
        end

        skip.obj = CreateObject(logPropHash, skip.coords.x, skip.coords.y, skip.coords.z, false, true, true)
        FreezeEntityPosition(skip.obj, true)
        SetEntityRotation(skip.obj, skip.rotation.x, skip.rotation.y, skip.rotation.z, 0, false)
        skip.percentage = 0
        skip.liftProgress = 0

        skip.chipsObj = CreateObject(chipsPropHash, skip.coords.x, skip.coords.y, skip.coords.z, false, true, true)
        FreezeEntityPosition(skip.chipsObj, true)
        SetEntityRotation(skip.chipsObj, skip.rotation.x, skip.rotation.y, skip.rotation.z, 0, false)
        AttachEntityToEntity(skip.chipsObj, skip.obj, 0, 0.027, 0.076, 0.16, 0.0, 0.0, 0.0, false, false, true, false, 2, true)
        skip.chipsAttachOffset = vec3(0.027, 0.076, 0.16)

        Entity(skip.obj).state.myIndex = skipId
        Entity(skip.obj).state.type = "skips"
    end

    for stationName, stationParts in pairs(Config.Stations) do
        for i = 1, #stationParts do
            local part = stationParts[i]
            part.blip = AddBlip(
                Config.BlipsStyles[stationName].label,
                Config.BlipsStyles[stationName].sprite,
                part.coords,
                Config.BlipsStyles[stationName].color,
                Config.BlipsStyles[stationName].scale
            )
        end
    end

    for attachmentId, coords in pairs(Config.TrailerLogsAttachments) do
        TrailerLogsAttachmentsState[attachmentId] = { coords = coords }
    end

    for _, plank in pairs(PlanksSpawnPoints) do
        plank.obj = nil
    end

    if Config.EnableVehicleLegacyMode then
        Config.Locations.WithdrawTruck.blip = AddBlip(
            Config.BlipsStyles.withdrawTruck.label,
            Config.BlipsStyles.withdrawTruck.sprite,
            Config.Locations.WithdrawTruck.Coords[1],
            Config.BlipsStyles.withdrawTruck.color,
            Config.BlipsStyles.withdrawTruck.scale
        )

        Config.Locations.rentForklift.blip = AddBlip(
            Config.BlipsStyles.rentForklift.label,
            Config.BlipsStyles.rentForklift.sprite,
            Config.Locations.rentForklift.Coords[1],
            Config.BlipsStyles.rentForklift.color,
            Config.BlipsStyles.rentForklift.scale
        )
    end

    ChipsBlip = AddBlip(
        Config.BlipsStyles.pickupChips.label,
        Config.BlipsStyles.pickupChips.sprite,
        Config.SkipsSpawnPoints[1].coords,
        Config.BlipsStyles.pickupChips.color,
        Config.BlipsStyles.pickupChips.scale
    )

    PlanksBlip = AddBlip(
        Config.BlipsStyles.pickupPlanks.label,
        Config.BlipsStyles.pickupPlanks.sprite,
        PlanksSpawnPoints[1].coords,
        Config.BlipsStyles.pickupPlanks.color,
        Config.BlipsStyles.pickupPlanks.scale
    )

    for _, tree in pairs(TreesData) do
        if tree.isAvalible then
            tree.blip = AddBlip(
                Config.BlipsStyles.treeBlip.label,
                Config.BlipsStyles.treeBlip.sprite,
                tree.coords,
                Config.BlipsStyles.treeBlip.color,
                Config.BlipsStyles.treeBlip.scale
            )
        end
    end

    CreateThread(function()
        if not ClothesIsWork then
            if Config.RequireWorkClothes then
                ClothesIsWork = true
                ChangeClothes("work")
            end
        end
    end)

    for i = 1, #Config.ForksAttachment do
        Config.ForksAttachment[i].obj = nil
    end

    for i = 1, #Config.ForksAttachment2 do
        Config.ForksAttachment2[i].obj = nil
    end

    if not isBack then

        if Config.EnableVehicleLegacyMode and Config.Lang.startingTutorialLegacy then
            ShowTutorial(Config.Lang.startingTutorialLegacy)
        else
            ShowTutorial(Config.Lang.startingTutorial)
        end
    end

    local vehiclesToSpawn = {}

    if hostId == myId then
        if Config.EnableVehicleLegacyMode then
            vehiclesToSpawn.JobVehicle = { model = Config.LegacyJobVehicleModel, coords = Config.SpawnPoint, teleport = true }
            vehiclesToSpawn.JobFlatbed = {
                model = Config.LegacyJobFlatbedModel,
                coords = Config.SpawnPointFlatbed,
                teleport = false,
                setFuel = true,
                isTrailer = true,
            }
        else
            vehiclesToSpawn.JobVehicle = { model = Config.JobVehicleModel, coords = Config.SpawnPoint, teleport = true }
        end
    end

    if lobbySize == 4 and secondVehicleRoleId == myId then
        if Config.EnableVehicleLegacyMode then
            vehiclesToSpawn.JobVehicle2 = { model = Config.LegacyJobVehicleModel, coords = Config.SpawnPoint2, teleport = true }
        end
    end

    if pickupRoleId == myId then
        vehiclesToSpawn.JobPickup = { model = Config.PickupModel, coords = Config.SpawnPointPickup, teleport = true }
    end

    if Config.EnableVehicleTeleporting then
        if not isBack then
            DoScreenFadeOut(300)
            Wait(500)
        end
    end

    for roleKey, vehicleSpec in pairs(vehiclesToSpawn) do
        local vehicleHandle, netId = SpawnVehicle(
            vehicleSpec.model, vehicleSpec.coords, vehicleSpec.teleport,
            vehicleSpec.setFuel, vehicleSpec.isTrailer
        )
        if vehicleHandle then
            SetHornEnabled(vehicleHandle, false)
            TriggerServerEvent("17mov_lumberjack:SendVehicleToClients", roleKey, netId)

            if not Config.EnableVehicleLegacyMode and (roleKey == "JobVehicle" or roleKey == "JobVehicle2") then
                TriggerServerEvent("17mov_Lumberjack:SpawnCrane", netId)
            end
        end
    end

    Wait(1500)
    DoScreenFadeIn(300)

    local vehicleSyncDeadline = GetGameTimer() + 15000
    while not (JobVehicles.JobVehicle ~= nil and JobVehicles.JobVehicle ~= 0)
        and GetGameTimer() < vehicleSyncDeadline do
        Wait(100)
    end
    if JobVehicles.JobVehicle == nil or JobVehicles.JobVehicle == 0 then
        Notify(Config.Lang.wentWrong)
        return
    end

    if Config.EnableVehicleLegacyMode then
        while not (JobVehicles.JobFlatbed ~= nil and JobVehicles.JobFlatbed ~= 0)
            and GetGameTimer() < vehicleSyncDeadline do
            Wait(100)
        end
        if JobVehicles.JobFlatbed == nil or JobVehicles.JobFlatbed == 0 then
            Notify(Config.Lang.wentWrong)
            return
        end
    end

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            if CurrentHoldingController ~= nil then
                if IsDead(PlayerPedId()) then
                    for _, craneEntry in pairs(Cranes) do
                        local crane = craneEntry.crane
                        if crane.id == CurrentHoldingController then
                            crane.controling = false
                            CurrentHoldingController = nil
                            craneEntry.hasControl = nil
                            crane.UpdateCrane()
                            TriggerServerEvent("17mov_Lumberjack:RunCraneAction", crane.id, "Fold")
                            crane.Fold()
                        end
                    end
                end
            end

            Wait(pollInterval)
        end
    end)

    if Config.EnableVehicleLegacyMode then
        CreateThread(function()
            while OnDuty do
                local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)

                if vehicleUnderPed ~= 0 then
                    local trailer = GetVehicleTrailerVehicle(vehicleUnderPed)

                    if GetEntityModel(trailer) == -740256823 then
                        local truckHookOffset = nil
                        local trailerHookOffset = nil
                        local hasKnownHookBones = false

                        local truckHeading = GetEntityHeading(vehicleUnderPed)
                        local trailerHeading = GetEntityHeading(trailer)

                        if GetEntityModel(vehicleUnderPed) == -227413559 then
                            local truckBonePos = GetWorldPositionOfEntityBone(
                                vehicleUnderPed, GetEntityBoneIndexByName(vehicleUnderPed, "transmission_m")
                            )
                            local trailerBonePos = GetWorldPositionOfEntityBone(
                                trailer, GetEntityBoneIndexByName(trailer, "hook")
                            )
                            truckHookOffset = GetObjectOffsetFromCoords(truckBonePos.x, truckBonePos.y, truckBonePos.z, truckHeading, 0, -3.0, 0.5)
                            trailerHookOffset = GetObjectOffsetFromCoords(trailerBonePos.x, trailerBonePos.y, trailerBonePos.z, trailerHeading, 0, 8.0, -0.5)
                            hasKnownHookBones = true
                        else
                            if GetEntityModel(vehicleUnderPed) == 1204003331 then
                                local truckBonePos = GetWorldPositionOfEntityBone(
                                    vehicleUnderPed, GetEntityBoneIndexByName(vehicleUnderPed, "hook")
                                )
                                local trailerBonePos = GetWorldPositionOfEntityBone(
                                    trailer, GetEntityBoneIndexByName(trailer, "hook")
                                )
                                truckHookOffset = GetObjectOffsetFromCoords(truckBonePos.x, truckBonePos.y, truckBonePos.z, truckHeading, 0, -3.25, 1.0)
                                trailerHookOffset = GetObjectOffsetFromCoords(trailerBonePos.x, trailerBonePos.y, trailerBonePos.z, trailerHeading, 0, 8.0, -0.5)
                                hasKnownHookBones = true
                            end
                        end

                        if hasKnownHookBones then
                            local hookDiffX = math.abs(truckHookOffset.x - trailerHookOffset.x)
                            local hookDiffY = math.abs(truckHookOffset.y - trailerHookOffset.y)

                            local truckCoords = GetEntityCoords(vehicleUnderPed)
                            local trailerCoords = GetEntityCoords(trailer)
                            local vehicleDiffX = math.abs(truckCoords.x - trailerCoords.x)
                            local vehicleDiffY = math.abs(truckCoords.y - trailerCoords.y)

                            if vehicleDiffX > 12 or vehicleDiffY > 12 then
                                DetachVehicleFromTrailer(vehicleUnderPed)
                            else
                                AttachVehicleToTrailer(vehicleUnderPed, trailer, 10.0)
                            end

                            if hookDiffX >= 2.0 or hookDiffY >= 2.0 then
                                print("DETACHING TRAILER TO AVOID DESYNC")
                                DetachVehicleFromTrailer(vehicleUnderPed)
                            end
                        end
                    end
                end

                Wait(1000)
            end
        end)
    end

    PickupActionBusy = false
    PickupActionObject = 0

    local notifiedLoadOnFlatbed = false

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            SetEntityVisible(HeldLogObject, false, false)
            SetEntityCollision(HeldLogObject, false, true)

            if not PickupActionBusy then
                if DoesEntityExist(JobVehicles.JobForklift) then
                    if GetVehiclePedIsIn(PlayerPedId(), false) == JobVehicles.JobForklift then
                        local forksAttachPos = GetWorldPositionOfEntityBone(
                            JobVehicles.JobForklift, GetEntityBoneIndexByName(JobVehicles.JobForklift, "forks_attach")
                        )

                        for plankId, plank in pairs(PlanksSpawnPoints) do
                            if plank.obj ~= nil then
                                local plankCoords = GetEntityCoords(plank.obj)

                                if #(forksAttachPos.xy - plankCoords.xy) <= 1.2 then
                                    if forksAttachPos.z - plankCoords.z > -0.2 then
                                        if forksAttachPos.z - plankCoords.z < 0.0 then
                                            if not DecorGetBool(plank.obj, "entityOnForks") then
                                                if plank.haveAbove == false or plank.haveAbove == nil then
                                                    pollInterval = 0

                                                    SetEntityDrawOutline(plank.obj, true)
                                                    SetEntityDrawOutlineColor(171, 91, 41, 200)
                                                    ShowHelpNotification(Config.Lang.attachPlanksToForklift)

                                                    if IsControlJustReleased(0, 38) then
                                                        SetEntityDrawOutline(plank.obj, false)

                                                        local oldPlankObj = plank.obj

                                                        plank.obj = CreateObject(
                                                            "17mov_woodpile",
                                                            PlanksSpawnPoints[plankId].coords.x,
                                                            PlanksSpawnPoints[plankId].coords.y,
                                                            PlanksSpawnPoints[plankId].coords.z,
                                                            true, true, false
                                                        )
                                                        SetEntityCollision(plank.obj, false, true)

                                                        SetEntityRotation(
                                                            plank.obj,
                                                            PlanksSpawnPoints[plankId].rotation.x,
                                                            PlanksSpawnPoints[plankId].rotation.y,
                                                            PlanksSpawnPoints[plankId].rotation.z,
                                                            0, false
                                                        )

                                                        local networkDeadline = GetGameTimer() + 5000
                                                        while GetGameTimer() < networkDeadline do
                                                            local netIdCheck = ObjToNet(plank.obj)
                                                            if netIdCheck ~= plank.obj and netIdCheck ~= 0 then
                                                                break
                                                            end

                                                            DeleteEntity(plank.obj)
                                                            plank.obj = CreateObject(
                                                                "17mov_woodpile",
                                                                PlanksSpawnPoints[plankId].coords.x,
                                                                PlanksSpawnPoints[plankId].coords.y,
                                                                PlanksSpawnPoints[plankId].coords.z,
                                                                true, true, false
                                                            )
                                                            SetEntityCollision(plank.obj, false, true)
                                                            SetEntityRotation(
                                                                plank.obj,
                                                                PlanksSpawnPoints[plankId].rotation.x,
                                                                PlanksSpawnPoints[plankId].rotation.y,
                                                                PlanksSpawnPoints[plankId].rotation.z,
                                                                0, false
                                                            )
                                                            Wait(100)
                                                        end

                                                        DeleteEntity(oldPlankObj)
                                                        DecorSetBool(plank.obj, "entityOnForks", true)
                                                        AttachEntityToEntity(
                                                            plank.obj, JobVehicles.JobForklift, 3,
                                                            0.0, 1.15, -0.6, 0.0, -3.5, 90.0,
                                                            false, false, false, false, 2, true
                                                        )

                                                        for otherPlankId, otherPlank in pairs(PlanksSpawnPoints) do
                                                            if otherPlank.aboveId == plankId then
                                                                TriggerServerEvent("17mov_Lumberjack:EnableViaAboveLift", otherPlankId)
                                                            end
                                                        end

                                                        TriggerServerEvent("17mov_Lumberjack:ForkliftUpdate", ObjToNet(plank.obj), plankId)

                                                        PickupActionBusy = true
                                                        plank.obj = nil

                                                        if not notifiedLoadOnFlatbed then
                                                            notifiedLoadOnFlatbed = true
                                                            Notify(Config.Lang.loadItOnFlatbed)
                                                        end
                                                    end
                                                end

                                            end
                                        end
                                    end
                                else
                                    SetEntityDrawOutline(plank.obj, false)
                                end
                            end
                        end
                    end
                else

                    if GetLogOnTrailerCount() == 0 then
                        if GetLastSkipSlot() == 1 then
                            if DoesEntityExist(JobVehicles.JobForklift) then
                                if GetVehiclePedIsIn(PlayerPedId(), false) == JobVehicles.JobForklift then
                                    if GetLastPlanksSlot() ~= 0 then
                                        local flatbedWaitStart = GetGameTimer()

                                        local skipRecreateGhost = true
                                        if HeldLogObject ~= 0 then
                                            if DoesEntityExist(HeldLogObject) then
                                                skipRecreateGhost = false
                                            end
                                        end

                                        if skipRecreateGhost then
                                            if DoesEntityExist(JobVehicles.JobFlatbed) then
                                                NetworkRequestControlOfEntity(JobVehicles.JobFlatbed)
                                                while true do
                                                    if NetworkHasControlOfEntity(JobVehicles.JobFlatbed) then
                                                        break
                                                    end
                                                    if GetGameTimer() - flatbedWaitStart > 500 then
                                                        break
                                                    end
                                                    Wait(100)
                                                end

                                                local flatbedCoords = GetEntityCoords(JobVehicles.JobFlatbed)
                                                HeldLogObject = CreateObject(
                                                    "17mov_woodpile",
                                                    flatbedCoords.x, flatbedCoords.y, flatbedCoords.z,
                                                    false, true, false
                                                )
                                                SetEntityVisible(HeldLogObject, false, false)
                                                SetEntityCollision(HeldLogObject, false, true)
                                                AttachEntityToEntity(
                                                    HeldLogObject, JobVehicles.JobFlatbed, 0,
                                                    Config.HintPlankAttachment.offset.x,
                                                    Config.HintPlankAttachment.offset.y,
                                                    Config.HintPlankAttachment.offset.z,
                                                    Config.HintPlankAttachment.rotation.x,
                                                    Config.HintPlankAttachment.rotation.y,
                                                    Config.HintPlankAttachment.rotation.z,
                                                    true, true, true, true, 2, true
                                                )
                                            end
                                        end

                                        local ghostDistanceFromFlatbed = #(
                                            GetEntityCoords(HeldLogObject) - GetEntityCoords(JobVehicles.JobFlatbed)
                                        )

                                        local ghostStillValid = true
                                        if ghostDistanceFromFlatbed > 15.0 then
                                            ghostStillValid = false
                                        else
                                            ghostStillValid = IsEntityAttachedToEntity(HeldLogObject, JobVehicles.JobFlatbed)
                                        end

                                        if ghostStillValid then

                                            SetEntityDrawOutlineColor(171, 91, 41, 200)
                                            SetEntityDrawOutline(HeldLogObject, true)

                                            local ghostTargetOffset = GetOffsetFromEntityInWorldCoords(
                                                JobVehicles.JobFlatbed,
                                                Config.HintPlankAttachment.offset.x,
                                                Config.HintPlankAttachment.offset.y,
                                                Config.HintPlankAttachment.offset.z
                                            )

                                            if #(GetEntityCoords(PickupActionObject) - ghostTargetOffset) < 2.5 then
                                                SetEntityDrawOutlineColor(41, 171, 50, 200)
                                                ShowHelpNotification(Config.Lang.loadPallete)

                                                if IsControlJustReleased(0, 38) then
                                                    DetachEntity(PickupActionObject, true, true)
                                                    AttachPalleteToTrailer(PickupActionObject, GetLastPlanksSlot())
                                                    SetEntityDrawOutlineColor(171, 91, 41, 200)
                                                    PickupActionBusy = false

                                                    if ProcessedPlanksCount == GetPlanksOnTrailerCount() + 1
                                                        or GetPlanksOnTrailerCount() + 1 >= 9 then
                                                        TaskLeaveAnyVehicle(PlayerPedId(), 1, 0)
                                                        NetworkRequestControlOfEntity(JobVehicles.JobForklift)
                                                        Wait(1500)
                                                        DeleteVehicleByCore(JobVehicles.JobForklift)
                                                        TriggerServerEvent("17mov_Lumberjack:ForkliftDeleted")
                                                    end

                                                    pollInterval = 0
                                                end

                                            end
                                        else
                                            DeleteEntity(HeldLogObject)
                                            HeldLogObject = 0

                                        end
                                    else
                                        SetEntityDrawOutline(HeldLogObject, false)
                                    end
                                end
                            end
                        end
                    else
                        SetEntityDrawOutline(HeldLogObject, false)
                    end
                end
            end

            Wait(pollInterval)
        end
    end)

    do
        local logForksBoneIndex = GetEntityBoneIndexByName(JobVehicles.JobVehicle, "forks_attach")

        local outlinedLogObject = 0
        local lastClosestLogId = nil

        CreateThread(function()
            while OnDuty do
                local pollInterval = 1000

                local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)

                if vehicleUnderPed ~= nil and vehicleUnderPed ~= 0 then

                    if PendingSkipObjForVehicle1 == 0 then
                        local isJobVehicle1 = JobVehicles.JobVehicle == vehicleUnderPed
                        local isJobVehicle2 = JobVehicles.JobVehicle2 == vehicleUnderPed

                        if isJobVehicle1 or isJobVehicle2 then
                            if GetLastSkipSlot() == 1 then
                                if GetLastPlanksSlot() == 1 then
                                    local freeForksSlots, freeForksSlotIndex = GetFreeForksSlots(isJobVehicle2)

                                    if freeForksSlots >= 1 then
                                        pollInterval = 250

                                        local forksBonePos = GetWorldPositionOfEntityBone(vehicleUnderPed, logForksBoneIndex)
                                        local closestLogId = GetClosestLog(forksBonePos)

                                        if closestLogId ~= lastClosestLogId then
                                            SetEntityDrawOutline(outlinedLogObject, false)
                                        end

                                        if closestLogId ~= 0 then
                                            if not DecorGetBool(closestLogId, "entityOnForks") then
                                                pollInterval = 0
                                                outlinedLogObject = closestLogId

                                                SetEntityDrawOutline(outlinedLogObject, true)
                                                SetEntityDrawOutlineColor(171, 91, 41, 200)
                                                ShowHelpNotification(Config.Lang.attachLogToLoader)

                                                if IsControlJustReleased(0, 38) then
                                                    if RequestEntityControl(closestLogId, 1000) then
                                                        local sourceLogNetId = NetworkGetNetworkIdFromEntity(closestLogId)
                                                        if isJobVehicle1 then
                                                            TriggerServerEvent(
                                                                "17mov_Lumberjack:AttachLogToLumberCar",
                                                                freeForksSlotIndex, JobVehicleNetIds.JobVehicle,
                                                                isJobVehicle2, sourceLogNetId
                                                            )
                                                        else
                                                            TriggerServerEvent(
                                                                "17mov_Lumberjack:AttachLogToLumberCar",
                                                                freeForksSlotIndex, JobVehicleNetIds.JobVehicle2,
                                                                isJobVehicle2, sourceLogNetId
                                                            )
                                                        end

                                                        DeleteEntity(closestLogId)
                                                    else
                                                        Notify(Config.Lang.wentWrong)
                                                    end
                                                end
                                            end
                                        end

                                        lastClosestLogId = closestLogId
                                    end
                                end
                            end
                        end
                    end
                end

                Wait(pollInterval)
            end
        end)
    end

    local forksGhostSlotB = nil
    local forksGhostSlotA = nil

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            SetEntityDrawOutlineShader(1)

            local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)
            local isJobVehicle1 = JobVehicles.JobVehicle == vehicleUnderPed
            local isJobVehicle2 = JobVehicles.JobVehicle2 == vehicleUnderPed

            SetEntityDrawOutline(forksGhostSlotB, false)
            SetEntityDrawOutline(forksGhostSlotA, false)
            SetEntityVisible(forksGhostSlotB, false, false)
            SetEntityVisible(forksGhostSlotA, false, false)

            if isJobVehicle1 or isJobVehicle2 then
                if GetEntitySpeed(JobVehicles.JobFlatbed) < 50.0 then
                    local forksAttachmentConfig = Config.ForksAttachment
                    local logsOnForksCount, logsOnForksSlot = GetLastLogOnForks()

                    if isJobVehicle2 then
                        forksAttachmentConfig = Config.ForksAttachment2
                        logsOnForksCount, logsOnForksSlot = GetLastLogOnForks2()
                    end

                    if logsOnForksCount ~= 0 then
                        if GetTrailerFreeSlot() ~= 0 then
                            if GetLastSkipSlot() == 1 then
                                if GetLastPlanksSlot() == 1 then
                                    local forksBonePos = GetWorldPositionOfEntityBone(
                                        vehicleUnderPed, GetEntityBoneIndexByName(JobVehicles.JobVehicle, "forks_attach")
                                    )

                                    local ghostBCoords = GetEntityCoords(forksGhostSlotB)
                                    local ghostACoords = GetEntityCoords(forksGhostSlotA)

                                    local canDropHere = false
                                    local distToGhostB = #(forksBonePos.xy - ghostBCoords.xy)
                                    local distToGhostA = #(forksBonePos.xy - ghostACoords.xy)

                                    if distToGhostB < distToGhostA then
                                        if distToGhostB < 1.5 then
                                            if forksBonePos.z - ghostBCoords.z > -1.0 then
                                                if forksBonePos.z - ghostBCoords.z < 2.5 then
                                                    SetEntityDrawOutlineColor(41, 171, 50, 200)
                                                    SetEntityDrawOutline(forksGhostSlotB, true)
                                                    canDropHere = true
                                                end
                                            end
                                        else
                                            SetEntityDrawOutlineColor(171, 91, 41, 200)
                                            SetEntityDrawOutline(forksGhostSlotB, true)
                                        end
                                    else
                                        if distToGhostA < 1.5 then
                                            if forksBonePos.z - ghostACoords.z > -1.4 then
                                                if forksBonePos.z - ghostACoords.z < 2.5 then
                                                    SetEntityDrawOutlineColor(41, 171, 50, 200)
                                                    SetEntityDrawOutline(forksGhostSlotA, true)
                                                    canDropHere = true
                                                end
                                            end
                                        else
                                            SetEntityDrawOutlineColor(171, 91, 41, 200)
                                            SetEntityDrawOutline(forksGhostSlotA, true)
                                        end
                                    end

                                    if canDropHere then
                                        ShowHelpNotification(Config.Lang.putLogOnLoader)

                                        if IsControlJustReleased(0, 38) then
                                            if DoesEntityExist(forksAttachmentConfig[logsOnForksSlot].obj) then
                                                DeleteEntity(forksAttachmentConfig[logsOnForksSlot].obj)
                                                TriggerServerEvent(
                                                    "17mov_Lumberjack:DetachObjFromLumber",
                                                    logsOnForksSlot, isJobVehicle2 == true,
                                                    isJobVehicle2 and JobVehicleNetIds.JobVehicle2 or JobVehicleNetIds.JobVehicle
                                                )
                                                AttachLogOnTrailer(logsOnForksCount)
                                                SetEntityDrawOutlineColor(171, 91, 41, 200)
                                            end
                                        end
                                    end

                                    pollInterval = 0
                                end
                            end
                        end
                    end
                end
            end

            Wait(pollInterval)
        end
    end)

    local lastForksGhostRecreateTime = 0

    CreateThread(function()
        local logModelHash = Config.Props.logs.hash

        if not LoadModelWithTimeout(logModelHash) then return end

        while OnDuty do
            local ghostBTooFar = #(GetEntityCoords(forksGhostSlotB) - GetEntityCoords(JobVehicles.JobFlatbed)) > 10
            local ghostATooFar = #(GetEntityCoords(forksGhostSlotA) - GetEntityCoords(JobVehicles.JobFlatbed)) > 10

            if ghostBTooFar or ghostATooFar then
                if forksGhostSlotB ~= nil and ghostBTooFar then
                    DeleteEntity(forksGhostSlotB)
                end
                if forksGhostSlotA ~= nil and ghostATooFar then
                    DeleteEntity(forksGhostSlotA)
                end

                if GetGameTimer() - lastForksGhostRecreateTime >= 5000 then
                    local controlWaitStart = GetGameTimer()

                    NetworkRequestControlOfEntity(JobVehicles.JobFlatbed)
                    while true do
                        if NetworkHasControlOfEntity(JobVehicles.JobFlatbed) then
                            break
                        end
                        if GetGameTimer() - controlWaitStart > 500 then
                            break
                        end
                        Wait(100)
                    end

                    local flatbedCoords = GetEntityCoords(JobVehicles.JobFlatbed)

                    if #flatbedCoords ~= 0 then
                        local newGhost = CreateObject(
                            logModelHash, flatbedCoords.x, flatbedCoords.y, flatbedCoords.z,
                            false, true, false
                        )

                        if ghostBTooFar then
                            AttachEntityToEntity(
                                newGhost, JobVehicles.JobFlatbed,
                                GetEntityBoneIndexByName(JobVehicles.JobFlatbed, "bodyshell"),
                                1.7, 0.0, 1.5, 0.0, 0.0, 0.0,
                                true, true, false, false, 2, true
                            )
                            forksGhostSlotB = newGhost
                        elseif ghostATooFar then
                            AttachEntityToEntity(
                                newGhost, JobVehicles.JobFlatbed,
                                GetEntityBoneIndexByName(JobVehicles.JobFlatbed, "bodyshell"),
                                -1.7, 0.0, 1.5, 0.0, 0.0, 0.0,
                                true, true, false, false, 2, true
                            )
                            forksGhostSlotA = newGhost
                        end

                        FreezeEntityPosition(newGhost, true)
                        SetEntityVisible(newGhost, false, false)
                        DecorSetBool(newGhost, "entityOnForks", true)

                        lastForksGhostRecreateTime = GetGameTimer()
                        Wait(500)

                        if #GetEntityCoords(newGhost) == 0 then
                            DetachEntity(newGhost, true, false)
                            DeleteEntity(newGhost)
                        end
                    end
                end
            end

            Wait(100)
        end
    end)

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            if GetLastLogOnForks() == 0 then
                if not ChipsThreadRunning then
                    local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)

                    if vehicleUnderPed ~= 0 then
                        if JobVehicles.JobVehicle == vehicleUnderPed or JobVehicles.JobVehicle2 == vehicleUnderPed then
                            local forksAttachBone = GetEntityBoneIndexByName(vehicleUnderPed, "forks_attach")
                            local forksAttachPos = GetWorldPositionOfEntityBone(vehicleUnderPed, forksAttachBone)
                            local isJobVehicle2 = JobVehicles.JobVehicle2 == vehicleUnderPed

                            for skipId, skip in pairs(SkipsSpawnPoints) do
                                local skipCoords = GetEntityCoords(skip.obj)
                                SetEntityDrawOutline(skip.obj, false)

                                if #(skipCoords.xy - forksAttachPos.xy) < 2.0 then
                                    pollInterval = 13

                                    if skip.currActiveSkip then
                                        if skip.percentage > 0 then
                                            ShowHelpNotification(Config.Lang.AttachSkip)
                                            SetEntityDrawOutlineColor(171, 91, 41, 200)
                                            SetEntityDrawOutline(skip.obj, true)

                                            if IsControlJustReleased(0, 38) then
                                                SetEntityDrawOutline(skip.obj, false)
                                                SetEntityCollision(skip.obj, false, false)

                                                local oldSkipCoords = GetEntityCoords(skip.obj)
                                                local oldSkipRotation = GetEntityRotation(skip.obj)
                                                local oldChipsCoords = GetEntityCoords(skip.chipsObj)
                                                local oldChipsRotation = GetEntityRotation(skip.chipsObj)

                                                local newSkipObj = CreateObject(
                                                    "17movement_skip",
                                                    oldSkipCoords.x, oldSkipCoords.y, oldSkipCoords.z,
                                                    true, true, false
                                                )
                                                SetEntityRotation(newSkipObj, oldSkipRotation.x, oldSkipRotation.y, oldSkipRotation.z, 0, false)
                                                SetEntityCollision(newSkipObj, false, false)

                                                local newChipsObj = CreateObject(
                                                    "17movement_chips",
                                                    oldChipsCoords.x, oldChipsCoords.y, oldChipsCoords.z,
                                                    true, true, false
                                                )
                                                SetEntityRotation(newChipsObj, oldChipsRotation.x, oldChipsRotation.y, oldChipsRotation.z, 0, false)
                                                SetEntityCollision(newChipsObj, false, false)

                                                AttachEntityToEntity(
                                                    newSkipObj, vehicleUnderPed, forksAttachBone,
                                                    SkipAttachOffset.coords.x, SkipAttachOffset.coords.y, SkipAttachOffset.coords.z,
                                                    SkipAttachOffset.rotation.x, SkipAttachOffset.rotation.y, SkipAttachOffset.rotation.z,
                                                    false, true, false, false, 2, true
                                                )
                                                AttachEntityToEntity(
                                                    newChipsObj, newSkipObj, 0,
                                                    skip.chipsAttachOffset.x, skip.chipsAttachOffset.y, skip.chipsAttachOffset.z,
                                                    0.0, 0.0, 0.0,
                                                    false, true, true, false, 2, true
                                                )

                                                local deleteDeadline = GetGameTimer() + 2000
                                                while GetGameTimer() < deleteDeadline do
                                                    if not DoesEntityExist(skip.obj) then
                                                        if not DoesEntityExist(skip.chipsObj) then
                                                            break
                                                        end
                                                    end
                                                    Citizen.Wait(10)
                                                    DeleteEntity(skip.obj)
                                                    DeleteEntity(skip.chipsObj)
                                                end

                                                local netIdWaitStart = GetGameTimer()
                                                local netIdsResolvedInTime = true
                                                local newSkipNetId = 0
                                                local newChipsNetId = 0

                                                while newSkipNetId == 0 or newSkipNetId == newSkipObj
                                                    or newChipsNetId == 0 or newChipsNetId == newChipsObj do
                                                    if newSkipNetId == 0 or newSkipNetId == newSkipObj then
                                                        newSkipNetId = ObjToNet(newSkipObj)
                                                    end
                                                    if newChipsNetId == 0 or newChipsNetId == newChipsObj then
                                                        newChipsNetId = ObjToNet(newChipsObj)
                                                    end

                                                    if GetGameTimer() - netIdWaitStart > 5000 then
                                                        netIdsResolvedInTime = false
                                                        break
                                                    end

                                                    Wait(50)
                                                end

                                                if netIdsResolvedInTime then
                                                    TriggerServerEvent(
                                                        "17mov_Lumberjack:AttachSkip",
                                                        skipId, newSkipNetId, newChipsNetId, isJobVehicle2
                                                    )
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end

            Wait(pollInterval)
        end
    end)

    CreateThread(function()
        while OnDuty do
            local pollInterval = 500

            FreezeEntityPosition(HeldPlankObject, true)
            SetEntityCollision(HeldPlankObject, false, true)
            SetEntityVisible(HeldPlankObject, false, false)

            if PendingSkipObjForVehicle1 ~= 0 or PendingSkipObjForVehicle2 ~= 0 then
                if HeldPlankObject == 0 then
                    if DoesEntityExist(JobVehicles.JobFlatbed) then
                        NetworkRequestControlOfEntity(JobVehicles.JobFlatbed)

                        local controlWaitStart = GetGameTimer()
                        while true do
                            if NetworkHasControlOfEntity(JobVehicles.JobFlatbed) then
                                break
                            end
                            if GetGameTimer() - controlWaitStart > 500 then
                                break
                            end
                            Wait(100)
                        end

                        local flatbedCoords = GetEntityCoords(JobVehicles.JobFlatbed)
                        HeldPlankObject = CreateObject(
                            "17movement_skip",
                            flatbedCoords.x, flatbedCoords.y, flatbedCoords.z,
                            false, true, false
                        )
                        AttachEntityToEntity(
                            HeldPlankObject, JobVehicles.JobFlatbed, 0,
                            Config.HintSkip.offset.x, Config.HintSkip.offset.y, Config.HintSkip.offset.z,
                            Config.HintSkip.rotation.x, Config.HintSkip.rotation.y, Config.HintSkip.rotation.z,
                            true, true, true, true, 2, true
                        )
                    end
                end

                local ghostDistanceFromFlatbed = #(
                    GetEntityCoords(HeldPlankObject) - GetEntityCoords(JobVehicles.JobFlatbed)
                )
                local ghostStillValid = true
                if ghostDistanceFromFlatbed > 15.0 then
                    ghostStillValid = false
                else
                    ghostStillValid = IsEntityAttachedToEntity(HeldPlankObject, JobVehicles.JobFlatbed)
                end

                if not ghostStillValid then
                    DeleteEntity(HeldPlankObject)
                    HeldPlankObject = 0
                end

                if DoesEntityExist(HeldPlankObject) then
                    FreezeEntityPosition(HeldPlankObject, true)
                    SetEntityCollision(HeldPlankObject, false, true)
                    SetEntityVisible(HeldPlankObject, false, false)
                    SetEntityDrawOutline(HeldPlankObject, false)

                    local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)
                    local isJobVehicle1 = vehicleUnderPed == JobVehicles.JobVehicle
                    local isJobVehicle2 = vehicleUnderPed == JobVehicles.JobVehicle2

                    if GetLogOnTrailerCount() == 0 then
                        if GetPlanksOnTrailerCount() == 0 and (isJobVehicle1 or isJobVehicle2) then
                            local lastSkipSlot = GetLastSkipSlot()

                            if lastSkipSlot ~= 0 then
                                local hintPos = GetOffsetFromEntityInWorldCoords(
                                    JobVehicles.JobFlatbed,
                                    Config.HintSkip.offset.x, Config.HintSkip.offset.y, Config.HintSkip.offset.z
                                )

                                SetEntityDrawOutlineColor(171, 91, 41, 200)
                                SetEntityDrawOutline(HeldPlankObject, true)

                                local closeEnoughToDrop = #(hintPos - GetEntityCoords(PendingSkipObjForVehicle1)) < 2.5
                                if not closeEnoughToDrop then
                                    closeEnoughToDrop = #(hintPos - GetEntityCoords(PendingSkipObjForVehicle2)) < 2.5
                                end

                                if closeEnoughToDrop then
                                    ShowHelpNotification(Config.Lang.attachSkipToTrailer)
                                    SetEntityDrawOutlineColor(41, 171, 50, 200)

                                    if IsControlJustReleased(0, 38) then
                                        SetEntityDrawOutlineColor(171, 91, 41, 200)
                                        SetEntityDrawOutline(HeldPlankObject, false)

                                        if isJobVehicle1 then
                                            AttachSkipToTrailer(PendingSkipObjForVehicle1, PendingChipsObjForVehicle1, lastSkipSlot)
                                            PendingSkipObjForVehicle1 = 0
                                            PendingChipsObjForVehicle1 = 0
                                        end
                                        if isJobVehicle2 then
                                            AttachSkipToTrailer(PendingSkipObjForVehicle2, PendingChipsObjForVehicle2, lastSkipSlot)
                                            PendingSkipObjForVehicle2 = 0
                                            PendingChipsObjForVehicle2 = 0
                                        end

                                        PickupActionBusy = false
                                    end

                                    pollInterval = 0
                                end
                            end
                        end
                    end
                end
            end

            Wait(pollInterval)
        end
    end)

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)

            for stationType, stationParts in pairs(Config.Stations) do
                for partIndex = 1, #stationParts do
                    local part = stationParts[partIndex]
                    local distanceToPart = #(GetEntityCoords(vehicleUnderPed) - part.coords.xyz)

                    if distanceToPart < 50.0 then
                        if not Carrying3DBox then

                            local lateralDistance = math.abs(#(part.coords.xy - GetEntityCoords(vehicleUnderPed).xy))

                            if lateralDistance < 5.2 then
                                local facingOk = SimilarOrientation(GetEntityHeading(vehicleUnderPed), part.targetHeading, 12.5)

                                if not facingOk then
                                    Draw3DBox(
                                        part.coords.x, part.coords.y, part.coords.z,
                                        12.0, 3.5, 4.0,
                                        171, 91, 41, 100,
                                        part.rotation
                                    )
                                end

                                if facingOk then

                                    local isDriverOrNonLegacy = facingOk
                                    if Config.EnableVehicleLegacyMode then
                                        isDriverOrNonLegacy = GetPedInVehicleSeat(JobVehicles.JobVehicle, -1) == PlayerPedId()
                                    end

                                    Draw3DBox(
                                        part.coords.x, part.coords.y, part.coords.z,
                                        12.0, 3.5, 4.0,
                                        0, 255, 0, 100,
                                        part.rotation
                                    )

                                    if isDriverOrNonLegacy then
                                        ShowHelpNotification(Config.Lang.OpenProcessingMenu)

                                        if IsControlJustReleased(0, 38) then
                                            local price = nil

                                            if stationType:sub(1, 4) == "sell" then
                                                local priceAwaiter = promise.new()
                                                TriggerServerCallback("17mov_Lumberjack:GetPrice", function(fetchedPrice)
                                                    priceAwaiter:resolve(fetchedPrice)
                                                end, partIndex, stationType)
                                                price = Citizen.Await(priceAwaiter)
                                            end

                                            local panelArgs = {}

                                            if stationType == "processToPlanks" then
                                                table.insert(panelArgs, Config.EnableVehicleLegacyMode and "6" or "8")
                                                table.insert(panelArgs, math.floor(
                                                    GetLogOnTrailerCount() / (Config.EnableVehicleLegacyMode and 6 or 8)
                                                ))
                                                table.insert(panelArgs, Config.EnableVehicleLegacyMode and "9" or "4")
                                            end

                                            if stationType == "processToChips" then
                                                table.insert(panelArgs, Config.EnableVehicleLegacyMode and "5" or "6.25")
                                                table.insert(panelArgs, Config.EnableVehicleLegacyMode and "3" or "2")
                                            end

                                            if price ~= nil then
                                                table.insert(panelArgs, price)
                                            end

                                            OpenPanel(stationType, panelArgs)
                                        end
                                    end
                                end
                            else
                                Draw3DBox(
                                    part.coords.x, part.coords.y, part.coords.z,
                                    12.0, 3.5, 4.0,
                                    171, 91, 41, 100,
                                    part.rotation
                                )
                            end
                        else
                            Draw3DBox(
                                part.coords.x, part.coords.y, part.coords.z,
                                12.0, 3.5, 4.0,
                                171, 91, 41, 100,
                                part.rotation
                            )
                        end
                    else
                        Draw3DBox(
                            part.coords.x, part.coords.y, part.coords.z,
                            12.0, 3.5, 4.0,
                            171, 91, 41, 100,
                            part.rotation
                        )
                    end

                    pollInterval = 0
                end
            end

            Wait(pollInterval)
        end
    end)

    local lastTargetedTreeId = 0

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            local myCoords = GetEntityCoords(PlayerPedId())
            local closestTreeId = 0
            local closestDistance = 2.0

            for treeId, tree in pairs(TreesData) do
                if tree.isAvalible then
                    local distance = #(myCoords - tree.coords)
                    if closestDistance > distance then
                        closestDistance = distance
                        closestTreeId = treeId
                    end
                end
            end

            if Config.UseTarget then
                if closestTreeId ~= lastTargetedTreeId then
                    DeleteTreeFromTarget(lastTargetedTreeId)
                    if TreeTargetsAdded[lastTargetedTreeId] then
                        TreeTargetsAdded[lastTargetedTreeId] = nil
                    end
                end
            end

            if closestTreeId ~= 0 then
                local tree = TreesData[closestTreeId]

                if Config.UseTarget == false then
                    if CurrentHoldingController == nil then
                        pollInterval = 0

                        local offset = GetOffsetFromEntityInWorldCoords(tree.obj, 0.0, 0.05, 0.0)
                        DrawMarker(
                            6, offset.x, offset.y, myCoords.z,
                            0.0, 0.0, 0.0,
                            -90, 0.0, 0.0,
                            1.3, 1.3, 1.3,
                            Config.MarkerSettings.UnActive.r, Config.MarkerSettings.UnActive.g,
                            Config.MarkerSettings.UnActive.b, Config.MarkerSettings.UnActive.a,
                            false, false, false, false, nil, nil, false
                        )
                        ShowHelpNotification(Config.Lang.treeCutting)

                        if IsControlJustReleased(0, 38) then
                            if CurrentLogCounter >= 12 then
                                Notify(Config.Lang.tooManyLogs)
                            else
                                CutDownTree(closestTreeId)
                            end
                        end
                    end
                else
                    if Config.UseTarget then
                        if not TreeTargetsAdded[closestTreeId] then
                            lastTargetedTreeId = closestTreeId
                            TreeTargetsAdded[closestTreeId] = true
                            AddTreeToTarget(tree.obj, closestTreeId)
                        end
                    end
                end
            end

            Wait(pollInterval)
        end
    end)

    CreateThread(function()
        while OnDuty do
            local pollInterval = 1000

            local myCoords = GetEntityCoords(PlayerPedId())
            local vehicleUnderPed = GetVehiclePedIsIn(PlayerPedId(), false)
            local allObjects = GetGamePool("CObject")

            local cranePartNames = {}
            cranePartNames[-1436027651] = "control"
            cranePartNames[91512090] = "base"
            cranePartNames[-844957414] = "boom"
            cranePartNames[-203303706] = "stick1"
            cranePartNames[103545210] = "stick2"
            cranePartNames[1135801411] = "stick3"
            cranePartNames[-1277810458] = "hook"
            cranePartNames[2069585976] = "grab1"
            cranePartNames[687258484] = "grab2"

            for i = 1, #allObjects do
                local obj = allObjects[i]

                local onForksFlag = DecorGetBool(obj, "entityOnForks")
                if not IsEntityVisible(obj) and onForksFlag then
                    if not IsEntityAttachedToAnyObject(obj) then
                        if not IsEntityAttachedToAnyVehicle(obj) then
                            if not IsEntityAttachedToAnyPed(obj) then
                                DeleteEntity(obj)
                            end
                        end
                    end
                end

                local objModel = GetEntityModel(obj)
                GetGameTimer()

                if objModel == chipsPropHash then
                    local attachedTo = GetEntityAttachedTo(obj)
                    local attachedModel = GetEntityModel(attachedTo)
                    if attachedModel ~= logPropHash and attachedModel ~= 1242069632 then
                        DeleteEntity(obj)
                    end
                end

                local isCraneContent = DecorGetBool(obj, "isCraneContent")
                if isCraneContent then
                    local stillAttached = IsEntityAttachedToAnyVehicle(obj)
                    if not stillAttached then
                        stillAttached = IsEntityAttachedToAnyObject(obj)
                    end

                    if stillAttached then
                        local attachedTo = GetEntityAttachedTo(obj)
                        local attachedModel = GetEntityModel(attachedTo)
                        if attachedTo ~= 0 and attachedModel ~= -184773924
                            and attachedModel ~= logPropHash and attachedModel ~= 1242069632 then
                            DeleteEntity(obj)
                        end
                    else
                        DeleteEntity(obj)
                    end
                end

                local cranePartName = cranePartNames[objModel]
                if cranePartName then
                    local belongsToTrackedCrane = false
                    for _, craneEntry in pairs(Cranes) do
                        if craneEntry.crane then
                            if craneEntry.crane[cranePartName] == obj then
                                belongsToTrackedCrane = true
                            end
                        end
                    end
                    if not belongsToTrackedCrane then
                        DeleteEntity(obj)
                    end
                end

                if vehicleUnderPed == 0 then
                    if objModel == Config.Props.logs.hash and not onForksFlag then
                        local logOwner = Entity(obj).state["17mov_Lumberjack:LogOwnedBy"]
                        if logOwner == CurrentLobbyHost then
                            local objCoords = GetEntityCoords(obj)
                            if #(myCoords - objCoords) < 4.0 then
                                DrawText3Ds(objCoords.x, objCoords.y, objCoords.z, Config.Lang.useLogLoader)
                                pollInterval = 0
                            end
                        end
                    end
                end
            end

            if vehicleUnderPed == 0 then
                for _, skip in pairs(SkipsSpawnPoints) do
                    if skip.currActiveSkip then
                        if skip.percentage > 0 then
                            local skipCoords = GetEntityCoords(skip.obj)
                            if #(myCoords - skipCoords) < 4.0 then
                                if ChipsThreadRunning or ChipsActionBusy then
                                    DrawText3Ds(skipCoords.x, skipCoords.y, skipCoords.z + 1.5, Config.Lang.WaitUntilFullLoad)
                                else
                                    DrawText3Ds(skipCoords.x, skipCoords.y, skipCoords.z + 1.5, Config.Lang.useJobTractor)
                                end
                                pollInterval = 0
                            end
                        end
                    end
                end
            end

            Wait(pollInterval)
        end
    end)
end)

function GetNearbyVehicles(coords, radius)
    local allVehicles = GetGamePool("CVehicle")

    for i = 1, #allVehicles do
        if radius >= #(coords - GetEntityCoords(allVehicles[i])) then
            return false
        end
    end

    return true
end

RegisterNetEvent("17mov_Lumberjack:AttachSkip")
AddEventHandler("17mov_Lumberjack:AttachSkip", function(skipId, skipNetId, chipsNetId, isJobVehicle2)
    local skip = SkipsSpawnPoints[skipId]
    local networkSkip = WaitForNetworkObject(skipNetId, 5000)
    local networkChips = WaitForNetworkObject(chipsNetId, 5000)
    if skip == nil or networkSkip == 0 or networkChips == 0 then return end

    DeleteEntity(skip.obj)
    DeleteEntity(skip.chipsObj)
    skip.currActiveSkip = false
    skip.hasBeenLifted = true

    CreateThread(function()
        Wait(3000)

        local clearDeadline = GetGameTimer() + 30000
        while not GetNearbyVehicles(SkipsSpawnPoints[1].coords, 6.5)
            and GetGameTimer() < clearDeadline do
            Wait(500)
        end

        if not GetNearbyVehicles(SkipsSpawnPoints[1].coords, 6.5) then return end

        for otherSkipId, otherSkip in pairs(SkipsSpawnPoints) do
            if not otherSkip.currActiveSkip then
                if otherSkipId ~= skipId then
                    if otherSkip.hasBeenLifted == nil then
                        SetEntityCoords(
                            otherSkip.obj,
                            SkipsSpawnPoints[1].coords.x, SkipsSpawnPoints[1].coords.y, SkipsSpawnPoints[1].coords.z,
                            false, false, false, false
                        )
                        SetEntityRotation(
                            otherSkip.obj,
                            SkipsSpawnPoints[1].rotation.x, SkipsSpawnPoints[1].rotation.y, SkipsSpawnPoints[1].rotation.z,
                            0, false
                        )
                        SetEntityCollision(otherSkip.obj, true, true)
                        otherSkip.currActiveSkip = true
                        break
                    end
                end
            end
        end
    end)

    if isJobVehicle2 then
        if DoesEntityExist(JobVehicles.JobVehicle2) then
            PendingSkipObjForVehicle2 = networkSkip
            PendingChipsObjForVehicle2 = networkChips

            local attachDeadline = GetGameTimer() + 5000
            while DoesEntityExist(PendingSkipObjForVehicle2) and GetGameTimer() < attachDeadline do
                if IsEntityAttachedToEntity(PendingSkipObjForVehicle2, JobVehicles.JobVehicle2) then
                    break
                end

                NetworkRequestControlOfEntity(PendingSkipObjForVehicle2)
                DetachEntity(PendingSkipObjForVehicle2, true, true)

                local forksAttachBone = GetEntityBoneIndexByName(JobVehicles.JobVehicle2, "forks_attach")
                AttachEntityToEntity(
                    PendingSkipObjForVehicle2, JobVehicles.JobVehicle2, forksAttachBone,
                    SkipAttachOffset.coords.x, SkipAttachOffset.coords.y, SkipAttachOffset.coords.z,
                    SkipAttachOffset.rotation.x, SkipAttachOffset.rotation.y, SkipAttachOffset.rotation.z,
                    false, true, false, false, 2, true
                )

                Wait(250)
            end
        end
    else
        if DoesEntityExist(JobVehicles.JobVehicle) then
            PendingSkipObjForVehicle1 = networkSkip
            PendingChipsObjForVehicle1 = networkChips

            local attachDeadline = GetGameTimer() + 5000
            while DoesEntityExist(PendingSkipObjForVehicle1) and GetGameTimer() < attachDeadline do
                if IsEntityAttachedToEntity(PendingSkipObjForVehicle1, JobVehicles.JobVehicle) then
                    break
                end

                NetworkRequestControlOfEntity(PendingSkipObjForVehicle1)
                DetachEntity(PendingSkipObjForVehicle1, true, true)

                local forksAttachBone = GetEntityBoneIndexByName(JobVehicles.JobVehicle, "forks_attach")
                AttachEntityToEntity(
                    PendingSkipObjForVehicle1, JobVehicles.JobVehicle, forksAttachBone,
                    SkipAttachOffset.coords.x, SkipAttachOffset.coords.y, SkipAttachOffset.coords.z,
                    SkipAttachOffset.rotation.x, SkipAttachOffset.rotation.y, SkipAttachOffset.rotation.z,
                    false, true, false, false, 2, true
                )

                Wait(250)
            end
        end
    end
end)

ForksLogsByVehicleNetId = {}

RegisterNetEvent("17mov_Lumberjack:AttachLogToLumberCar")
AddEventHandler("17mov_Lumberjack:AttachLogToLumberCar", function(forksSlot, vehicleNetId, isJobVehicle2)
    local waitStartTime = GetGameTimer()
    local resolvedVehicle = 0
    local matchedTrackedVehicle = false

    for jobRoleKey, trackedNetId in pairs(JobVehicleNetIds) do
        if trackedNetId == vehicleNetId then
            resolvedVehicle = JobVehicles[jobRoleKey]
            matchedTrackedVehicle = true
        end
    end

    while resolvedVehicle == 0 or resolvedVehicle == vehicleNetId do
        resolvedVehicle = NetToVeh(vehicleNetId)

        if GetGameTimer() - waitStartTime > 5000 then
            return
        end

        Wait(100)
    end

    local createdLogObj = nil

    if DoesEntityExist(resolvedVehicle) then
        local forksAttachBoneIndex = GetEntityBoneIndexByName(resolvedVehicle, "forks_attach")
        local vehicleCoords = GetEntityCoords(resolvedVehicle)

        createdLogObj = CreateObject(
            Config.Props.logs.hash,
            vehicleCoords.x, vehicleCoords.y, vehicleCoords.z,
            false, true, true
        )

        AttachEntityToEntity(
            createdLogObj, resolvedVehicle, forksAttachBoneIndex,
            Config.ForksAttachment[forksSlot].offset.x, Config.ForksAttachment[forksSlot].offset.y, Config.ForksAttachment[forksSlot].offset.z,
            Config.ForksAttachment[forksSlot].rotation.x, Config.ForksAttachment[forksSlot].rotation.y, Config.ForksAttachment[forksSlot].rotation.z,
            true, true, true, false, 2, true
        )

        DecorSetBool(createdLogObj, "entityOnForks", true)

        if ForksLogsByVehicleNetId[vehicleNetId] == nil then
            ForksLogsByVehicleNetId[vehicleNetId] = {}
        end

        table.insert(ForksLogsByVehicleNetId[vehicleNetId], { obj = createdLogObj, slot = forksSlot })
    end

    if matchedTrackedVehicle then
        CurrentLogCounter = CurrentLogCounter - 1

        if isJobVehicle2 then
            Config.ForksAttachment2[forksSlot].obj = createdLogObj
        else
            Config.ForksAttachment[forksSlot].obj = createdLogObj
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:DetachObjFromLumber")
AddEventHandler("17mov_Lumberjack:DetachObjFromLumber", function(forksSlot, isJobVehicle2, vehicleNetId)
    local waitStartTime = GetGameTimer()
    local resolvedVehicle = 0
    local matchedTrackedVehicle = false

    for jobRoleKey, trackedNetId in pairs(JobVehicleNetIds) do
        if trackedNetId == vehicleNetId then
            resolvedVehicle = JobVehicles[jobRoleKey]
            matchedTrackedVehicle = true
        end
    end

    while resolvedVehicle == 0 or resolvedVehicle == vehicleNetId do
        resolvedVehicle = NetToVeh(vehicleNetId)

        if GetGameTimer() - waitStartTime > 5000 then
            return
        end

        Wait(100)
    end

    for trackedNetIdKey, _ in pairs(ForksLogsByVehicleNetId) do
        if trackedNetIdKey == vehicleNetId then
            local logsForVehicle = ForksLogsByVehicleNetId[trackedNetIdKey]

            if logsForVehicle then
                for logIndex = 1, #logsForVehicle do
                    local logEntry = ForksLogsByVehicleNetId[trackedNetIdKey][logIndex]

                    if logEntry then
                        if ForksLogsByVehicleNetId[trackedNetIdKey][logIndex].slot == forksSlot then
                            NetworkRequestControlOfNetworkId(vehicleNetId)
                            DeleteEntity(ForksLogsByVehicleNetId[trackedNetIdKey][logIndex].obj)
                            ForksLogsByVehicleNetId[trackedNetIdKey][logIndex] = nil
                        end
                    end
                end
            end
        end
    end

    if matchedTrackedVehicle then
        if isJobVehicle2 then
            NetworkRequestControlOfEntity(JobVehicles.JobVehicle2)
            DeleteEntity(Config.ForksAttachment2[forksSlot].obj)
            Config.ForksAttachment2[forksSlot].obj = nil
        else
            NetworkRequestControlOfEntity(JobVehicles.JobVehicle)
            DeleteEntity(Config.ForksAttachment[forksSlot].obj)
            Config.ForksAttachment[forksSlot].obj = nil
        end
    end
end)

RegisterNetEvent("17mov_lumberjack:SendVehicleToClients")
AddEventHandler("17mov_lumberjack:SendVehicleToClients", function(jobRoleKey, vehicleNetId)
    local waitStartTime = GetGameTimer()
    local resolvedVehicle = 0

    while resolvedVehicle == 0 or resolvedVehicle == vehicleNetId do
        resolvedVehicle = NetToVeh(vehicleNetId)

        if GetGameTimer() - waitStartTime > 5000 then
            return print("Failed to obtain vehicle ID from NetId", jobRoleKey)
        end

        Wait(100)
    end

    JobVehicles[jobRoleKey] = resolvedVehicle
    SetHornEnabled(resolvedVehicle, false)
    JobVehicleNetIds[jobRoleKey] = vehicleNetId

    CreateThread(function()
        while true do
            if not OnDuty then
                break
            end

            if NetworkDoesEntityExistWithNetworkId(JobVehicleNetIds[jobRoleKey]) then
                if JobVehicleNetIds[jobRoleKey] ~= 0 then
                    if JobVehicleNetIds[jobRoleKey] ~= nil then
                        local resolvedFromNetId = NetToVeh(JobVehicleNetIds[jobRoleKey])

                        if JobVehicles[jobRoleKey] ~= resolvedFromNetId then
                            if resolvedFromNetId ~= JobVehicleNetIds[jobRoleKey] then
                                JobVehicles[jobRoleKey] = NetToVeh(JobVehicleNetIds[jobRoleKey])
                                SetHornEnabled(JobVehicles[jobRoleKey], false)
                            end
                        end
                    end
                end
            end

            Citizen.Wait(5000)
        end
    end)

    if Config.GiveKeysToAllLobby then
        SetVehicle(resolvedVehicle)
    end
end)

function GetLastPlanksSlot()
    local foundSlot = 0

    for slotIndex, slotData in pairs(PlanksSpawnPoints) do
        if slotData.obj == nil then
            foundSlot = slotIndex
            break
        end
    end

    return foundSlot
end

function GetLastSkipSlot()
    local foundSlot = 0

    for slotIndex, slotData in pairs(SkipsSpawnPoints) do
        if slotData.obj == nil then
            foundSlot = slotIndex
            break
        end
    end

    return foundSlot
end

RegisterNetEvent("17mov_Lumberjack:DisableViaAboveSpawn")
AddEventHandler("17mov_Lumberjack:DisableViaAboveSpawn", function(planksSlot)
    PlanksSpawnPoints[planksSlot].haveAbove = false
end)

RegisterNetEvent("17mov_Lumberjack:EnableViaAboveLift")
AddEventHandler("17mov_Lumberjack:EnableViaAboveLift", function(planksSlot)
    PlanksSpawnPoints[planksSlot].haveAbove = false
    DeleteObject(PlanksSpawnPoints[PlanksSpawnPoints[planksSlot].aboveId].obj)
    PlanksSpawnPoints[PlanksSpawnPoints[planksSlot].aboveId].obj = nil
end)

RegisterNetEvent("17mov_Lumberjack:ForkliftUpdate")
AddEventHandler("17mov_Lumberjack:ForkliftUpdate", function(planksNetId, planksSlot)
    PickupActionBusy = true

    DeleteEntity(PlanksSpawnPoints[planksSlot].obj)
    PlanksSpawnPoints[planksSlot].obj = nil

    local waitTicks = 0

    while true do
        if NetToObj(planksNetId) ~= 0 then
            if NetToObj(planksNetId) ~= planksNetId then
                break
            end
        end

        Wait(10)

        waitTicks = waitTicks + 1

        if waitTicks > 250 then
            break
        end
    end

    PickupActionObject = NetToObj(planksNetId)
end)

function AttachSkipToTrailer(skipObj, chipsObj, skipId)
    local chipsAttachOffset = SkipsSpawnPoints[skipId].chipsAttachOffset

    PickupActionBusy = false

    NetworkRequestControlOfEntity(skipObj)
    NetworkRequestControlOfEntity(chipsObj)

    DeleteEntity(skipObj)
    DeleteEntity(chipsObj)

    TriggerServerEvent("17mov_Lumberjack:AttachSkipToTrailer", JobVehicleNetIds.JobFlatbed, skipId, chipsAttachOffset)
end

function AttachPalleteToTrailer(palleteObj, palleteId)
    PickupActionBusy = false

    NetworkRequestControlOfEntity(palleteObj)
    DeleteEntity(palleteObj)

    TriggerServerEvent("17mov_Lumberjack:AttachPallete", JobVehicleNetIds.JobFlatbed, palleteId)
end

function GetLastPlankLocationIndex()
    local foundSlot = 0

    for slotIndex, slotData in pairs(PlanksSpawnPoints) do
        if slotData.obj == nil then
            foundSlot = slotIndex
            break
        end
    end

    return foundSlot
end


SpawnLocalPlanksBusy = {}

RegisterNetEvent("17mov_Lumberjack:SpawnLocalPlanks")
AddEventHandler("17mov_Lumberjack:SpawnLocalPlanks", function(planksSlot)
    if planksSlot > 9 then
        return
    end

    if SpawnLocalPlanksBusy[planksSlot] then
        return
    end

    local woodpileHash = GetHashKey("17mov_woodpile")

    if not LoadModelWithTimeout(woodpileHash) then return end

    SpawnLocalPlanksBusy[planksSlot] = true

    local woodpileObj = CreateObject(
        woodpileHash,
        PlanksSpawnPoints[planksSlot].coords.x, PlanksSpawnPoints[planksSlot].coords.y, PlanksSpawnPoints[planksSlot].coords.z,
        false, true, true
    )

    SetEntityRotation(
        woodpileObj,
        PlanksSpawnPoints[planksSlot].rotation.x, PlanksSpawnPoints[planksSlot].rotation.y, PlanksSpawnPoints[planksSlot].rotation.z,
        0, false
    )

    FreezeEntityPosition(woodpileObj, true)

    PlanksSpawnPoints[planksSlot].obj = woodpileObj

    Entity(woodpileObj).state.myIndex = planksSlot
    Entity(woodpileObj).state.type = "planks"

    for _, slotData in pairs(PlanksSpawnPoints) do
        if slotData.aboveId == planksSlot then
            slotData.haveAbove = true
        end
    end

    Wait(1500)

    SpawnLocalPlanksBusy[planksSlot] = nil
end)

ActiveAnimations = {}
AnimationIdCounter = 1
AnimationThreadRunning = false

function AnimateObjectToPoint(object, point, duration, currentIndex, changeObject, spawnCoords, spawnRotation, animType)
    TriggerServerEvent("17mov_Lumberjack:StartAnimation", {
        spawnCoords, spawnRotation, point, duration, currentIndex, changeObject, object, animType
    })
end

function StartAnimation(animationData)
    local spawnCoords = animationData[1]
    local spawnRotation = animationData[2]
    local point = animationData[3]
    local duration = animationData[4]
    local currentIndex = animationData[5]
    local changeObject = animationData[6]
    local object = animationData[7]
    local animType = animationData[8]

    local logsHash = Config.Props.logs.hash

    if not LoadModelWithTimeout(logsHash) then return end

    if object == nil then
        object = CreateObject(logsHash, spawnCoords.x, spawnCoords.y, spawnCoords.z, false, true, false)

        DecorSetBool(object, "entityOnForks", true)
        SetEntityRotation(object, spawnRotation.x, spawnRotation.y, spawnRotation.z, 0, false)
        TriggerEvent("17mov_Lumberjack:PlaySound", "logroll.mp3", object, true)
    end

    local animationId = AnimationIdCounter
    AnimationIdCounter = AnimationIdCounter + 1

    ActiveAnimations[animationId] = {
        object = object,
        point = point,
        duration = duration,
        currentIndex = currentIndex,
        changeObject = changeObject,
        startTime = GetGameTimer(),
        initialPos = GetEntityCoords(object, false),
        initialRot = GetEntityRotation(object, 2),
        type = animType,
    }

    if not AnimationThreadRunning then
        RunAnimationThread()
        AnimationThreadRunning = true
    end
end

RegisterNetEvent("17mov_Lumberjack:StartAnimation")
AddEventHandler("17mov_Lumberjack:StartAnimation", StartAnimation)

function RunAnimationThread()
    CreateThread(function()
        local finalRotation = nil
        local newPosition = nil
        local particleFxHandle = nil
        local lastParticleSpawnTime = nil

        while true do
            local finishedIds = {}
            local currentTime = GetGameTimer()
            local activeCount = 0

            if next(ActiveAnimations) == nil then
                AnimationThreadRunning = false
                break
            end

            for animationId, animation in pairs(ActiveAnimations) do
                activeCount = activeCount + 1

                local object = animation.object
                local point = animation.point
                local duration = animation.duration
                local currentIndex = animation.currentIndex
                local changeObject = animation.changeObject
                local elapsed = currentTime - animation.startTime
                local animType = animation.type

                local waypointsTable
                if animType == "chips" then
                    waypointsTable = WoodPileWaypoints
                else
                    waypointsTable = WoodPileDebrisEffects
                end

                if duration <= elapsed then
                    table.insert(finishedIds, animationId)

                    if particleFxHandle then
                        RemoveParticleFx(particleFxHandle, false)
                        particleFxHandle = nil
                    end

                    currentIndex = currentIndex + 1

                    if currentIndex <= #waypointsTable then
                        if point.changeObjectTo then
                            if changeObject then
                                DeleteObject(object)

                                local deleteAttempts = 0
                                while DoesEntityExist(object) and deleteAttempts < 100 do
                                    Wait(10)
                                    DeleteEntity(object)
                                    deleteAttempts = deleteAttempts + 1
                                end

                                local changeHash = GetHashKey(point.changeObjectTo)

                                if not LoadModelWithTimeout(changeHash) then return end

                                object = CreateObject(changeHash, point.coords.x, point.coords.y, point.coords.z, false, true, false)

                                SetEntityRotation(object, point.rotation.x, point.rotation.y, point.rotation.z, 0, false)
                                DecorSetBool(object, "entityOnForks", true)
                            else
                                DeleteObject(object)

                                local deleteAttempts = 0
                                while DoesEntityExist(object) and deleteAttempts < 100 do
                                    Wait(10)
                                    DeleteEntity(object)
                                    deleteAttempts = deleteAttempts + 1
                                end
                            end
                        end

                        StartAnimation({
                            nil, nil,
                            waypointsTable[currentIndex],
                            waypointsTable[currentIndex].duration or 1000,
                            currentIndex,
                            changeObject,
                            object,
                            animType,
                        })
                    elseif changeObject then
                        if animType == nil then
                            Wait(100)
                            DeleteObject(object)

                            local freePlankSlot = GetLastPlankLocationIndex()

                            if freePlankSlot ~= 0 then
                                TriggerServerEvent("17mov_lumberjack:SpawnLocalPlanks", freePlankSlot)
                            end
                        else
                            DeleteObject(object)
                            TriggerServerEvent("17mov_lumberjack:AddChipsToQueue")
                        end
                    end
                end

                local progress = elapsed / duration

                newPosition = vector3(
                    Lerp(animation.initialPos.x, point.coords.x, progress),
                    Lerp(animation.initialPos.y, point.coords.y, progress),
                    Lerp(animation.initialPos.z, point.coords.z, progress)
                )

                if point.rotate then
                    local durationSeconds = duration / 1000.0
                    local rotationSpeed = durationSeconds * -360.0
                    local rotatedAngle = (rotationSpeed * progress) % -360.0

                    finalRotation = vector3(animation.initialRot.x, rotatedAngle, animation.initialRot.z)
                else
                    finalRotation = vector3(
                        Lerp(animation.initialRot.x, point.rotation.x, progress),
                        Lerp(animation.initialRot.y, point.rotation.y, progress),
                        Lerp(animation.initialRot.z, point.rotation.z, progress)
                    )
                end

                FreezeEntityPosition(object, true)
                SetEntityRotation(object, finalRotation.x, finalRotation.y, finalRotation.z, 2, true)
                SetEntityCoords(object, newPosition.x, newPosition.y, newPosition.z, false, false, false, false)

                if point.fxName then
                    if point.particle then
                        local skipParticleThisTick = false

                        if lastParticleSpawnTime then
                            if not (currentTime - lastParticleSpawnTime >= 1500) then
                                skipParticleThisTick = true
                            end
                        end

                        if not skipParticleThisTick then
                            lastParticleSpawnTime = currentTime

                            local ptfxLoadTimeoutMs = 250
                            local ptfxLoadStartTime = GetGameTimer()
                            local ptfxLoaded = true

                            RequestNamedPtfxAsset(point.fxName)

                            while true do
                                if HasNamedPtfxAssetLoaded(point.fxName) then
                                    break
                                end

                                Wait(0)

                                if ptfxLoadTimeoutMs < (GetGameTimer() - ptfxLoadStartTime) then
                                    ptfxLoaded = false
                                    break
                                end
                            end

                            if ptfxLoaded then
                                UseParticleFxAssetNextCall(point.fxName)

                                particleFxHandle = StartParticleFxNonLoopedOnEntity(
                                    point.particle, object,
                                    0.0, 0.0, 0.0,
                                    0.0, 0.0, 0.0,
                                    1.0, false, false, false
                                )
                            end
                        end
                    end
                end
            end

            for _, finishedId in ipairs(finishedIds) do
                ActiveAnimations[finishedId] = nil
            end

            if activeCount == 0 then
                AnimationThreadRunning = false
                break
            end

            if Config.UseBetterPerformance then
                Wait(100)
            else
                Wait(10)
            end
        end
    end)
end

RegisterNetEvent("17mov_Lumberjack:AddChipsToQueue")
AddEventHandler("17mov_Lumberjack:AddChipsToQueue", function()
    local deliveryIncrement

    if Config.EnableVehicleLegacyMode then
        deliveryIncrement = 4.5
    else
        deliveryIncrement = 5.75
    end

    ChipsRatePerDelivery = ChipsRatePerDelivery + deliveryIncrement
    ChipsActionBusy = false

    local currActiveSkip = GetCurrActiveSkip()

    while OnDuty do
        currActiveSkip = GetCurrActiveSkip()
        if currActiveSkip ~= 0 and SkipsSpawnPoints[currActiveSkip].percentage < 100 then break end
        Wait(1000)
    end

    if not OnDuty or currActiveSkip == 0 then return end

    local fillIncrement

    if Config.EnableVehicleLegacyMode then
        fillIncrement = 4
    else
        fillIncrement = 5.25
    end

    SkipsSpawnPoints[GetCurrActiveSkip()].percentage = SkipsSpawnPoints[GetCurrActiveSkip()].percentage + fillIncrement

    if not ChipsThreadRunning then
        ChipsThreadRunning = true
        StartChipsThread()
    end
end)

function StartChipsThread()
    for dumpsterIndex = 1, #SkipDumpsterModels do
        if not LoadModelWithTimeout(SkipDumpsterModels[dumpsterIndex].model) then
            ChipsThreadRunning = false
            return
        end

        SkipDumpsterModels[dumpsterIndex].obj = CreateObject(
            SkipDumpsterModels[dumpsterIndex].model,
            SkipDumpsterModels[dumpsterIndex].coords.x, SkipDumpsterModels[dumpsterIndex].coords.y, SkipDumpsterModels[dumpsterIndex].coords.z,
            false, true, true
        )

        SetEntityRotation(
            SkipDumpsterModels[dumpsterIndex].obj,
            SkipDumpsterModels[dumpsterIndex].rotation.x, SkipDumpsterModels[dumpsterIndex].rotation.y, SkipDumpsterModels[dumpsterIndex].rotation.z,
            0, false
        )

        FreezeEntityPosition(SkipDumpsterModels[dumpsterIndex].obj, true)
    end

    while true do
        if not ChipsThreadRunning then
            break
        end

        local currActiveSkip = GetCurrActiveSkip()

        if OnDuty and currActiveSkip == 0 then
            for dumpsterIndex = 1, #SkipDumpsterModels do
                DeleteEntity(SkipDumpsterModels[dumpsterIndex].obj)
            end

            ChipsThreadRunning = false

            if not AfterSkipFullLoadShown then
                AfterSkipFullLoadShown = true
                ShowTutorial(Config.Lang.afterSkipFullLoad)
            end
        end

        SkipsSpawnPoints[currActiveSkip].liftProgress = SkipsSpawnPoints[currActiveSkip].liftProgress + 1

        local dropTargetZ = SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.z + 0.09574
        local dropStepZ = 0.00007

        ChipsRatePerDelivery = ChipsRatePerDelivery - 1

        CreateThread(function()
            while true do
                if not (SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.z < dropTargetZ) then
                    break
                end

                local newOffsetZ = SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.z + dropStepZ

                DetachEntity(SkipsSpawnPoints[currActiveSkip].chipsObj, true, true)

                AttachEntityToEntity(
                    SkipsSpawnPoints[currActiveSkip].chipsObj, SkipsSpawnPoints[currActiveSkip].obj, 0,
                    SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.x, SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.y, newOffsetZ,
                    0.0, 0.0, 0.0,
                    false, true, true, false, 2, true
                )

                SkipsSpawnPoints[currActiveSkip].chipsAttachOffset = vec3(
                    SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.x, SkipsSpawnPoints[currActiveSkip].chipsAttachOffset.y, newOffsetZ
                )

                Wait(10)
            end
        end)

        TriggerServerEvent("17mov_Lumberjack:LiftChips", currActiveSkip)

        Wait(500)

        if ChipsRatePerDelivery <= 0 then
            for dumpsterIndex = 1, #SkipDumpsterModels do
                DeleteEntity(SkipDumpsterModels[dumpsterIndex].obj)
            end

            ChipsThreadRunning = false

            ShowTutorial(Config.Lang.afterSkipFullLoad)
        end
    end

    AfterSkipFullLoadShown = false
end

function GetCurrActiveSkip()
    for slotIndex, slotData in pairs(SkipsSpawnPoints) do
        if slotData.currActiveSkip then
            return slotIndex
        end
    end

    return 0
end

function Lerp(fromValue, toValue, progress)
    return fromValue + (toValue - fromValue) * progress
end

function GetPedCrane()
    if CurrentCraneId ~= nil then
        if Cranes[CurrentCraneId] ~= nil then
            if Cranes[CurrentCraneId].crane ~= nil then
                return Cranes[CurrentCraneId]
            end
        end
    else

        for _, craneEntry in pairs(Cranes) do
            if type(craneEntry) == "table" then
                if type(craneEntry.crane) == "table" then
                    if craneEntry.crane.vehicleNetId == JobVehicleNetIds.JobVehicle then
                        return craneEntry
                    end
                end
            end

            if craneEntry.crane.vehicleNetId == JobVehicleNetIds.JobVehicle2 then
                return craneEntry
            end
        end

        return nil
    end
end

function GetLogOnTrailerCount()
    if Config.EnableVehicleLegacyMode then
        local logCount = 0

        for _, attachmentState in pairs(TrailerLogsAttachmentsState) do
            if attachmentState.obj ~= 0 then
                if attachmentState.obj ~= nil then
                    logCount = logCount + 1
                end
            end
        end

        return logCount
    else
        local pedCrane = GetPedCrane()

        if pedCrane ~= nil then
            if pedCrane.contentType ~= nil then
                if pedCrane.contentType == Config.Props.logs.hash then
                    return pedCrane.contentQuantity
                end
            end
        end

        return 0
    end
end

function GetPlanksOnTrailerCount()
    if Config.EnableVehicleLegacyMode then
        local plankCount = 0

        for _, attachmentState in pairs(PlanksAttachmentsState) do
            if attachmentState.obj ~= 0 then
                if attachmentState.obj ~= nil then
                    plankCount = plankCount + 1
                end
            end
        end

        return plankCount
    else
        local pedCrane = GetPedCrane()

        if pedCrane then
            if pedCrane.contentType == 1597396577 then
                return pedCrane.contentQuantity
            end
        end

        return 0
    end
end

function GetSkipsOnTrailerCount()
    if Config.EnableVehicleLegacyMode then
        local skipCount = 0

        for _, attachmentState in pairs(TrailerSkipsAttachmentsState) do
            if attachmentState.obj ~= 0 then
                if attachmentState.obj ~= nil then
                    skipCount = skipCount + 1
                end
            end
        end

        return skipCount
    else
        local pedCrane = GetPedCrane()

        if pedCrane then
            if pedCrane.contentType == -1937513394 then
                return pedCrane.contentQuantity
            end
        end

        return 0
    end
end

function GetClosetStation()
    local playerCoords = GetEntityCoords(PlayerPedId())
    local closestStationKey = nil
    local closestPartIndex = nil
    local searchRadius = 100

    for stationKey, stationParts in pairs(Config.Stations) do
        for partIndex = 1, #stationParts do
            local distance = #(stationParts[partIndex].coords.xyz - playerCoords)

            if searchRadius > distance then
                closestStationKey = stationKey
                closestPartIndex = partIndex
                searchRadius = distance
            end
        end
    end

    return closestStationKey, closestPartIndex
end

RegisterNetEvent("17mov_Lumberjack:PlanksProcessed")
AddEventHandler("17mov_Lumberjack:PlanksProcessed", function()
    PlanksProcessed = true
end)

RegisterNetEvent("17mov_lumberjack:SetProcessedPlanksCount")
AddEventHandler("17mov_lumberjack:SetProcessedPlanksCount", function(processedCount)
    ProcessedPlanksCount = processedCount
end)

RegisterNetEvent("17mov_Lumberjack:DeleteThisSlotObj")
AddEventHandler("17mov_Lumberjack:DeleteThisSlotObj", function(slot, vehicleNetId, cargoType)
    for cargoIndex, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
        if cargoEntry.slot == slot then
            if cargoEntry.type == cargoType then
                if cargoEntry.obj ~= nil then
                    local waitStartTime = GetGameTimer()

                    while true do
                        if GetEntityModel(cargoEntry.obj) ~= Config.Props.logs.hash then
                            if GetEntityModel(cargoEntry.obj) ~= 1597396577 then
                                if GetEntityModel(cargoEntry.obj) ~= -1937513394 then
                                    break
                                end
                            end
                        end

                        if not (GetGameTimer() - waitStartTime < 5000) then
                            break
                        end

                        DeleteEntity(cargoEntry.obj)
                        SetEntityAsMissionEntity(cargoEntry.obj, false, false)
                        SetEntityCoords(cargoEntry.obj, 0, 0, 0, false, false, false, false)

                        Wait(10)
                    end
                end

                if cargoEntry.chips ~= nil then
                    local waitStartTime = GetGameTimer()

                    while true do
                        if GetEntityModel(cargoEntry.chips) ~= -195941584 then
                            break
                        end

                        if not (GetGameTimer() - waitStartTime < 5000) then
                            break
                        end

                        DeleteEntity(cargoEntry.chips)
                        SetEntityAsMissionEntity(cargoEntry.chips, false, false)
                        SetEntityCoords(cargoEntry.chips, 0, 0, 0, false, false, false, false)

                        Wait(10)
                    end
                end

                VehicleAttachedCargo[vehicleNetId][cargoIndex] = nil
                break
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:ClearThisIDLog")
AddEventHandler("17mov_Lumberjack:ClearThisIDLog", function(logId)
    TrailerLogsAttachmentsState[logId].obj = nil
end)

RegisterNetEvent("17mov_Lumberjack:3dBoxState")
AddEventHandler("17mov_Lumberjack:3dBoxState", function(carrying3DBox)
    Carrying3DBox = carrying3DBox
end)

RegisterNetEvent("17mov_Lumberjack:StartChipsProcessing")
AddEventHandler("17mov_Lumberjack:StartChipsProcessing", function(_, resetToDefault)
    if resetToDefault then
        SkipsSpawnPoints = DeepCopy(SkipsSpawnPointsDefault)

        for skipIndex, skipData in pairs(SkipsSpawnPoints) do
            local strayGarbageObj = nil
            local strayChipsObj = nil

            while strayGarbageObj ~= 0 do
                strayGarbageObj = GetClosestLog(vec3(skipData.coords.x, skipData.coords.y, skipData.coords.z), 1.0, -1937513394)
                strayChipsObj = GetClosestLog(vec3(skipData.coords.x, skipData.coords.y, skipData.coords.z), 3.0, -195941584)

                if strayGarbageObj ~= 0 then
                    DeleteEntity(strayGarbageObj)
                end

                if strayChipsObj ~= 0 then
                    DeleteEntity(strayChipsObj)
                end

                Wait(100)
            end

            skipData.obj = CreateObject(-1937513394, skipData.coords.x, skipData.coords.y, skipData.coords.z, false, true, true)
            FreezeEntityPosition(skipData.obj, true)
            SetEntityRotation(skipData.obj, skipData.rotation.x, skipData.rotation.y, skipData.rotation.z, 0, false)

            skipData.percentage = 0
            skipData.liftProgress = 0

            skipData.chipsObj = CreateObject(-195941584, skipData.coords.x, skipData.coords.y, skipData.coords.z, false, true, true)
            FreezeEntityPosition(skipData.chipsObj, true)
            SetEntityRotation(skipData.chipsObj, skipData.rotation.x, skipData.rotation.y, skipData.rotation.z, 0, false)

            AttachEntityToEntity(
                skipData.chipsObj, skipData.obj, 0,
                0.027, 0.076, 0.16,
                0.0, 0.0, 0.0,
                false, false, true, false, 2, true
            )

            skipData.chipsAttachOffset = vec3(0.027, 0.076, 0.16)

            Entity(skipData.obj).state.myIndex = skipIndex
            Entity(skipData.obj).state.type = "skips"
        end
    end
end)

RegisterSafeNUICallback("processToChips", function(_, reply)
    reply({ ok = true })
    local playerPed = PlayerPedId()
    local flatbedVehicle = GetVehiclePedIsIn(playerPed, false)
    local currActiveSkip = GetCurrActiveSkip()
    local logOnTrailerCount = GetLogOnTrailerCount()

    if logOnTrailerCount < 1 then
        return Notify(Config.Lang.notEnoughLogs)
    end

    if currActiveSkip == 0 or currActiveSkip == nil then
        return Notify(Config.Lang.noSkipUnder)
    end

    if SkipsSpawnPoints[currActiveSkip].percentage >= 100 then
        return Notify(Config.Lang.currentSkipIsFull)
    end

    if Config.EnableVehicleLegacyMode then
        flatbedVehicle = JobVehicles.JobFlatbed

        TriggerServerEvent("17mov_lumberjack:StopLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    ChipsActionBusy = true
    Carrying3DBox = true

    TriggerServerEvent("17mov_lumberjack:StartChipsProcessing", true)
    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, true)

    local logObj, logSlot = GetLastLogOnTrailer()

    while logObj ~= nil and logSlot ~= nil do
        SetEntityDrawOutlineColor(171, 91, 41, 200)
        SetEntityDrawOutline(logObj, true)

        Wait(1200)

        if Config.EnableVehicleLegacyMode then
            TriggerServerEvent("17mov_Lumberjack:ClearThisIDLog", logSlot, JobVehicleNetIds.JobFlatbed, logSlot)

            TrailerLogsAttachmentsState[logSlot].obj = nil

            CreateThread(function()
                Wait(150)
                TriggerServerEvent("17mov_Lumberjack:ClearThisIDLog", logSlot, JobVehicleNetIds.JobFlatbed, logSlot)
            end)
        else
            if CurrentCraneId ~= nil then
                TriggerServerEvent("17mov_Lumberjack:DeleteTrailerProp", CurrentCraneId)
            end
        end

        AnimateObjectToPoint(
            nil, WoodPileWaypoints[1], WoodPileWaypoints[1].duration or 1000, 1, true,
            vec3(-469.596283, 5333.026, 82.56943), vec3(0.0, 0.0, -20.0), "chips"
        )

        Citizen.Wait(300)

        logObj, logSlot = GetLastLogOnTrailer()
    end

    if Config.EnableVehicleLegacyMode then
        TriggerServerEvent("17mov_lumberjack:StartLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = false

    ShowTutorial(Config.Lang.afterChipsProcess)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, false)

    TriggerServerEvent("17mov_lumberjack:StartChipsProcessing", false)
    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)
end)

RegisterNetEvent("17mov_lumberjack:StartLoopOnThisFlatbed")
AddEventHandler("17mov_lumberjack:StartLoopOnThisFlatbed", function(vehicleNetId)
    for cargoNetId, cargoEntries in pairs(VehicleAttachedCargo) do
        if cargoNetId == vehicleNetId and cargoEntries ~= nil then
            for cargoIndex = 1, #cargoEntries do
                if cargoEntries[cargoIndex].stopLoop ~= nil then
                    cargoEntries[cargoIndex].stopLoop = nil
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_lumberjack:StopLoopOnThisFlatbed")
AddEventHandler("17mov_lumberjack:StopLoopOnThisFlatbed", function(vehicleNetId)
    for cargoNetId, cargoEntries in pairs(VehicleAttachedCargo) do
        if cargoNetId == vehicleNetId then
            for cargoIndex = 1, #cargoEntries do
                cargoEntries[cargoIndex].stopLoop = true
            end
        end
    end
end)

RegisterSafeNUICallback("processToPlanks", function(_, reply)
    reply({ ok = true })
    local playerPed = PlayerPedId()
    local flatbedVehicle = GetVehiclePedIsIn(playerPed, false)

    local planksDivisor = Config.EnableVehicleLegacyMode and 6 or 8
    local planksToProduce = math.floor(GetLogOnTrailerCount() / planksDivisor)

    if planksToProduce < 1 then
        return Notify(Config.Lang.notEnoughLogs)
    end

    if Config.EnableVehicleLegacyMode then
        flatbedVehicle = JobVehicles.JobFlatbed

        TriggerServerEvent("17mov_lumberjack:StopLoopOnThisFlatbed", VehToNet(flatbedVehicle))
    end

    PlanksProcessed = true
    ProcessedPlanksCount = planksToProduce
    Carrying3DBox = true

    TriggerServerEvent("17mov_lumberjack:StartPlanksProcessing")
    TriggerServerEvent("17mov_Lumberjack:SetProcessedPlanksCount", ProcessedPlanksCount)
    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, true)

    local logsProcessedCount = 0
    local logObj, logSlot = GetLastLogOnTrailer()

    while logObj ~= nil and logSlot ~= nil do
        logsProcessedCount = logsProcessedCount + 1

        SetEntityDrawOutlineColor(171, 91, 41, 200)
        SetEntityDrawOutline(logObj, true)

        Wait(900)

        if Config.EnableVehicleLegacyMode then
            TriggerServerEvent("17mov_Lumberjack:ClearThisIDLog", logSlot, JobVehicleNetIds.JobFlatbed, logSlot)

            TrailerLogsAttachmentsState[logSlot].obj = nil

            CreateThread(function()
                Wait(150)
                TriggerServerEvent("17mov_Lumberjack:ClearThisIDLog", logSlot, JobVehicleNetIds.JobFlatbed, logSlot)
            end)
        else
            if CurrentCraneId ~= nil then
                TriggerServerEvent("17mov_Lumberjack:DeleteTrailerProp", CurrentCraneId)
            end
        end

        local swapObject = (logsProcessedCount % planksDivisor) == 0

        AnimateObjectToPoint(
            nil, WoodPileWaypoints[1], WoodPileWaypoints[1].duration or 1000, 1, swapObject,
            vec3(-495.279846, 5346.84375, 80.76374), vec3(0.0, 0.0, -20.0)
        )

        Citizen.Wait(300)

        logObj, logSlot = GetLastLogOnTrailer()
    end

    if Config.EnableVehicleLegacyMode then
        TriggerServerEvent("17mov_lumberjack:StartLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = false

    if Config.EnableVehicleLegacyMode then
        ShowTutorial(Config.Lang.afterLogsProcessLegacy)
    else
        ShowTutorial(Config.Lang.afterLogsProcess)
    end

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, false)

    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)
end)

function SimilarOrientation(heading1, heading2, tolerance)
    local angleDiff = math.abs(heading1 - heading2) % 360

    if angleDiff > 180 then
        angleDiff = 360 - angleDiff
    end

    return tolerance > angleDiff
end

RegisterNetEvent("17mov_Lumberjack:UnloadThisLog")
AddEventHandler("17mov_Lumberjack:UnloadThisLog", function(slot)
    TrailerLogsAttachmentsState[slot].obj = nil
end)

RegisterNetEvent("17mov_Lumberjack:UnloadThisPlank")
AddEventHandler("17mov_Lumberjack:UnloadThisPlank", function(slot)
    PlanksAttachmentsState[slot].obj = nil
end)

RegisterNetEvent("17mov_Lumberjack:UnloadThisSkip")
AddEventHandler("17mov_Lumberjack:UnloadThisSkip", function(slot)
    TrailerSkipsAttachmentsState[slot].obj = nil
end)

RegisterSafeNUICallback("sellChips", function(_, reply)
    reply({ ok = true })
    local playerPed = PlayerPedId()
    local flatbedVehicle = GetVehiclePedIsIn(playerPed, false)
    local closestStationKey, closestPartIndex = GetClosetStation()

    if Carrying3DBox then
        return print("SELLING BLOCKED AND CANCELED")
    end

    if GetSkipsOnTrailerCount() <= 0 then
        return Notify(Config.Lang.dontHaveChips)
    end

    if Config.EnableVehicleLegacyMode then
        flatbedVehicle = JobVehicles.JobFlatbed

        TriggerServerEvent("17mov_lumberjack:StopLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = true
    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)

    Notify(Config.Lang.chipsSellInProgress)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, true)

    local skipObj, skipSlot = GetLastSkipOnTrailer()
    local skipsSoldCap = Config.EnableVehicleLegacyMode and 3 or 2
    local skipsSoldCount = 0

    TriggerServerEvent("17mov_lumberjack:server:SetElementQuantity")

    while skipObj ~= nil and skipSlot ~= nil do
        skipsSoldCount = skipsSoldCount + 1

        SetEntityDrawOutlineColor(171, 91, 41, 200)
        SetEntityDrawOutline(skipObj, true)

        Wait(1300 + math.random(100, 200))

        if Config.EnableVehicleLegacyMode then
            TriggerServerEvent("17mov_Lumberjack:ClearThisIDSkip", skipSlot, JobVehicleNetIds.JobFlatbed, skipSlot)

            TrailerSkipsAttachmentsState[skipSlot].obj = nil

            CreateThread(function()
                Wait(150)
                TriggerServerEvent("17mov_Lumberjack:ClearThisIDSkip", skipSlot, JobVehicleNetIds.JobFlatbed, skipSlot)
            end)
        else
            if CurrentCraneId ~= nil then
                TriggerServerEvent("17mov_Lumberjack:DeleteTrailerProp", CurrentCraneId)
            end
        end

        TriggerServerEvent("17mov_lumberjack:UnloadThisSkip", skipSlot, closestPartIndex)

        Citizen.Wait(300)

        skipObj, skipSlot = GetLastSkipOnTrailer()

        if skipsSoldCap <= skipsSoldCount then
            break
        end
    end

    if Config.EnableVehicleLegacyMode then
        TriggerServerEvent("17mov_lumberjack:StartLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = false

    Notify(Config.Lang.sold)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, false)

    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)
end)

RegisterSafeNUICallback("sellPlanks", function(_, reply)
    reply({ ok = true })
    local playerPed = PlayerPedId()
    local flatbedVehicle = GetVehiclePedIsIn(playerPed, false)
    local closestStationKey, closestPartIndex = GetClosetStation()

    if Carrying3DBox then
        return print("SELLING BLOCKED AND CANCELED")
    end

    if GetPlanksOnTrailerCount() <= 0 then
        return Notify(Config.Lang.dontHavePlanks)
    end

    if Config.EnableVehicleLegacyMode then
        flatbedVehicle = JobVehicles.JobFlatbed

        TriggerServerEvent("17mov_lumberjack:StopLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = true
    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)

    TriggerServerEvent("17mov_lumberjack:server:SetElementQuantity")

    Notify(Config.Lang.planksSellInProgress)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, true)

    local plankObj, plankSlot = GetLastPlankOnTrailer()
    local planksSoldCap = Config.EnableVehicleLegacyMode and 9 or 4
    local planksSoldCount = 0

    while plankObj ~= nil and plankSlot ~= nil do
        planksSoldCount = planksSoldCount + 1

        SetEntityDrawOutlineColor(171, 91, 41, 200)
        SetEntityDrawOutline(plankObj, true)

        Wait(1200 + math.random(100, 200))

        if Config.EnableVehicleLegacyMode then
            TriggerServerEvent("17mov_Lumberjack:ClearThisIDPlank", plankSlot, JobVehicleNetIds.JobFlatbed, plankSlot)

            PlanksAttachmentsState[plankSlot].obj = nil

            CreateThread(function()
                Wait(150)
                TriggerServerEvent("17mov_Lumberjack:ClearThisIDPlank", plankSlot, JobVehicleNetIds.JobFlatbed, plankSlot)
            end)
        else
            if CurrentCraneId ~= nil then
                TriggerServerEvent("17mov_Lumberjack:DeleteTrailerProp", CurrentCraneId)
            end
        end

        TriggerServerEvent("17mov_lumberjack:UnloadThisPlank", plankSlot, closestPartIndex)

        Citizen.Wait(300)

        plankObj, plankSlot = GetLastPlankOnTrailer()

        if planksSoldCap <= planksSoldCount then
            break
        end
    end

    if Config.EnableVehicleLegacyMode then
        TriggerServerEvent("17mov_lumberjack:StartLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = false

    Notify(Config.Lang.sold)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, false)

    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)
end)

RegisterSafeNUICallback("sellLogs", function(_, reply)
    reply({ ok = true })
    local playerPed = PlayerPedId()
    local flatbedVehicle = GetVehiclePedIsIn(playerPed, false)
    local closestStationKey, closestPartIndex = GetClosetStation()

    if Carrying3DBox then
        return print("SELLING BLOCKED AND CANCELED")
    end

    if GetLogOnTrailerCount() <= 0 then
        return Notify(Config.Lang.dontHaveLogs)
    end

    if Config.EnableVehicleLegacyMode then
        flatbedVehicle = JobVehicles.JobFlatbed

        TriggerServerEvent("17mov_lumberjack:StopLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    TriggerServerEvent("17mov_lumberjack:server:SetElementQuantity")

    Carrying3DBox = true
    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)

    Notify(Config.Lang.logsSellInProgress)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, true)

    local logObj, logSlot = GetLastLogOnTrailer()
    local logsSoldCap = Config.EnableVehicleLegacyMode and 32 or 60
    local logsSoldCount = 0

    while logObj ~= nil and logSlot ~= nil do
        logsSoldCount = logsSoldCount + 1

        SetEntityDrawOutlineColor(171, 91, 41, 200)
        SetEntityDrawOutline(logObj, true)

        Wait(1200 + math.random(100, 200))

        if Config.EnableVehicleLegacyMode then
            TriggerServerEvent("17mov_Lumberjack:ClearThisIDLog", logSlot, JobVehicleNetIds.JobFlatbed, logSlot)

            TrailerLogsAttachmentsState[logSlot].obj = nil

            CreateThread(function()
                Wait(150)
                TriggerServerEvent("17mov_Lumberjack:ClearThisIDLog", logSlot, JobVehicleNetIds.JobFlatbed, logSlot)
            end)
        else
            if CurrentCraneId ~= nil then
                TriggerServerEvent("17mov_Lumberjack:DeleteTrailerProp", CurrentCraneId)
            end
        end

        TriggerServerEvent("17mov_lumberjack:UnloadThisLog", closestPartIndex, logSlot)

        Citizen.Wait(300)

        logObj, logSlot = GetLastLogOnTrailer()

        if logsSoldCap <= logsSoldCount then
            break
        end
    end

    if Config.EnableVehicleLegacyMode then
        TriggerServerEvent("17mov_lumberjack:StartLoopOnThisFlatbed", JobVehicleNetIds.JobFlatbed)
    end

    Carrying3DBox = false

    Notify(Config.Lang.sold)

    NetworkRequestControlOfEntity(flatbedVehicle)
    FreezeEntityPosition(flatbedVehicle, false)

    TriggerServerEvent("17mov_Lumberjack:3dBoxState", Carrying3DBox)
end)

ActiveSounds = {}
ActiveSoundCounter = 0

RegisterNetEvent("17mov_Lumberjack:PlaySound")
AddEventHandler("17mov_Lumberjack:PlaySound", function(audioFile, sourceEntityOrCoords, isEntitySource)
    local maxDistance = nil

    if audioFile == "treefall.mp3" then
        maxDistance = Config.Sounds.TreeFallingMaxDistance
    elseif audioFile == "chainsaw.mp3" then
        maxDistance = Config.Sounds.ChainsawNoiseMaxDistance
    elseif audioFile == "logroll.mp3" then
        maxDistance = Config.Sounds.logRollProcessing
    end

    if type(maxDistance) ~= "number" or maxDistance <= 0 then return end

    local sourceEntity = nil
    local sourceCoords = nil

    if isEntitySource then
        sourceEntity = sourceEntityOrCoords
        if not DoesEntityExist(sourceEntity) then return end
        sourceCoords = GetEntityCoords(sourceEntity)
    else
        sourceCoords = sourceEntityOrCoords
    end

    if sourceCoords == nil or type(sourceCoords.x) ~= "number"
        or type(sourceCoords.y) ~= "number" or type(sourceCoords.z) ~= "number" then return end

    local distanceToPlayer = #(sourceCoords - GetEntityCoords(PlayerPedId()))

    if maxDistance < distanceToPlayer then
        return
    end

    local soundVolume = Config.SoundsMultipler or 0.5

    ActiveSoundCounter = ActiveSoundCounter + 1
    local soundId = ActiveSoundCounter
    ActiveSounds[soundId] = false

    local playerCoords = GetEntityCoords(PlayerPedId())
    local playerHeading = GetEntityHeading(PlayerPedId())

    SendNUIMessage({
        sound = "updateSounds",
        x = playerCoords.x,
        y = playerCoords.y,
        z = playerCoords.z,
        h = playerHeading,
    })

    if isEntitySource then
        sourceCoords = GetEntityCoords(sourceEntity)

        CreateThread(function()
            Citizen.Wait(200)

            while true do
                if not ActiveSounds[soundId] then
                    break
                end

                sourceCoords = GetEntityCoords(sourceEntity)

                SendNUIMessage({
                    sound = "updateSoundCoords",
                    id = soundId,
                    x = sourceCoords.x,
                    y = sourceCoords.y,
                    z = sourceCoords.z,
                })

                Citizen.Wait(100)
            end
        end)
    end

    SendNUIMessage({
        sound = "playSound",
        id = soundId,
        audioFile = audioFile,
        volume = soundVolume,
        x = sourceCoords.x,
        y = sourceCoords.y,
        z = sourceCoords.z,
        maxDistance = maxDistance,
    })
end)

RegisterSafeNUICallback("soundsEnd", function(data, cb)
    local soundId = tonumber(data.id)
    if soundId == nil then return end
    ActiveSounds[soundId] = nil
end)

CreateThread(function()
    while true do
        local waitTime = 100

        if next(ActiveSounds) ~= nil then
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local playerHeading = GetEntityHeading(playerPed)

            waitTime = 10

            SendNUIMessage({
                sound = "updateSounds",
                x = playerCoords.x,
                y = playerCoords.y,
                z = playerCoords.z,
                h = playerHeading,
            })

            for soundId, isEstablished in pairs(ActiveSounds) do
                if not isEstablished then
                    ActiveSounds[soundId] = true
                end
            end
        end

        Wait(waitTime)
    end
end)

function GetFreeForksSlots(useForks2)
    local freeSlotsCount = #Config.ForksAttachment
    local nextFreeSlotIndex = 1

    local slotsToScan = useForks2 and Config.ForksAttachment2 or Config.ForksAttachment

    for slotIndex = 1, #slotsToScan do
        if slotsToScan[slotIndex].obj ~= nil then
            freeSlotsCount = freeSlotsCount - 1

            if nextFreeSlotIndex == slotIndex then
                if slotIndex == #slotsToScan then
                    nextFreeSlotIndex = nil
                else
                    nextFreeSlotIndex = nextFreeSlotIndex + 1
                end
            end
        end
    end

    return freeSlotsCount, nextFreeSlotIndex
end

function GetLastLogOnForks()
    local logObj = 0
    local logSlot = 0

    for slotIndex = #Config.ForksAttachment, 1, -1 do
        if Config.ForksAttachment[slotIndex].obj ~= nil then
            logObj = Config.ForksAttachment[slotIndex].obj
            logSlot = slotIndex
            break
        end
    end

    return logObj, logSlot
end

function GetLastLogOnForks2()
    local logObj = 0
    local logSlot = 0

    for slotIndex = #Config.ForksAttachment2, 1, -1 do
        if Config.ForksAttachment2[slotIndex].obj ~= nil then
            logObj = Config.ForksAttachment2[slotIndex].obj
            logSlot = slotIndex
            break
        end
    end

    return logObj, logSlot
end

function GetClosestLog(originCoords, searchRadius, modelHash)
    local allObjects = GetGamePool("CObject")
    local candidateObjects = {}

    if not modelHash then
        modelHash = Config.Props.logs.hash
    end

    for _, objectEntity in pairs(allObjects) do
        if GetEntityModel(objectEntity) == modelHash then
            if not DecorGetBool(objectEntity, "entityOnForks") then
                table.insert(candidateObjects, objectEntity)
            end
        end
    end

    local closestObject = 0
    local closestDistance = searchRadius or 1.5

    for _, candidateObject in pairs(candidateObjects) do
        local distanceToOrigin = #(GetEntityCoords(candidateObject) - originCoords)

        if closestDistance > distanceToOrigin then
            closestObject = candidateObject
            closestDistance = #(GetEntityCoords(candidateObject) - originCoords)
        end
    end

    return closestObject
end

function GetTrailerFreeSlot()
    local freeSlot = 0

    for slotIndex = 1, #TrailerLogsAttachmentsState do
        if TrailerLogsAttachmentsState[slotIndex] ~= nil then
            if TrailerLogsAttachmentsState[slotIndex].obj == nil then
                freeSlot = slotIndex
                break
            end
        end
    end

    return freeSlot
end

if Config.EnableVehicleLegacyMode then
    CreateThread(function()
        CreateThread(function()
            while true do
                TriggerServerCallback("17mov_lumberjack:requestLogsData", function(vehiclesCargoData)
                    if Config.Debug == true then
                        print("NEW DATA FROM CALLBACK")
                    end

                    for vehicleNetId, serverCargoEntries in pairs(vehiclesCargoData) do
                        if VehicleAttachedCargo[vehicleNetId] == nil then
                            VehicleAttachedCargo[vehicleNetId] = serverCargoEntries
                        else
                            for _, serverCargoEntry in pairs(serverCargoEntries) do
                                local alreadyTracked = false

                                for _, existingCargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
                                    if existingCargoEntry.slot == serverCargoEntry.slot then
                                        alreadyTracked = true
                                        break
                                    end
                                end

                                if not alreadyTracked then
                                    if Config.Debug == true then
                                        print("ADDING NEW MATERIAL ON ", serverCargoEntry.slot)
                                    end

                                    table.insert(VehicleAttachedCargo[vehicleNetId], serverCargoEntry)
                                end
                            end
                        end
                    end

                    for vehicleNetId, existingCargoEntries in pairs(VehicleAttachedCargo) do
                        if vehiclesCargoData[vehicleNetId] == nil then
                            VehicleAttachedCargo[vehicleNetId] = nil
                        else
                            local cargoIndicesToRemove = {}

                            for cargoIndex, existingCargoEntry in pairs(existingCargoEntries) do
                                local stillPresentOnServer = false

                                for _, serverCargoEntry in pairs(vehiclesCargoData[vehicleNetId]) do
                                    if existingCargoEntry.slot == serverCargoEntry.slot then
                                        stillPresentOnServer = true
                                        break
                                    end
                                end

                                if not stillPresentOnServer then
                                    if Config.Debug == true then
                                        print("DELETING MATERIAL MATERIAL ON ", existingCargoEntry.slot)
                                    end

                                    if JobVehicleNetIds.JobFlatbed == vehicleNetId then
                                        if existingCargoEntry.type == "logs" then
                                            TrailerLogsAttachmentsState[existingCargoEntry.slot].obj = nil
                                        end

                                        if existingCargoEntry.type == "planks" then
                                            PlanksAttachmentsState[existingCargoEntry.slot].obj = nil
                                        end

                                        if existingCargoEntry.type == "skip" then
                                            TrailerSkipsAttachmentsState[existingCargoEntry.slot].obj = nil
                                            TrailerSkipsAttachmentsState[existingCargoEntry.slot].chipsObj = nil

                                            local chipsObjToDelete = existingCargoEntry.chips

                                            CreateThread(function()
                                                Wait(50)
                                                DeleteObject(chipsObjToDelete)
                                            end)
                                        end
                                    end

                                    local cargoObjToDelete = existingCargoEntry.obj

                                    table.insert(cargoIndicesToRemove, cargoIndex)

                                    CreateThread(function()
                                        Wait(50)
                                        DeleteObject(cargoObjToDelete)
                                    end)
                                end
                            end

                            for removalIndex = #cargoIndicesToRemove, 1, -1 do
                                if Config.Debug == true then
                                    print("4688: ", vehicleNetId, cargoIndicesToRemove[removalIndex])
                                end

                                if VehicleAttachedCargo[vehicleNetId][cargoIndicesToRemove[removalIndex]] ~= nil then
                                    table.remove(VehicleAttachedCargo[vehicleNetId], cargoIndicesToRemove[removalIndex])
                                end
                            end
                        end
                    end
                end)

                Wait(5171)
            end
        end)

        while true do
            Wait(2500)

            for vehicleNetId, cargoEntries in pairs(VehicleAttachedCargo) do
                local vehicleEntity = NetToVeh(vehicleNetId)

                if vehicleEntity ~= 0 then
                    if GetEntityModel(NetToVeh(vehicleNetId)) == GetHashKey(Config.LegacyJobFlatbedModel) then
                        if #(GetEntityCoords(NetToVeh(vehicleNetId)) - GetEntityCoords(PlayerPedId())) < 400.0 then
                            vehicleEntity = NetToVeh(vehicleNetId)

                            for _, cargoEntry in pairs(cargoEntries) do
                                if cargoEntry.stopLoop ~= true then
                                    local vehicleCoords = GetEntityCoords(vehicleEntity)

                                    if cargoEntry.type == "logs" then
                                        local logAlreadyValid = false

                                        if cargoEntry.obj ~= nil then
                                            if DoesEntityExist(cargoEntry.obj) then
                                                if GetEntityModel(cargoEntry.obj) == Config.Props.logs.hash then
                                                    logAlreadyValid = true
                                                end
                                            end
                                        end

                                        if not logAlreadyValid then
                                            cargoEntry.obj = CreateObject(Config.Props.logs.hash, vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)

                                            if vehicleNetId == JobVehicleNetIds.JobFlatbed then
                                                TrailerLogsAttachmentsState[cargoEntry.slot].obj = cargoEntry.obj
                                            end

                                            AttachEntityToEntity(
                                                cargoEntry.obj, vehicleEntity, 0,
                                                TrailerLogsAttachmentsState[cargoEntry.slot].coords.x,
                                                TrailerLogsAttachmentsState[cargoEntry.slot].coords.y,
                                                TrailerLogsAttachmentsState[cargoEntry.slot].coords.z,
                                                0.0, 0.0, 0.0, true, true, true, false, 2, true
                                            )

                                            DecorSetBool(cargoEntry.obj, "entityOnForks", true)
                                        end

                                        if cargoEntry.obj ~= nil then
                                            if not IsEntityAttachedToEntity(cargoEntry.obj, vehicleEntity) then
                                                AttachEntityToEntity(
                                                    cargoEntry.obj, vehicleEntity, 0,
                                                    TrailerLogsAttachmentsState[cargoEntry.slot].coords.x,
                                                    TrailerLogsAttachmentsState[cargoEntry.slot].coords.y,
                                                    TrailerLogsAttachmentsState[cargoEntry.slot].coords.z,
                                                    0.0, 0.0, 0.0, true, true, true, false, 2, true
                                                )
                                            end
                                        end
                                    elseif cargoEntry.type == "planks" then
                                        local plankAlreadyValid = false

                                        if cargoEntry.obj ~= nil then
                                            if DoesEntityExist(cargoEntry.obj) then
                                                plankAlreadyValid = true
                                            end
                                        end

                                        if not plankAlreadyValid then
                                            cargoEntry.obj = CreateObject("17mov_woodpile", vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)

                                            if vehicleNetId == JobVehicleNetIds.JobFlatbed then
                                                PlanksAttachmentsState[cargoEntry.slot].obj = cargoEntry.obj
                                            end

                                            AttachEntityToEntity(
                                                cargoEntry.obj, vehicleEntity, 0,
                                                PlanksAttachmentsState[cargoEntry.slot].coords.x,
                                                PlanksAttachmentsState[cargoEntry.slot].coords.y,
                                                PlanksAttachmentsState[cargoEntry.slot].coords.z,
                                                0.0, 0.0, 0.0, true, true, true, false, 2, true
                                            )
                                        end

                                        if cargoEntry.obj ~= nil then
                                            if not IsEntityAttachedToEntity(cargoEntry.obj, vehicleEntity) then
                                                AttachEntityToEntity(
                                                    cargoEntry.obj, vehicleEntity, 0,
                                                    PlanksAttachmentsState[cargoEntry.slot].coords.x,
                                                    PlanksAttachmentsState[cargoEntry.slot].coords.y,
                                                    PlanksAttachmentsState[cargoEntry.slot].coords.z,
                                                    0.0, 0.0, 0.0, true, true, true, false, 2, true
                                                )
                                            end
                                        end
                                    elseif cargoEntry.type == "skip" then
                                        local skipAlreadyValid = false

                                        if cargoEntry.obj ~= nil then
                                            if DoesEntityExist(cargoEntry.obj) then
                                                skipAlreadyValid = true
                                            end
                                        end

                                        if not skipAlreadyValid then
                                            cargoEntry.obj = CreateObject("17movement_skip", vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)
                                            cargoEntry.chips = CreateObject("17movement_chips", vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)

                                            AttachEntityToEntity(
                                                cargoEntry.chips, cargoEntry.obj, 0,
                                                cargoEntry.offset.x, cargoEntry.offset.y, cargoEntry.offset.z,
                                                0.0, 0.0, 0.0, false, true, true, false, 2, true
                                            )

                                            AttachEntityToEntity(
                                                cargoEntry.obj, vehicleEntity, 0,
                                                TrailerSkipsAttachmentsState[cargoEntry.slot].coords.x,
                                                TrailerSkipsAttachmentsState[cargoEntry.slot].coords.y,
                                                TrailerSkipsAttachmentsState[cargoEntry.slot].coords.z,
                                                0.0, 0.0, 0.0, true, true, true, false, 2, true
                                            )
                                        end

                                        if cargoEntry.obj ~= nil then
                                            if not IsEntityAttachedToEntity(cargoEntry.obj, vehicleEntity) then
                                                AttachEntityToEntity(
                                                    cargoEntry.obj, vehicleEntity, 0,
                                                    TrailerSkipsAttachmentsState[cargoEntry.slot].coords.x,
                                                    TrailerSkipsAttachmentsState[cargoEntry.slot].coords.y,
                                                    TrailerSkipsAttachmentsState[cargoEntry.slot].coords.z,
                                                    0.0, 0.0, 0.0, true, true, true, false, 2, true
                                                )
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                else
                    for _, cargoEntry in pairs(cargoEntries) do
                        if cargoEntry.obj ~= nil then
                            if #(GetEntityCoords(cargoEntry.obj) - GetEntityCoords(NetToVeh(vehicleNetId))) > 20.0 then
                                DeleteEntity(cargoEntry.obj)
                                cargoEntry.obj = nil
                            end
                        end
                    end
                end
            end
        end
    end)
end

RegisterNetEvent("17mov_Lumberjack:SaveObject")
AddEventHandler("17mov_Lumberjack:SaveObject", function(vehicleNetId, slot)
    local deadline = GetGameTimer() + 10000
    while VehicleAttachedCargo[vehicleNetId] == nil and GetGameTimer() < deadline do
        Wait(100)
    end

    while VehicleAttachedCargo[vehicleNetId] ~= nil and GetGameTimer() < deadline do
        for _, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
            if cargoEntry.slot == slot then
                if cargoEntry.type == "logs" then
                    TrailerLogsAttachmentsState[slot].obj = cargoEntry.obj
                    return
                end
            end
        end

        Wait(100)
    end
end)

RegisterNetEvent("17mov_Lumberjack:AttachLog_CL")
AddEventHandler("17mov_Lumberjack:AttachLog_CL", function(vehicleNetId, slot)
    if VehicleAttachedCargo[vehicleNetId] == nil then
        VehicleAttachedCargo[vehicleNetId] = {}
    end

    table.insert(VehicleAttachedCargo[vehicleNetId], {
        netid = vehicleNetId,
        slot = slot,
        type = "logs",
    })

    local vehicleEntity = NetToVeh(vehicleNetId)

    if vehicleEntity ~= 0 then
        if GetEntityModel(vehicleEntity) == GetHashKey(Config.LegacyJobFlatbedModel) then
            if #(GetEntityCoords(vehicleEntity) - GetEntityCoords(PlayerPedId())) < 400.0 then
                for _, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
                    if cargoEntry.type == "logs" then
                        local logAlreadyValid = false

                        if cargoEntry.obj ~= nil then
                            if DoesEntityExist(cargoEntry.obj) then
                                logAlreadyValid = true
                            end
                        end

                        if not logAlreadyValid then
                            local vehicleCoords = GetEntityCoords(vehicleEntity)

                            cargoEntry.obj = CreateObject(Config.Props.logs.hash, vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)

                            AttachEntityToEntity(
                                cargoEntry.obj, vehicleEntity, 0,
                                TrailerLogsAttachmentsState[slot].coords.x,
                                TrailerLogsAttachmentsState[slot].coords.y,
                                TrailerLogsAttachmentsState[slot].coords.z,
                                0.0, 0.0, 0.0, true, true, true, false, 2, true
                            )

                            DecorSetBool(cargoEntry.obj, "entityOnForks", true)
                        end
                    end
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:AttachSkipToTrailer")
AddEventHandler("17mov_Lumberjack:AttachSkipToTrailer", function(skipNetId, chipsNetId, skipSlot)
    local skipObject = WaitForNetworkObject(skipNetId, 5000)
    local chipsObject = WaitForNetworkObject(chipsNetId, 5000)
    if skipObject == 0 or chipsObject == 0 or TrailerSkipsAttachmentsState[skipSlot] == nil then return end

    TrailerSkipsAttachmentsState[skipSlot].obj = skipObject
    TrailerSkipsAttachmentsState[skipSlot].chipsObj = chipsObject

    PickupActionBusy = false
    PendingSkipObjForVehicle1 = 0
    PendingChipsObjForVehicle1 = 0

    local attachStartTime = GetGameTimer()

    while true do
        if JobVehicles.JobFlatbed == nil then
            break
        end

        if IsEntityAttachedToEntity(TrailerSkipsAttachmentsState[skipSlot].obj, JobVehicles.JobFlatbed) then
            break
        end

        if GetGameTimer() - attachStartTime > 2500 then
            break
        end

        NetworkRequestControlOfEntity(TrailerSkipsAttachmentsState[skipSlot].obj)

        AttachEntityToEntity(
            TrailerSkipsAttachmentsState[skipSlot].obj, JobVehicles.JobFlatbed, 0,
            TrailerSkipsAttachmentsState[skipSlot].coords.x,
            TrailerSkipsAttachmentsState[skipSlot].coords.y,
            TrailerSkipsAttachmentsState[skipSlot].coords.z,
            0.0, 0.0, 0.0, true, true, true, false, 2, true
        )

        Wait(250)
    end
end)

RegisterNetEvent("17mov_Lumberjack:SaveSkipObject")
AddEventHandler("17mov_Lumberjack:SaveSkipObject", function(vehicleNetId, slot)
    local deadline = GetGameTimer() + 10000
    while VehicleAttachedCargo[vehicleNetId] == nil and GetGameTimer() < deadline do
        Wait(100)
    end

    while VehicleAttachedCargo[vehicleNetId] ~= nil and GetGameTimer() < deadline do
        Wait(100)

        for _, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
            if cargoEntry.slot == slot then
                if cargoEntry.type == "skip" then
                    TrailerSkipsAttachmentsState[slot].obj = cargoEntry.obj
                    TrailerSkipsAttachmentsState[slot].chipsObj = cargoEntry.chips

                    PickupActionBusy = false
                    PickupActionObject = 0

                    return
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:SavePlankObject")
AddEventHandler("17mov_Lumberjack:SavePlankObject", function(vehicleNetId, slot)
    local deadline = GetGameTimer() + 10000
    while VehicleAttachedCargo[vehicleNetId] == nil and GetGameTimer() < deadline do
        Wait(100)
    end

    while VehicleAttachedCargo[vehicleNetId] ~= nil and GetGameTimer() < deadline do
        Wait(100)

        for _, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
            if cargoEntry.slot == slot then
                if cargoEntry.type == "planks" then
                    PlanksAttachmentsState[slot].obj = cargoEntry.obj

                    PickupActionBusy = false
                    PickupActionObject = 0

                    return
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:AttachLocalSkip")
AddEventHandler("17mov_Lumberjack:AttachLocalSkip", function(vehicleNetId, slot, offset)
    if VehicleAttachedCargo[vehicleNetId] == nil then
        VehicleAttachedCargo[vehicleNetId] = {}
    end

    table.insert(VehicleAttachedCargo[vehicleNetId], {
        netid = vehicleNetId,
        slot = slot,
        type = "skip",
        offset = offset,
    })

    local vehicleEntity = NetToVeh(vehicleNetId)

    if vehicleEntity ~= 0 then
        if GetEntityModel(vehicleEntity) == GetHashKey(Config.LegacyJobFlatbedModel) then
            if #(GetEntityCoords(vehicleEntity) - GetEntityCoords(PlayerPedId())) < 400.0 then
                for _, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
                    if cargoEntry.type == "skip" then
                        local skipAlreadyValid = false

                        if cargoEntry.obj ~= nil then
                            if DoesEntityExist(cargoEntry.obj) then
                                skipAlreadyValid = true
                            end
                        end

                        if not skipAlreadyValid then
                            local vehicleCoords = GetEntityCoords(vehicleEntity)

                            cargoEntry.obj = CreateObject("17movement_skip", vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)
                            cargoEntry.chips = CreateObject("17movement_chips", vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)

                            AttachEntityToEntity(
                                cargoEntry.chips, cargoEntry.obj, 0,
                                cargoEntry.offset.x, cargoEntry.offset.y, cargoEntry.offset.z,
                                0.0, 0.0, 0.0, false, true, true, false, 2, true
                            )

                            AttachEntityToEntity(
                                cargoEntry.obj, vehicleEntity, 0,
                                TrailerSkipsAttachmentsState[slot].coords.x,
                                TrailerSkipsAttachmentsState[slot].coords.y,
                                TrailerSkipsAttachmentsState[slot].coords.z,
                                0.0, 0.0, 0.0, true, true, true, false, 2, true
                            )
                        end
                    end
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:AttachPallete")
AddEventHandler("17mov_Lumberjack:AttachPallete", function(vehicleNetId, slot)
    if VehicleAttachedCargo[vehicleNetId] == nil then
        VehicleAttachedCargo[vehicleNetId] = {}
    end

    table.insert(VehicleAttachedCargo[vehicleNetId], {
        netid = vehicleNetId,
        slot = slot,
        type = "planks",
    })

    local vehicleEntity = NetToVeh(vehicleNetId)

    if vehicleEntity ~= 0 then
        if GetEntityModel(vehicleEntity) == GetHashKey(Config.LegacyJobFlatbedModel) then
            if #(GetEntityCoords(vehicleEntity) - GetEntityCoords(PlayerPedId())) < 400.0 then
                for _, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
                    if cargoEntry.type == "planks" then
                        local plankAlreadyValid = false

                        if cargoEntry.obj ~= nil then
                            if DoesEntityExist(cargoEntry.obj) then
                                plankAlreadyValid = true
                            end
                        end

                        if not plankAlreadyValid then
                            local vehicleCoords = GetEntityCoords(vehicleEntity)

                            cargoEntry.obj = CreateObject("17mov_woodpile", vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, false, true, false)

                            AttachEntityToEntity(
                                cargoEntry.obj, vehicleEntity, 0,
                                PlanksAttachmentsState[slot].coords.x,
                                PlanksAttachmentsState[slot].coords.y,
                                PlanksAttachmentsState[slot].coords.z,
                                0.0, 0.0, 0.0, true, true, true, false, 2, true
                            )
                        end
                    end
                end
            end
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:ResetTractors")
AddEventHandler("17mov_Lumberjack:ResetTractors", function()
    for _, forkSlot in pairs(Config.ForksAttachment) do
        if forkSlot.obj ~= nil then
            if forkSlot.obj ~= 0 then
                DeleteEntity(forkSlot.obj)
                forkSlot.obj = nil
            end
        end
    end

    for _, forkSlot in pairs(Config.ForksAttachment2) do
        if forkSlot.obj ~= nil then
            if forkSlot.obj ~= 0 then
                DeleteEntity(forkSlot.obj)
                forkSlot.obj = nil
            end
        end
    end
end)

function ShowTutorial(tutorialText)
    CreateThread(function()
        if GetResourceKvpInt("17mov_Tutorials:" .. tutorialText) == 0 then
            UiActionBusy = true
            CurrentUiActionId = tutorialText

            SetNuiFocus(true, true)

            SendNUIMessage({
                action = "showTutorial",
                customText = tutorialText,
            })

            while UiActionBusy do
                DisableControlAction(0, 30, true)
                DisableControlAction(0, 31, true)
                DisableControlAction(0, 32, true)
                DisableControlAction(0, 33, true)
                DisableControlAction(0, 34, true)
                DisableControlAction(0, 35, true)

                Wait(0)
            end
        end
    end)
end

function OpenPanel(panelKey, formatArgs)
    local panelContent = Config.Panels[panelKey].content

    if formatArgs then
        panelContent = string.format(panelContent, table.unpack(formatArgs))
    end

    SetNuiFocus(true, true)

    SendNUIMessage({
        action = "showCustomPanel",
        callbackName = panelKey,
        title = Config.Panels[panelKey].title,
        subTitle = Config.Panels[panelKey].subTitle,
        confirmBtn = Config.Panels[panelKey].confirmBtn,
        closeBtn = Config.Panels[panelKey].closeBtn,
        content = panelContent,
        img = Config.Panels[panelKey].photo,
    })
end

function AttachLogOnTrailer(logObj)
    local freeSlot = GetTrailerFreeSlot()

    if freeSlot >= #Config.TrailerLogsAttachments then
        ShowTutorial(Config.Lang.afterLoadingFullTrailer)
        TriggerServerEvent("17mov_Lumberjack:ResetTractors")
    end

    if freeSlot == 0 then
        return Notify(Config.Lang.fullTrailer)
    end

    if not DoesEntityExist(logObj) then
        return Notify(Config.Lang.wentWrong)
    end

    DeleteEntity(logObj)
    TrailerLogsAttachmentsState[freeSlot].obj = 17
    TriggerServerEvent("17mov_Lumberjack:AttachLog", freeSlot, JobVehicleNetIds.JobFlatbed, 0)
end

function RotatePointAroundOrigin(point, angleDegrees)
    local angleRadians = math.rad(angleDegrees)
    local cosAngle = math.cos(angleRadians)
    local sinAngle = math.sin(angleRadians)

    local rotatedX = point.x * cosAngle - point.y * sinAngle
    local rotatedY = point.x * sinAngle + point.y * cosAngle

    return vector3(rotatedX, rotatedY, point.z)
end

function DegreesToRadians(degrees)
    return degrees * (math.pi / 180)
end

function RotatePointAroundOrigin3D(originPoint, targetPoint, rotation)
    local offset = targetPoint - originPoint

    local cosX = math.cos(DegreesToRadians(rotation.x))
    local sinX = math.sin(DegreesToRadians(rotation.x))
    local cosY = math.cos(DegreesToRadians(rotation.y))
    local sinY = math.sin(DegreesToRadians(rotation.y))
    local cosZ = math.cos(DegreesToRadians(rotation.z))
    local sinZ = math.sin(DegreesToRadians(rotation.z))

    local rotatedX = offset.x * (cosY * cosZ)
        + offset.y * (cosZ * sinX * sinY - cosX * sinZ)
        + offset.z * (sinX * sinZ + cosX * cosZ * sinY)

    local rotatedY = offset.x * (cosY * sinZ)
        + offset.y * (cosX * cosZ + sinX * sinY * sinZ)
        + offset.z * (cosX * sinY * sinZ - cosZ * sinX)

    local rotatedZ = offset.x * (-sinY)
        + offset.y * (cosY * sinX)
        + offset.z * (cosX * cosY)

    return vector3(rotatedX, rotatedY, rotatedZ) + originPoint
end

local function DrawPolyDoubleSided(x1, y1, z1, x2, y2, z2, x3, y3, z3, r, g, b, a)
    DrawPoly(x1, y1, z1, x2, y2, z2, x3, y3, z3, r, g, b, a)
    DrawPoly(x1, y1, z1, x3, y3, z3, x2, y2, z2, r, g, b, a)
end

function Draw3DBox(centerX, centerY, centerZ, boxWidth, boxHeight, boxLength, colorR, colorG, colorB, colorA, rotation)
    local centerPoint = vector3(centerX, centerY, centerZ)

    local halfWidth = boxWidth / 2
    local halfHeight = boxHeight / 2
    local halfLength = boxLength / 2

    local cornerLeftBottomNear = RotatePointAroundOrigin3D(centerPoint, vector3(centerX - halfWidth, centerY - halfHeight, centerZ - halfLength), rotation)
    local cornerRightBottomNear = RotatePointAroundOrigin3D(centerPoint, vector3(centerX + halfWidth, centerY - halfHeight, centerZ - halfLength), rotation)
    local cornerLeftTopNear = RotatePointAroundOrigin3D(centerPoint, vector3(centerX - halfWidth, centerY + halfHeight, centerZ - halfLength), rotation)
    local cornerRightTopNear = RotatePointAroundOrigin3D(centerPoint, vector3(centerX + halfWidth, centerY + halfHeight, centerZ - halfLength), rotation)
    local cornerLeftBottomFar = RotatePointAroundOrigin3D(centerPoint, vector3(centerX - halfWidth, centerY - halfHeight, centerZ + halfLength), rotation)
    local cornerRightBottomFar = RotatePointAroundOrigin3D(centerPoint, vector3(centerX + halfWidth, centerY - halfHeight, centerZ + halfLength), rotation)
    local cornerLeftTopFar = RotatePointAroundOrigin3D(centerPoint, vector3(centerX - halfWidth, centerY + halfHeight, centerZ + halfLength), rotation)
    local cornerRightTopFar = RotatePointAroundOrigin3D(centerPoint, vector3(centerX + halfWidth, centerY + halfHeight, centerZ + halfLength), rotation)

    DrawPolyDoubleSided(cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, colorR, colorG, colorB, colorA)

    DrawPolyDoubleSided(cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, colorR, colorG, colorB, colorA)

    DrawPolyDoubleSided(cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)

    DrawPolyDoubleSided(cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, colorR, colorG, colorB, colorA)

    DrawPolyDoubleSided(cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightTopFar.x, cornerRightTopFar.y, cornerRightTopFar.z, cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomFar.x, cornerRightBottomFar.y, cornerRightBottomFar.z, cornerLeftBottomFar.x, cornerLeftBottomFar.y, cornerLeftBottomFar.z, cornerLeftTopFar.x, cornerLeftTopFar.y, cornerLeftTopFar.z, colorR, colorG, colorB, colorA)

    DrawPolyDoubleSided(cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerRightBottomNear.x, cornerRightBottomNear.y, cornerRightBottomNear.z, cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, colorR, colorG, colorB, colorA)
    DrawPolyDoubleSided(cornerLeftBottomNear.x, cornerLeftBottomNear.y, cornerLeftBottomNear.z, cornerLeftTopNear.x, cornerLeftTopNear.y, cornerLeftTopNear.z, cornerRightTopNear.x, cornerRightTopNear.y, cornerRightTopNear.z, colorR, colorG, colorB, colorA)
end

function IsThereSomebodyClose()
    local activePlayers = GetActivePlayers()
    local localPed = PlayerPedId()
    local localCoords = GetEntityCoords(localPed)
    local proximityThreshold = 3

    for _, playerId in ipairs(activePlayers) do
        local otherPed = GetPlayerPed(playerId)

        if localPed ~= otherPed then
            local otherCoords = GetEntityCoords(otherPed)

            if proximityThreshold >= #(localCoords - otherCoords) then
                return true
            end
        end
    end

    return false
end

function ChainsawAnimation(treeObj)
    local localPed = PlayerPedId()
    local treeCoords = GetEntityCoords(treeObj)

    if IsThereSomebodyClose() then
        Notify(Config.Lang.exploitFix)
        return false
    end

    local pedCoords = GetEntityCoords(localPed)
    local directionToTree = treeCoords - pedCoords
    local flatDirection = vector3(directionToTree.x, directionToTree.y, 0.0)
    local normalizedDirection = flatDirection / #flatDirection
    local approachOffset = normalizedDirection * 0.7
    local targetPosition = treeCoords - approachOffset

    local pedCoordsAgain = GetEntityCoords(localPed)
    local headingDeltaX = treeCoords.x - pedCoordsAgain.x
    local headingDeltaY = treeCoords.y - pedCoordsAgain.y
    local facingHeading = GetHeadingFromVector_2d(headingDeltaX, headingDeltaY)

    SetEntityCoords(localPed, targetPosition.x, targetPosition.y, targetPosition.z + 1.2, true, false, false, false)
    SetEntityHeading(localPed, facingHeading)
    ClearPedTasks(localPed)

    local animDict = "weapons@heavy@minigun"
    local animName = "fire_med"

    if not LoadAnimDictWithTimeout(animDict) or not LoadModelWithTimeout(-1314067793) then
        FreezeEntityPosition(localPed, false)
        return false
    end

    TaskPlayAnim(localPed, animDict, animName, 8.0, -8.0, -1, 50, 0, false, false, false)

    TriggerServerEvent("17mov_Lumberjack:PlaySound", "chainsaw.mp3", GetEntityCoords(PlayerPedId()))

    local chainsawObj = CreateObject(-1314067793, 0, 0, 0, true, true, true)
    local rightHandBone = GetPedBoneIndex(localPed, 57005)
    local chainsawAttachOffset = vector3(0.3, 0.18, -0.1)
    local chainsawAttachRotation = vector3(-52.0, 20.0, 65.0)

    AttachEntityToEntity(
        chainsawObj, localPed, rightHandBone,
        chainsawAttachOffset.x, chainsawAttachOffset.y, chainsawAttachOffset.z,
        chainsawAttachRotation.x, chainsawAttachRotation.y, chainsawAttachRotation.z,
        true, true, false, true, 2, true
    )

    local minigameRunning = true

    CreateThread(function()
        while minigameRunning do
            Wait(100)

            local splinterCoords = GetOffsetFromEntityInWorldCoords(localPed, 0.235, 0.45, 0.0)

            UseParticleFxAssetNextCall("core")
            StartNetworkedParticleFxNonLoopedAtCoord(
                "ent_dst_wood_splinter",
                splinterCoords.x, splinterCoords.y, splinterCoords.z,
                0.0, 0.0, GetEntityHeading(localPed) - 180.0,
                0.4, false, false, false
            )
        end
    end)

    CreateThread(function()
        while minigameRunning do
            Wait(0)
            DisableMotion()
        end

        EnableControlAction(0, 32, true)
        EnableControlAction(0, 33, true)
        EnableControlAction(0, 34, true)
        EnableControlAction(0, 35, true)
        EnableControlAction(0, 30, true)
        EnableControlAction(0, 31, true)
        EnableControlAction(0, 22, true)
        EnableControlAction(0, 59, true)
        EnableControlAction(0, 60, true)
        EnableControlAction(0, 61, true)
        EnableControlAction(0, 62, true)
        EnableControlAction(0, 63, true)
        EnableControlAction(0, 64, true)

        FreezeEntityPosition(PlayerPedId(), false)
    end)

    local minigameSucceeded = true

    if ChainsawMinigame == nil then
        Wait(13000)
    else
        minigameSucceeded = ChainsawMinigame()
    end

    minigameRunning = false

    FreezeEntityPosition(PlayerPedId(), false)
    ClearPedTasks(localPed)
    RemoveAnimDict(animDict)
    DeleteObject(chainsawObj)

    return minigameSucceeded
end

function DisableMotion()
    DisableControlAction(0, 32, true)
    DisableControlAction(0, 33, true)
    DisableControlAction(0, 34, true)
    DisableControlAction(0, 35, true)
    DisableControlAction(0, 30, true)
    DisableControlAction(0, 31, true)
    DisableControlAction(0, 22, true)
    DisableControlAction(0, 59, true)
    DisableControlAction(0, 60, true)
    DisableControlAction(0, 61, true)
    DisableControlAction(0, 62, true)
    DisableControlAction(0, 63, true)
    DisableControlAction(0, 64, true)

    FreezeEntityPosition(PlayerPedId(), true)
end

function GetLastPlankOnTrailer()
    if Config.EnableVehicleLegacyMode then
        local plankObj = nil
        local plankSlot = nil

        for slotIndex = #PlanksAttachmentsState, 1, -1 do
            if PlanksAttachmentsState[slotIndex].obj ~= nil then
                if JobVehicles.JobFlatbed ~= nil then
                    if IsEntityAttachedToEntity(PlanksAttachmentsState[slotIndex].obj, JobVehicles.JobFlatbed) then
                        plankObj = PlanksAttachmentsState[slotIndex].obj
                        plankSlot = slotIndex
                        break
                    end
                end
            end
        end

        return plankObj, plankSlot
    else
        local pedCrane = GetPedCrane()

        if pedCrane then
            if pedCrane.crane then
                if pedCrane.contentType == 1597396577 then
                    return pedCrane.crane.LoadedObjects[#pedCrane.crane.LoadedObjects], #pedCrane.crane.LoadedObjects
                end
            end
        end
    end
end

function GetLastSkipOnTrailer()
    if Config.EnableVehicleLegacyMode then
        local skipObj = nil
        local skipSlot = nil

        for slotIndex = #TrailerSkipsAttachmentsState, 1, -1 do
            if TrailerSkipsAttachmentsState[slotIndex].obj ~= nil then
                if JobVehicles.JobFlatbed ~= nil then
                    if IsEntityAttachedToEntity(TrailerSkipsAttachmentsState[slotIndex].obj, JobVehicles.JobFlatbed) then
                        skipObj = TrailerSkipsAttachmentsState[slotIndex].obj
                        skipSlot = slotIndex
                        break
                    end
                end
            end
        end

        return skipObj, skipSlot
    else
        local pedCrane = GetPedCrane()

        if pedCrane then
            if pedCrane.crane then
                if pedCrane.contentType == -1937513394 then
                    return pedCrane.crane.LoadedObjects[#pedCrane.crane.LoadedObjects], #pedCrane.crane.LoadedObjects
                end
            end
        end
    end
end

function GetLastLogOnTrailer()
    if Config.EnableVehicleLegacyMode then
        local logObj = nil
        local logSlot = nil

        for slotIndex = #TrailerLogsAttachmentsState, 1, -1 do
            if TrailerLogsAttachmentsState[slotIndex] ~= nil then
                if TrailerLogsAttachmentsState[slotIndex].obj ~= nil then
                    if JobVehicles.JobFlatbed ~= nil then
                        if IsEntityAttachedToEntity(TrailerLogsAttachmentsState[slotIndex].obj, JobVehicles.JobFlatbed) then
                            logObj = TrailerLogsAttachmentsState[slotIndex].obj
                            logSlot = slotIndex
                            break
                        end
                    end
                end
            end
        end

        return logObj, logSlot
    else
        local pedCrane = GetPedCrane()

        if pedCrane then
            if pedCrane.crane then
                if pedCrane.contentType == Config.Props.logs.hash then
                    return pedCrane.crane.LoadedObjects[#pedCrane.crane.LoadedObjects], #pedCrane.crane.LoadedObjects
                end
            end
        end
    end
end

function GetGroundHeightRaycast(x, y)
    local rayHandle = StartShapeTestRay(x, y, 1000.0, x, y, -1000.0, -1, PlayerPedId(), 0)
    local _, didHit, hitCoords = GetShapeTestResult(rayHandle)

    if didHit then
        return hitCoords.z
    else
        local _, groundZ = GetGroundZFor_3dCoord(x, y, 0.0, false)
        return groundZ
    end
end

function CalculateSlopeAngle(originCoords, direction, stepDistance)
    local probeCoords = originCoords + direction * stepDistance
    local playerGroundHeight = GetEntityCoords(PlayerPedId()).z - 1.0
    local probeGroundHeight = GetGroundHeightRaycast(probeCoords.x, probeCoords.y)
    local heightDifference = math.abs(probeGroundHeight - playerGroundHeight)
    local deltaX = probeCoords.x - originCoords.x
    local deltaY = probeCoords.y - originCoords.y
    local horizontalDistance = math.sqrt(deltaX * deltaX + deltaY * deltaY)
    local slopeAngle = math.deg(math.atan(heightDifference / horizontalDistance))

    if playerGroundHeight > probeGroundHeight then
        slopeAngle = -slopeAngle
    end

    return slopeAngle
end

RegisterNetEvent("17mov_lumberjack:StartFallAnim")
AddEventHandler("17mov_lumberjack:StartFallAnim", function(treeId, fallHeadingDegrees)
    if LocalTreeFallSuppression[treeId] then
        LocalTreeFallSuppression[treeId] = nil
        return
    end
    if CurrentFallingTreeId == treeId then
        CurrentFallingTreeId = 0
        return
    end

    StartFallAnim(TreesData[treeId].obj, true, fallHeadingDegrees)
end)

RegisterNetEvent("17mov_Lumberjack:updateCounter")
AddEventHandler("17mov_Lumberjack:updateCounter", function()
    CurrentLogCounter = CurrentLogCounter + 3
end)

function StartFallAnim(treeObj, isRemoteTrigger, fallHeadingDegrees)
    if not isRemoteTrigger then
        TriggerServerEvent("17mov_Lumberjack:PlaySound", "treefall.mp3", GetEntityCoords(treeObj))
    else
        local distanceToTree = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(treeObj))

        if distanceToTree > 100 then
            DeleteObject(treeObj)
            return
        end
    end

    local fallHeadingRadians = math.rad(fallHeadingDegrees)
    local fallDirection = vector3(-math.sin(fallHeadingRadians), math.cos(fallHeadingRadians), 0.0)

    local logHash = Config.Props.logs.hash
    local fallDurationMs = 4800
    local treeCoords = GetEntityCoords(treeObj)
    local slopeAngle = CalculateSlopeAngle(treeCoords, fallDirection, 10.0)
    local targetPitch = -90 + slopeAngle
    local fallStartTime = GetGameTimer()

    while true do
        local fallProgress = math.min(1.0, (GetGameTimer() - fallStartTime) / fallDurationMs)

        if fallProgress >= 1.0 then
            local ptfxTimeoutStart = GetGameTimer()
            local ptfxLoaded = true

            RequestNamedPtfxAsset("scr_reconstructionaccident")

            while not HasNamedPtfxAssetLoaded("scr_reconstructionaccident") do
                Wait(0)

                if GetGameTimer() - ptfxTimeoutStart > 250 then
                    ptfxLoaded = false
                    break
                end
            end

            if ptfxLoaded then
                UseParticleFxAssetNextCall("scr_reconstructionaccident")
                StartNetworkedParticleFxNonLoopedOnEntity(
                    "scr_reconstruct_pipe_impact", treeObj,
                    0.0, -7.5, 0.0,
                    -90.0, 90.0, 0.0,
                    3.0, false, false, false
                )
            end

            Wait(350)
            DeleteObject(treeObj)
            break
        end

        local cubedProgress = fallProgress * fallProgress * fallProgress
        local sinkOffset = 0.0

        if cubedProgress > 0.5 then
            sinkOffset = sinkOffset + 0.02
        end

        local currentCoords = GetEntityCoords(treeObj)
        local rotationVector = vector3(targetPitch * cubedProgress, 0.0, fallHeadingDegrees)

        SetEntityCoords(treeObj, currentCoords.x, currentCoords.y, currentCoords.z + sinkOffset, false, false, false, false)
        SetEntityRotation(treeObj, rotationVector.x, rotationVector.y, rotationVector.z, 2, true)

        Wait(0)
    end

    if isRemoteTrigger then
        return
    end

    local logsData = {}

    for logIndex = 1, 3 do
        local logX = treeCoords.x + fallDirection.x * logIndex * Config.Props.logs.height
        local logY = treeCoords.y + fallDirection.y * logIndex * Config.Props.logs.height

        table.insert(logsData, {
            hash = logHash,
            coords = vector3(logX, logY, GetGroundHeightRaycast(logX, logY)),
            heading = fallHeadingDegrees,
        })
    end

    for logIndex, logEntry in pairs(logsData) do
        local logObj = CreateObject(logEntry.hash, logEntry.coords.x, logEntry.coords.y, logEntry.coords.z, true, true, true)

        SetEntityHeading(logObj, logEntry.heading)
        PlaceObjectOnGroundProperly(logObj)

        local netIdWaitStart = GetGameTimer()
        local logNetId = ObjToNet(logObj)

        while logNetId == logObj or logNetId == 0 do
            Wait(100)

            logNetId = ObjToNet(logObj)

            if GetGameTimer() - netIdWaitStart > 1500 then
                print("CANNOT SPAWN NET ID - SETTING LOG AS LOCAL TO PREVENT JOB STOP")
                break
            end
        end

        if logNetId ~= logObj and logNetId ~= 0 then
            logsData[logIndex].netId = logNetId
        end
    end

    TriggerServerEvent("17mov_Lumberjack:SetLogsStatebag", logsData)

    if not TreeFallTutorialShown then
        TreeFallTutorialShown = true

        local tutorialKey = Config.Lang.AfterTreeFallTutorial

        if Config.EnableVehicleLegacyMode then
            if Config.Lang.AfterTreeFallTutorialLegacy then
                tutorialKey = Config.Lang.AfterTreeFallTutorialLegacy
            end
        end

        ShowTutorial(tutorialKey)
    end
end

RegisterNetEvent("17mov_Lumberjack:ClearThisFlatbed")
AddEventHandler("17mov_Lumberjack:ClearThisFlatbed", function(vehicleNetId)
    if VehicleAttachedCargo[vehicleNetId] == nil then
        return
    end

    for cargoIndex, cargoEntry in pairs(VehicleAttachedCargo[vehicleNetId]) do
        DeleteEntity(cargoEntry.obj)
        VehicleAttachedCargo[vehicleNetId][cargoIndex] = nil
    end

    VehicleAttachedCargo[vehicleNetId] = nil
end)

function EndJob()
    local localPed = PlayerPedId()
    local currentVehicle = GetVehiclePedIsIn(localPed, false)

    if GetEntityModel(currentVehicle) ~= GetHashKey(Config.LegacyJobVehicleModel)
        and GetEntityModel(currentVehicle) ~= GetHashKey(Config.JobTruckModel)
        and GetEntityModel(currentVehicle) ~= GetHashKey(Config.PickupModel)
        and GetEntityModel(currentVehicle) ~= GetHashKey(Config.JobVehicleModel) then
        SetNuiFocus(true, true)
        SendNUIMessage({ action = "openWarning" })
        return
    end

    if GetPedInVehicleSeat(currentVehicle, -1) ~= localPed then
        return Notify(Config.Lang.notADriver)
    end

    return TriggerServerEvent("17mov_lumberjack:endJob_sv", true)
end

RegisterNetEvent("17mov_lumberjack:endJob_cl")
AddEventHandler("17mov_lumberjack:endJob_cl", function()
    if RemoveKeys ~= nil then
        RemoveKeys()
    end

    local localPed = PlayerPedId()
    local distanceToDutyToggle = #(GetEntityCoords(localPed) - Config.Locations.DutyToggle.Coords[1])

    if distanceToDutyToggle < 40.0 then
        if Config.EnableVehicleTeleporting then
            DoScreenFadeOut(250)
            Wait(1000)
            SetEntityCoords(
                localPed,
                Config.Locations.DutyToggle.Coords[1].x,
                Config.Locations.DutyToggle.Coords[1].y,
                Config.Locations.DutyToggle.Coords[1].z,
                true, false, false, false
            )
        end
    end

    for slotIndex = 1, #TrailerLogsAttachmentsState do
        if TrailerLogsAttachmentsState[slotIndex].obj ~= nil then
            DeleteEntity(TrailerLogsAttachmentsState[slotIndex].obj)
        end
    end

    DeleteEntity(HeldLogObject)
    DeleteEntity(HeldPlankObject)
    DeleteEntity(HeldSkipObject)

    for slotIndex = 1, #PlanksAttachmentsState do
        if PlanksAttachmentsState[slotIndex].obj ~= nil then
            DeleteEntity(PlanksAttachmentsState[slotIndex].obj)
        end
    end

    for slotIndex = 1, #TrailerSkipsAttachmentsState do
        if TrailerSkipsAttachmentsState[slotIndex].obj ~= nil then
            DeleteEntity(TrailerSkipsAttachmentsState[slotIndex].obj)
        end

        if TrailerSkipsAttachmentsState[slotIndex].chipsObj ~= nil then
            DeleteEntity(TrailerSkipsAttachmentsState[slotIndex].chipsObj)
        end
    end

    if Config.EnableVehicleLegacyMode then
        RemoveBlip(Config.Locations.WithdrawTruck.blip)
        RemoveBlip(Config.Locations.rentForklift.blip)
    end

    for _, stationParts in pairs(Config.Stations) do
        for partIndex = 1, #stationParts do
            if stationParts[partIndex].blip ~= nil then
                RemoveBlip(stationParts[partIndex].blip)
            end
        end
    end

    for _, treeEntry in pairs(TreesData) do
        if treeEntry.blip ~= nil then
            RemoveBlip(treeEntry.blip)
        end
    end

    DoScreenFadeIn(300)
    Wait(1000)

    OnDuty = false
    CurrentFallingTreeId = nil
    CurrentLobbyHost = nil
    CurrentHoldingController = nil

    if Config.RequireWorkClothes then
        if not Config.EnableCloakroom then
            ClothesIsWork = false
            ChangeClothes("citizen")
        end
    end

    RemoveBlip(ChipsBlip)
    RemoveBlip(PlanksBlip)
end)

RegisterSafeNUICallback("acceptWarning", function(data)
    TriggerServerEvent("17mov_lumberjack:endJob_sv", false)

    if Config.DeleteVehicleWithPenalty then
        DeleteVehicleByCore(GetVehiclePedIsIn(PlayerPedId(), false))
    end
end)

local function CleanupLocalResource(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    SetNuiFocus(false, false)
    SendNUIMessage({ action = "CloseAll" })
    RemoveKeys()

    for _, vehicleEntity in pairs(JobVehicles) do
        if DoesEntityExist(vehicleEntity) then DeleteEntity(vehicleEntity) end
    end

    for _, treeEntry in pairs(TreesData) do
        if treeEntry.obj and DoesEntityExist(treeEntry.obj) then DeleteEntity(treeEntry.obj) end
    end
    for _, skipEntry in pairs(SkipsSpawnPoints) do
        if skipEntry.obj and DoesEntityExist(skipEntry.obj) then DeleteEntity(skipEntry.obj) end
        if skipEntry.chipsObj and DoesEntityExist(skipEntry.chipsObj) then DeleteEntity(skipEntry.chipsObj) end
    end
    for _, plankEntry in pairs(PlanksSpawnPoints) do
        if plankEntry.obj and DoesEntityExist(plankEntry.obj) then DeleteEntity(plankEntry.obj) end
    end

    for callbackId, pending in pairs(CallbackRegistry) do
        CallbackRegistry[callbackId] = nil
        pending.callback(nil, "resource_stopped")
    end
end

AddEventHandler("onClientResourceStop", CleanupLocalResource)

RegisterNetEvent("17mov_Lumberjack:UpdateLogCounter")
AddEventHandler("17mov_Lumberjack:UpdateLogCounter", function()
    CurrentLogCounter = CurrentLogCounter - 1
end)
