local Core
local IssuedVehicleKeys = {}

Config.Framework = "STANDALONE"

local function IsResourceAvailable(resourceName)
    local state = GetResourceState(resourceName)
    return state == "started" or state == "starting"
end

function RefreshFramework()
    local detectedCore
    local detectedFramework = "STANDALONE"

    if IsResourceAvailable("qb-core") then
        local ok, result = pcall(function() return exports["qb-core"]:GetCoreObject() end)
        if ok and result then detectedCore, detectedFramework = result, "QBCore" end
    end
    if detectedCore == nil and IsResourceAvailable("es_extended") then
        local ok, result = pcall(function() return exports["es_extended"]:getSharedObject() end)
        if ok and result then detectedCore, detectedFramework = result, "ESX" end
    end

    if detectedCore == nil and IsResourceAvailable("qb-core") then
        TriggerEvent("__cfx_export_qb-core_GetCoreObject", function(getCore)
            if detectedCore == nil then detectedCore, detectedFramework = getCore(), "QBCore" end
        end)
    end
    if detectedCore == nil and IsResourceAvailable("es_extended") then
        TriggerEvent("__cfx_export_es_extended_getSharedObject", function(getCore)
            if detectedCore == nil then detectedCore, detectedFramework = getCore(), "ESX" end
        end)
        if detectedCore == nil then
            TriggerEvent("esx:getSharedObject", function(result)
                if detectedCore == nil then detectedCore, detectedFramework = result, "ESX" end
            end)
        end
    end

    Core = detectedCore
    Config.Framework = detectedCore and detectedFramework or "STANDALONE"
    return Config.Framework
end

RegisterNetEvent("17mov_DrawDefaultNotification" .. GetCurrentResourceName(), function(msg)
    Notify(msg)
end)

AddEventHandler("onClientResourceStart", function(resourceName)
    if resourceName == "qb-core" or resourceName == "es_extended" then RefreshFramework() end
end)

AddEventHandler("onClientResourceStop", function(resourceName)
    if resourceName == "qb-core" or resourceName == "es_extended" then
        Core = nil
        Config.Framework = "STANDALONE"
        RefreshFramework()
    end
end)

RefreshFramework()

CreateThread(function()
    Wait(2500)
    if InitalizeScript then InitalizeScript() end
end)

function LoadModelWithTimeout(modelHash, timeoutMs)
    timeoutMs = timeoutMs or 10000
    RequestModel(modelHash)
    local deadline = GetGameTimer() + timeoutMs
    while not HasModelLoaded(modelHash) and GetGameTimer() < deadline do
        Wait(50)
        RequestModel(modelHash)
    end
    return HasModelLoaded(modelHash)
end

function LoadAnimDictWithTimeout(dict, timeoutMs)
    timeoutMs = timeoutMs or 10000
    RequestAnimDict(dict)
    local deadline = GetGameTimer() + timeoutMs
    while not HasAnimDictLoaded(dict) and GetGameTimer() < deadline do
        Wait(50)
        RequestAnimDict(dict)
    end
    return HasAnimDictLoaded(dict)
end

function GetPlayerData()
    if Config.Framework == "QBCore" and Core and Core.Functions then
        return Core.Functions.GetPlayerData()
    elseif Config.Framework == "ESX" and Core then
        return Core.GetPlayerData()
    else
        return {job = {name = "unknown", grade = 0}}
    end
end

function DeleteVehicleByCore(vehicle)
    if vehicle == nil or vehicle == 0 then return end
    if Config.Framework == "QBCore" and Core and Core.Functions then
        Core.Functions.DeleteVehicle(vehicle)
    elseif Config.Framework == "ESX" and Core and Core.Game then
        Core.Game.DeleteVehicle(vehicle)
    else
        SetEntityAsMissionEntity(vehicle, false, true)
        DeleteVehicle(vehicle)
    end
end

function Notify(msg)
    if Config.UseBuiltInNotifications then
        local type = "good"
        if CheckIfNotificationIsWrong(msg) then
            type = "wrong"
        end

        SendNUIMessage({
            action = "showNotification",
            type = type,
            msg = msg
        })
    else
        if Config.Framework == "QBCore" then
            Core.Functions.Notify(msg)
        elseif Config.Framework == "ESX" then
            Core.ShowNotification(msg)
        else
            SetNotificationTextEntry('STRING')
            AddTextComponentString(msg)
            DrawNotification(false, true)
        end
    end
end

function SetVehicle(vehicle)
    local model = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
    local plate = GetVehicleNumberPlateText(vehicle)
    if plate ~= nil and plate ~= "" then
        IssuedVehicleKeys[plate] = { plate = plate, model = model }

        -- Keys Systems
        if GetResourceState("qs-vehiclekeys") == "started" then
            exports["qs-vehiclekeys"]:GiveKeys(plate, model, true)
        end

        if GetResourceState("0r-vehiclekeys") == "started" then
            exports["0r-vehiclekeys"]:GiveKeys(plate)
        end

        if GetResourceState("cd_garage") == "started" then TriggerEvent('cd_garage:AddKeys', plate) end
        if GetResourceState("vehicles_keys") == "started" then TriggerServerEvent("vehicles_keys:selfGiveVehicleKeys", plate) end
        if GetResourceState("qb-vehiclekeys") == "started" then TriggerEvent("vehiclekeys:client:SetOwner", plate) end
    end


    -- Fuel systems
    if GetResourceState("LegacyFuel") == "started" then
        exports["LegacyFuel"]:SetFuel(vehicle, 100.0)
    end

    if GetResourceState("cdn-fuel") == "started" then
        exports["cdn-fuel"]:SetFuel(vehicle, 100.0)
    end

    if GetResourceState("ps-fuel") == "started" then
        exports["ps-fuel"]:SetFuel(vehicle, 100.0)
    end
	
    if GetResourceState("lc_fuel") == "started" then
        exports["lc_fuel"]:SetFuel(vehicle, 100.0)
    end

    Entity(vehicle).state.fuel = 100.0
end

function RemoveKeys()
    for plate, vehicleKey in pairs(IssuedVehicleKeys) do
        if GetResourceState("qs-vehiclekeys") == "started" then
            exports["qs-vehiclekeys"]:RemoveKeys(plate, vehicleKey.model)
        end
	
        if GetResourceState("0r-vehiclekeys") == "started" then
            exports["0r-vehiclekeys"]:RemoveKeys(plate)
        end

        if GetResourceState("qb-vehiclekeys") == "started" then
            TriggerEvent("qb-vehiclekeys:client:RemoveKeys", plate)
        end

    end
    IssuedVehicleKeys = {}
end


function PrepeareVehicle()
    -- Before Vehicle spawn
end

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 500
    DrawRect(_x, _y + 0.0125, 0.030 + factor, 0.03, 0, 0, 0, 150)
end

function ShowHelpNotification(msg)
    if msg == nil then return end
    AddTextEntry('HelpNotification', msg)
    DisplayHelpTextThisFrame('HelpNotification', false)
end

function IsDead(ped)
    return GetEntityHealth(ped) <= 0
end

function ChangeClothes(type)
    if Config.Framework ~= "QBCore" and Config.Framework ~= "ESX" then
        return print("CANNOT CHANGE CLOTHES, PLEASE CONFIGURE UR CLOTHES SYSTEM IN /Client/Functions.lua file.")
    end

    if not LoadAnimDictWithTimeout("clothingshirt") then return end

    local PlayerPed = PlayerPedId()
    TaskPlayAnim(PlayerPed, "clothingshirt", "try_shirt_positive_d", 8.0, 1.0, -1, 49, 0, false, false, false)
    Wait(1000)

    if type == "work" then
        if GetEntityModel(PlayerPed) == 1885233650 then
            for k,v in pairs(Config.realClothes.male) do
                if v.isProp then
                    SetPedPropIndex(PlayerPed, v["component_id"], v["drawable"], v["texture"], true)
                else
                    SetPedComponentVariation(PlayerPed, v["component_id"], v["drawable"], v["texture"], 0)
                end
            end
        else
            for k,v in pairs(Config.realClothes.female) do
                if v.isProp then
                    SetPedPropIndex(PlayerPed, v["component_id"], v["drawable"], v["texture"], true)
                else
                    SetPedComponentVariation(PlayerPed, v["component_id"], v["drawable"], v["texture"], 0)
                end
            end
        end
    else
        if Config.Framework == "QBCore" then
            TriggerServerEvent('qb-clothes:loadPlayerSkin')
        elseif Config.Framework == "ESX" then
            Core.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                TriggerEvent('skinchanger:loadSkin', skin)
            end)
        end

        TriggerEvent("fivem-appearance:client:reloadSkin")
        TriggerEvent("fivem-appearance:ReloadSkin")
        TriggerEvent("illenium-appearance:client:reloadSkin")
        TriggerEvent("illenium-appearance:ReloadSkin")
    end

    Wait(1000)
    ClearPedTasks(PlayerPed)
end

function CheckIfNotificationIsWrong(text)
    local arrayName

    for k,v in pairs(Config.Lang) do
        if v == text then
            arrayName = k
            break
        end
    end

    return Config.WrongNotifications[arrayName] or false
end

Config.WrongNotifications = {
    ["no_permission"] = true,
    ["too_far"] = true,
    ["alreadyWorking"] = true,
    ["wrongCar"] = true,
    ["CarNeeded"] = true,
    ["nobodyNearby"] = true,
    ["cantInvite"] = true,
    ["spawnpointOccupied"] = true,
    ["pipesNotReady"] = true,
    ["workstationOccupied"] = true,
    ["notFullJob"] = true,
    ["notADriver"] = true,
    ["partyIsFull"] = true,
    ["wrongReward1"] = true,
    ["wrongReward2"] = true,
    ["isAlreadyHost"] = true,
    ["isBusy"] = true,
    ["hasActiveInvite"] = true,
    ["HaveActiveInvite"] = true,
    ["InviteDeclined"] = true,
    ["error"] = true,
    ["kickedOut"] = true,
    ["RequireOneFriend"] = true,
    ["clientsPenalty"] = true,
    ["noMixerStatus"] = true,
    ["dontHaveReqItem"] = true,
    ["notEverybodyHasRequiredJob"] = true,
}

Config.realClothes = {
    male = {},
    female = {},
}

local componentIdTranslation = {
    ['head'] = 0,
    ["mask"] = 1,
    ["arms"] = 3,
    ["pants"] = 4,
    ["bag"] = 5,
    ["shoes"] = 6,
    ["t-shirt"] = 8,
    ["torso"] = 11,
    ["decals"] = 10,
    ["kevlar"] = 9,
}

for k,v in pairs(Config.Clothes.male) do
    table.insert(Config.realClothes.male, {
        component_id = componentIdTranslation[k],
        drawable = v.clotheId, texture = v.variation,
        isProp = k == 'head',
    })
end

for k,v in pairs(Config.Clothes.female) do
    table.insert(Config.realClothes.female, {
        component_id = componentIdTranslation[k],
        drawable = v.clotheId, texture = v.variation,
        isProp = k == 'head',
    })
end

CraneControls = {
    ['LeftMouseButton'] = 24,
    ['INPUT_MOVE_LR'] = 30,
    ['INPUT_MOVE_UD'] = 31,
    ['W'] = 32,
    ['S'] = 33,
    ['A'] = 34,
    ['D'] = 35,
    ['E'] = 38,
    ['Q'] = 44,
    ['ArrowDown'] = 187,
    ['ArrowUp'] = 188,
    ['ArrowLeft'] = 189,
    ['ArrowRight'] = 190,
    ['ESC'] = 200,
    ["INPUT_VEH_MOVE_LR"] = 59,
    ["INPUT_VEH_MOVE_LEFT_ONLY"] = 63,
    ["INPUT_VEH_MOVE_RIGHT_ONLY"] = 64,
    ["INPUT_VEH_ACCELERATE"] = 71,
    ["INPUT_VEH_BRAKE"] = 72,
    ["INPUT_VEH_NEXT_RADIO"] = 85,
}
