local spawnedTargetPeds = {}

local function GetTargetSystem()
    if Config.Framework == "QBCore" and GetResourceState("qb-target") == "started" then return "qb-target" end
    if GetResourceState("qtarget") == "started" then return "qtarget" end
    if GetResourceState("ox_target") == "started" then return "ox_target" end
    if GetResourceState("qb-target") == "started" then return "qb-target" end
    return nil
end

function IsLumberjackTargetAvailable()
    return GetTargetSystem() ~= nil
end

local function IsTargetResource(resourceName)
    return resourceName == "qb-target" or resourceName == "qtarget" or resourceName == "ox_target"
end

local function AddLocalTarget(entity, option, distance)
    local targetSystem = GetTargetSystem()
    if targetSystem == nil then return false end

    if targetSystem == "ox_target" then
        exports.ox_target:addLocalEntity(entity, {
            {
                name = option.name,
                icon = option.icon,
                label = option.label,
                distance = distance,
                canInteract = option.canInteract,
                onSelect = option.action or function() TriggerEvent(option.event) end,
            },
        })
    else
        exports[targetSystem]:AddTargetEntity(entity, {
            options = { option },
            distance = distance,
        })
    end
    return true
end

local function RemoveLocalTarget(entity, optionName)
    local targetSystem = GetTargetSystem()
    if targetSystem == "ox_target" then
        exports.ox_target:removeLocalEntity(entity, optionName and { optionName } or nil)
    elseif targetSystem ~= nil then
        exports[targetSystem]:RemoveTargetEntity(entity)
    end
end

local function CreateTargetPed(model, coords, heading, option)
    if not LoadModelWithTimeout(model) then return nil end
    local ped = CreatePed(0, model, coords.x, coords.y, coords.z - 1.0, heading, false, true)
    if ped == 0 or not DoesEntityExist(ped) then return nil end

    DecorSetBool(ped, "entityIsNeeded", true)
    FreezeEntityPosition(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetEntityInvincible(ped, true)
    AddLocalTarget(ped, option, 2.5)
    table.insert(spawnedTargetPeds, ped)
    return ped
end

function DeleteTargetPeds()
    for _, ped in ipairs(spawnedTargetPeds) do
        if DoesEntityExist(ped) then
            RemoveLocalTarget(ped)
            DeleteEntity(ped)
        end
    end
    spawnedTargetPeds = {}
    SpawnedPed = nil
end

function SpawnPeds()
    if #spawnedTargetPeds > 0 or GetTargetSystem() == nil then return end

    local dutyCoords = Config.Locations.DutyToggle.Coords[1]
    SpawnedPed = CreateTargetPed(`a_m_m_bevhills_02`, dutyCoords, 66.74, {
        name = "17mov_lumberjack_duty",
        event = "multiplayerLumberjack:OpenMainMenu",
        icon = "fa-solid fa-handshake-simple",
        label = "Start Job",
        canInteract = function()
            return #(GetEntityCoords(PlayerPedId()) - dutyCoords) < 5.0
        end,
    })

    if not Config.EnableVehicleLegacyMode then return end

    local forkliftCoords = Config.Locations.rentForklift.Coords[1]
    CreateTargetPed(`a_m_m_rurmeth_01`, forkliftCoords, 182.1, {
        name = "17mov_lumberjack_forklift",
        event = "muliplayerLumberjack:OpenForkliftMenu",
        icon = "fa-solid fa-handshake-simple",
        label = "Rent Forklift",
        canInteract = function()
            return OnDuty and #(GetEntityCoords(PlayerPedId()) - forkliftCoords) < 5.0
        end,
    })

    local truckCoords = Config.Locations.WithdrawTruck.Coords[1]
    CreateTargetPed(`a_m_m_salton_02`, truckCoords, 69.96, {
        name = "17mov_lumberjack_truck",
        event = "muliplayerLumberjack:OpenTruckMenu",
        icon = "fa-solid fa-handshake-simple",
        label = "Rent Truck",
        canInteract = function()
            return OnDuty and #(GetEntityCoords(PlayerPedId()) - truckCoords) < 5.0
        end,
    })
end

RegisterNetEvent("multiplayerLumberjack:OpenMainMenu", function()
    OpenDutyMenu()
end)

RegisterNetEvent("muliplayerLumberjack:OpenForkliftMenu", function()
    OpenPanel("rentForklift")
end)

RegisterNetEvent("muliplayerLumberjack:OpenTruckMenu", function()
    OpenPanel("rentTruck")
end)

function DeleteTreeFromTarget(entity)
    RemoveLocalTarget(entity, "17mov_lumberjack_tree")
end

function AddTreeToTarget(entity, array)
    AddLocalTarget(entity, {
        name = "17mov_lumberjack_tree",
        icon = "fa-solid fa-tree",
        label = "Cut down tree",
        action = function() CutDownTree(array) end,
    }, 1.5)
end

AddEventHandler("onClientResourceStop", function(resourceName)
    if resourceName == GetCurrentResourceName() then
        DeleteTargetPeds()
    elseif Config.UseTarget and IsTargetResource(resourceName) then
        MarkersActive = false
        TreeTargetsAdded = {}
        DeleteTargetPeds()
        SetTimeout(750, function()
            if StartMarkers then StartMarkers(PlayerData or { job = { name = "unknown" } }) end
        end)
    end
end)

AddEventHandler("onClientResourceStart", function(resourceName)
    if not Config.UseTarget or not IsTargetResource(resourceName) then return end
    MarkersActive = false
    TreeTargetsAdded = {}
    DeleteTargetPeds()
    SetTimeout(750, function()
        if StartMarkers then StartMarkers(PlayerData or { job = { name = "unknown" } }) end
    end)
end)
