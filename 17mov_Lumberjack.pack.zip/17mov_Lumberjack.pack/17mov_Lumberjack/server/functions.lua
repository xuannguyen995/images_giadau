local Core
Config.Framework = "STANDALONE"

local function IsResourceAvailable(resourceName)
    local state = GetResourceState(resourceName)
    return state == "started" or state == "starting"
end

function RefreshFramework()
    local detectedCore
    local detectedFramework = "STANDALONE"

    if IsResourceAvailable("qb-core") then
        local ok, result = pcall(function()
            return exports["qb-core"]:GetCoreObject()
        end)
        if ok and result ~= nil then
            detectedCore = result
            detectedFramework = "QBCore"
        end
    end

    if detectedCore == nil and IsResourceAvailable("es_extended") then
        local ok, result = pcall(function()
            return exports["es_extended"]:getSharedObject()
        end)
        if ok and result ~= nil then
            detectedCore = result
            detectedFramework = "ESX"
        end
    end

    -- Keep compatibility with older framework releases that expose only the
    -- legacy CFX export event. QBCore intentionally has deterministic priority.
    if detectedCore == nil and IsResourceAvailable("qb-core") then
        TriggerEvent("__cfx_export_qb-core_GetCoreObject", function(getCore)
            if detectedCore == nil then
                detectedCore = getCore()
                detectedFramework = "QBCore"
            end
        end)
    end

    if detectedCore == nil and IsResourceAvailable("es_extended") then
        TriggerEvent("__cfx_export_es_extended_getSharedObject", function(getCore)
            if detectedCore == nil then
                detectedCore = getCore()
                detectedFramework = "ESX"
            end
        end)
    end

    if detectedCore == nil and IsResourceAvailable("es_extended") then
        TriggerEvent("esx:getSharedObject", function(result)
            if detectedCore == nil then
                detectedCore = result
                detectedFramework = "ESX"
            end
        end)
    end

    Core = detectedCore
    Config.Framework = detectedCore and detectedFramework or "STANDALONE"
    return Config.Framework
end

RefreshFramework()

AddEventHandler("onResourceStart", function(resourceName)
    if resourceName == "qb-core" or resourceName == "es_extended" then
        RefreshFramework()
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName == "qb-core" or resourceName == "es_extended" then
        Core = nil
        Config.Framework = "STANDALONE"
        RefreshFramework()
    end
end)

local cachedNames = {}
function GetPlayerIdentity(source)
    if cachedNames[source] ~= nil then
        return cachedNames[source]
    end

    if Config.Framework == "QBCore" then
        local xPlayer = Core.Functions.GetPlayer(source)

        local timeout = 50
        while xPlayer == nil and timeout > 0 do
            Wait(100)
            xPlayer = Core.Functions.GetPlayer(source)
            timeout = timeout - 1
        end

        if xPlayer == nil then return GetPlayerName(source) or "Unknown Player" end

        cachedNames[source] = xPlayer.PlayerData.charinfo.firstname .. " " .. xPlayer.PlayerData.charinfo.lastname
    elseif Config.Framework == "ESX" then
        local xPlayer = Core.GetPlayerFromId(source)

        local timeout = 50
        while xPlayer == nil and timeout > 0 do
            Wait(100)
            xPlayer = Core.GetPlayerFromId(source)
            timeout = timeout - 1
        end

        if xPlayer == nil then return GetPlayerName(source) or "Unknown Player" end

        cachedNames[source] = xPlayer.getName()
    else
        cachedNames[source] = GetPlayerName(source) or "Unknown Player"
    end

    return cachedNames[source]
end

function Notify(source, msg)
    if Config.UseBuiltInNotifications then
        TriggerClientEvent("17mov_DrawDefaultNotification"..GetCurrentResourceName(), source, msg)
    else
        if Config.Framework == "QBCore" then
            TriggerClientEvent("QBCore:Notify", source, msg)
        elseif Config.Framework == "ESX" then
            TriggerClientEvent("esx:showNotification", source, msg)
        else
            TriggerClientEvent("17mov_DrawDefaultNotification"..GetCurrentResourceName(), source, msg)
        end
    end
end

local function IsFiniteNumber(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function MergeRewardItems(...)
    local merged = {}

    for tableIndex = 1, select("#", ...) do
        local rewardTable = select(tableIndex, ...)
        if type(rewardTable) == "table" then
            for itemName, count in pairs(rewardTable) do
                if type(itemName) == "string" and IsFiniteNumber(count) and count > 0 then
                    merged[itemName] = (merged[itemName] or 0) + math.floor(count)
                end
            end
        end
    end

    return merged
end

function Pay(source, amount, logsItem, planksItems, chipsItems, lobbySize)
    if not IsFiniteNumber(amount) or amount < 0 then
        return false, "invalid_amount"
    end

    amount = math.floor(amount)
    local rewardItems = MergeRewardItems(logsItem, planksItems, chipsItems)

    if Config.Framework == "QBCore" then
        local player = Core and Core.Functions and Core.Functions.GetPlayer(source)
        if player == nil or player.Functions == nil then
            return false, "invalid_player"
        end

        local addedItems = {}
        for itemName, count in pairs(rewardItems) do
            local added = player.Functions.AddItem(itemName, count)
            if added == false then
                for rollbackName, rollbackCount in pairs(addedItems) do
                    player.Functions.RemoveItem(rollbackName, rollbackCount)
                end
                return false, "inventory_full"
            end
            addedItems[itemName] = count
        end

        if amount > 0 and player.Functions.AddMoney("cash", amount) == false then
            for rollbackName, rollbackCount in pairs(addedItems) do
                player.Functions.RemoveItem(rollbackName, rollbackCount)
            end
            return false, "money_failed"
        end

        return true
    elseif Config.Framework == "ESX" then
        local player = Core and Core.GetPlayerFromId(source)
        if player == nil or player.addMoney == nil or player.addInventoryItem == nil then
            return false, "invalid_player"
        end

        if player.canCarryItem ~= nil then
            for itemName, count in pairs(rewardItems) do
                if not player.canCarryItem(itemName, count) then
                    return false, "inventory_full"
                end
            end
        end

        local addedItems = {}
        for itemName, count in pairs(rewardItems) do
            local ok = pcall(player.addInventoryItem, itemName, count)
            if not ok then
                if player.removeInventoryItem ~= nil then
                    for rollbackName, rollbackCount in pairs(addedItems) do
                        pcall(player.removeInventoryItem, rollbackName, rollbackCount)
                    end
                end
                return false, "inventory_failed"
            end
            addedItems[itemName] = count
        end

        local paid = pcall(player.addMoney, amount)
        if not paid then
            if player.removeInventoryItem ~= nil then
                for rollbackName, rollbackCount in pairs(addedItems) do
                    pcall(player.removeInventoryItem, rollbackName, rollbackCount)
                end
            end
            return false, "money_failed"
        end

        return true
    end

    return false, "standalone_payment_not_configured"
end

function PayPenalty(source, amount)
    if not IsFiniteNumber(amount) or amount < 0 then
        return false
    end
    amount = math.floor(amount)

    if Config.Framework == "QBCore" then
        local player = Core and Core.Functions and Core.Functions.GetPlayer(source)
        if player ~= nil and player.Functions ~= nil then
            return player.Functions.RemoveMoney("cash", amount) ~= false
        end
    elseif Config.Framework == "ESX" then
        local player = Core and Core.GetPlayerFromId(source)
        if player ~= nil and player.removeMoney ~= nil then
            return pcall(player.removeMoney, amount)
        end
    end

    return false
end

function IsHaveRequiredItem(source)
    if Config.RequiredItem == "none" then
        return true
    end

    if Config.Framework == "QBCore" then
            local player = Core and Core.Functions and Core.Functions.GetPlayer(source)
            if player == nil or player.PlayerData == nil or type(player.PlayerData.items) ~= "table" then
                return false
            end

            local counter = 0
            for _, item in pairs(player.PlayerData.items) do
                if item.name == Config.RequiredItem then
                    local amount = tonumber(item.amount or item.count) or 0
                    counter = counter + amount
                    if counter > 0 then break end
                end
            end

            return counter > 0
    elseif Config.Framework == "ESX" then
        local player = Core and Core.GetPlayerFromId(source)
        if player == nil or player.getInventoryItem == nil then
            return false
        end

        local item = player.getInventoryItem(Config.RequiredItem)
        return item ~= nil and (tonumber(item.count) or 0) > 0
    end

    return false
end

function GetPlayerJob(source)
    if source == nil or type(source) ~= "number" then return "unknown" end
    if Config.Framework == "QBCore" then
        local player = Core and Core.Functions and Core.Functions.GetPlayer(source)
        return player and player.PlayerData and player.PlayerData.job and player.PlayerData.job.name or "unknown"
    elseif Config.Framework == "ESX" then
        local player = Core and Core.GetPlayerFromId(source)
        return player and player.job and player.job.name or "unknown"
    else
        return "unknown"
    end
end

function ClearPlayerIdentityCache(source)
    cachedNames[source] = nil
end
