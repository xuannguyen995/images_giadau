local Lobbies = {}
local PendingInvites = {}
local ServerCallbacks = {}
local MaxLobbyMembers = Config.LimitLobbyToTwoMembers and 2 or 4
local AttachedObjectsData = {}
local TreesData = {}
local CranesData = {}
local PendingLogBatches = {}
local ActionTimestamps = {}
local CraneActionListeners = {}

local ValidVehicleRoles = {
    JobVehicle = true,
    JobVehicle2 = true,
    JobFlatbed = true,
    JobTruck = true,
    JobForklift = true,
    JobPickup = true,
}

local AllowedSounds = {
    ["chainsaw.mp3"] = true,
    ["logroll.mp3"] = true,
    ["treefall.mp3"] = true,
}

local function IsFiniteNumber(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function IsIntegerInRange(value, minimum, maximum)
    return IsFiniteNumber(value) and value == math.floor(value) and value >= minimum and value <= maximum
end

local function IsValidPlayer(playerId)
    return type(playerId) == "number" and playerId > 0 and GetPlayerPing(playerId) ~= 0
end

local function GetLobbyForPlayer(playerId, requireWorking)
    for lobbyIndex, lobby in pairs(Lobbies) do
        local isMember = lobby.host == playerId
        if not isMember then
            for _, clientId in ipairs(lobby.clients or {}) do
                if clientId == playerId then
                    isMember = true
                    break
                end
            end
        end

        if isMember and (not requireWorking or lobby.working) then
            return lobbyIndex, lobby
        end
    end

    return nil, nil
end

local function IsLobbyHost(playerId, lobby)
    return lobby ~= nil and lobby.host == playerId
end

local function IsNearCoords(playerId, coords, maximumDistance)
    if not IsValidPlayer(playerId) or coords == nil then
        return false
    end

    local ped = GetPlayerPed(playerId)
    if ped == nil or ped == 0 or not DoesEntityExist(ped) then
        return false
    end

    local playerCoords = GetEntityCoords(ped)
    local dx = playerCoords.x - coords.x
    local dy = playerCoords.y - coords.y
    local dz = playerCoords.z - coords.z
    return dx * dx + dy * dy + dz * dz <= maximumDistance * maximumDistance
end

local function IsNearAnyStation(playerId, stationType, maximumDistance, requestedIndex)
    local stations = Config.Stations[stationType]
    if type(stations) ~= "table" then
        return false, nil
    end

    for stationIndex, station in ipairs(stations) do
        if (requestedIndex == nil or stationIndex == requestedIndex)
            and IsNearCoords(playerId, station.coords, maximumDistance) then
            return true, stationIndex
        end
    end

    return false, nil
end

local function AllowAction(playerId, actionName, minimumInterval)
    local now = GetGameTimer()
    local playerActions = ActionTimestamps[playerId]
    if playerActions == nil then
        playerActions = {}
        ActionTimestamps[playerId] = playerActions
    end

    local previous = playerActions[actionName]
    if previous ~= nil and now - previous < minimumInterval then
        return false
    end

    playerActions[actionName] = now
    return true
end

local function FindAttachedObject(vehicleNetId, slot, objectType)
    local objectList = AttachedObjectsData[vehicleNetId]
    if type(objectList) ~= "table" then
        return nil, nil
    end

    for objectIndex, object in pairs(objectList) do
        if object and object.slot == slot and object.type == objectType then
            return objectIndex, object
        end
    end

    return nil, nil
end

local function IsLobbyVehicle(lobby, vehicleNetId)
    if lobby == nil or not IsIntegerInRange(vehicleNetId, 1, 2147483647) then
        return false
    end

    for vehicleRole in pairs(ValidVehicleRoles) do
        if lobby[vehicleRole] == vehicleNetId then
            return true
        end
    end

    return false
end

local function IsSafeVector(value)
    local valueType = type(value)
    if valueType ~= "table" and valueType ~= "vector3" and valueType ~= "vector4" then
        return false
    end

    return IsFiniteNumber(value.x) and IsFiniteNumber(value.y) and IsFiniteNumber(value.z)
end

local function IsBoundedVector(value, maximumAbsoluteValue)
    return IsSafeVector(value)
        and math.abs(value.x) <= maximumAbsoluteValue
        and math.abs(value.y) <= maximumAbsoluteValue
        and math.abs(value.z) <= maximumAbsoluteValue
end

local function IsVectorNear(value, reference, maximumDistance)
    if not IsSafeVector(value) or reference == nil then return false end
    local dx = value.x - reference.x
    local dy = value.y - reference.y
    local dz = value.z - reference.z
    return dx * dx + dy * dy + dz * dz <= maximumDistance * maximumDistance
end

local function IncrementCargoRevision(lobby)
    lobby.cargoRevision = (lobby.cargoRevision or 0) + 1
    lobby.saleSession = nil
end

local function NextFreeIndex(values)
    local index = 1
    while values[index] ~= nil do index = index + 1 end
    return index
end

local function DeleteNetworkEntity(netId)
    if not IsIntegerInRange(netId, 1, 2147483647) then return false end
    local entity = NetworkGetEntityFromNetworkId(netId)
    if entity == 0 or not DoesEntityExist(entity) then return false end
    DeleteEntity(entity)
    return true
end

local function BeginTreeRespawn(treeId)
    CreateThread(function()
        Wait(Config.TreeRespawnTime)

        local tree = TreesData[treeId]
        if tree == nil then
            return
        end

        tree.isAvalible = true
        tree.reservedBy = nil
        tree.reservedUntil = nil
        tree.completedBy = nil
        tree.awaitingFallBroadcast = nil
        TriggerClientEvent("17mov_Lumberjack:RespawnThisTree", -1, treeId)
    end)
end

local function CompleteReservedTree(playerId, treeId, fallHeading, broadcastFall)
    local _, lobby = GetLobbyForPlayer(playerId, true)
    local tree = TreesData[treeId]
    local now = GetGameTimer()

    if lobby == nil or tree == nil or not tree.isAvalible then
        return false
    end

    if tree.reservedBy ~= playerId or tree.reservedUntil == nil or tree.reservedUntil < now then
        return false
    end

    if not IsNearCoords(playerId, tree.coords, 8.0) then
        return false
    end

    if broadcastFall and (not IsFiniteNumber(fallHeading) or fallHeading < -360.0 or fallHeading > 360.0) then
        return false
    end

    tree.isAvalible = false
    tree.reservedBy = nil
    tree.reservedUntil = nil
    tree.completedBy = playerId
    tree.awaitingFallBroadcast = not broadcastFall

    PendingLogBatches[playerId] = {
        treeId = treeId,
        coords = tree.coords,
        expiresAt = now + 20000,
    }

    TriggerClientEvent("17mov_Lumberjack:DeleteThisID", -1, treeId)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:updateCounter")

    if broadcastFall then
        TriggerClientEvent("17mov_lumberjack:StartFallAnim", -1, treeId, fallHeading)
    end

    BeginTreeRespawn(treeId)
    return true
end

local NativeGetPlayerIdentifierByType = GetPlayerIdentifierByType
function GetPlayerIdentifierByType(playerId, identifierType)
    if playerId == nil then
        return 0
    end

    if NativeGetPlayerIdentifierByType ~= nil then
        return NativeGetPlayerIdentifierByType(playerId, identifierType)
    else
        return GetPlayerIdentifier(playerId, 1)
    end
end

local NativeGetPlayerPing = GetPlayerPing
function GetPlayerPing(playerId)
    if playerId then
        if type(playerId) == "number" then
            return NativeGetPlayerPing(playerId)
        end
    else
        return 0
    end
end

Config.EnableRestoreAfterCrash = false

function RecalculateRewards(hostId)
    local lobbyIndex

    for index, lobby in pairs(Lobbies) do
        if lobby.host == hostId then
            lobbyIndex = index
        end
    end

    if lobbyIndex == nil or Lobbies[lobbyIndex] == nil then
        return false
    end

    Lobbies[lobbyIndex].rewardsOptions = {}

    local memberCount = #Lobbies[lobbyIndex].clients + 1
    for i = 1, memberCount - 1, 1 do
        local clientId = Lobbies[lobbyIndex].clients[i]
        Lobbies[lobbyIndex].rewardsOptions[clientId] = math.floor(100 / memberCount)
    end

    Lobbies[lobbyIndex].rewardsOptions[hostId] = math.floor(100 / memberCount)

    TriggerForAllMembers(hostId, "17mov_lumberjack:SetMyReward", math.floor(100 / memberCount))
    TriggerClientEvent("17mov_lumberjack:UpdateHostPercentages", hostId, math.floor(100 / memberCount))
    return true
end

function RegisterServerCallback(name, callback)
    ServerCallbacks[name] = callback
end

RegisterNetEvent("17mov_Callbacks:GetResponse" .. GetCurrentResourceName(), function(callbackName, requestId, ...)
    local playerSource = source
    if type(callbackName) ~= "string" or #callbackName > 100
        or not IsIntegerInRange(requestId, 1, 2147483647) then
        return
    end

    if not AllowAction(playerSource, "callback", 10) then
        TriggerClientEvent("17mov_Callbacks:receiveData" .. GetCurrentResourceName(), playerSource, callbackName, requestId, nil)
        return
    end

    local callback = ServerCallbacks[callbackName]
    if callback == nil then
        TriggerClientEvent("17mov_Callbacks:receiveData" .. GetCurrentResourceName(), playerSource, callbackName, requestId, nil)
        return
    end

    local response = table.pack(pcall(callback, playerSource, ...))
    if not response[1] then
        print(("[17mov_Lumberjack] callback '%s' failed: %s"):format(callbackName, tostring(response[2])))
        TriggerClientEvent("17mov_Callbacks:receiveData" .. GetCurrentResourceName(), playerSource, callbackName, requestId, nil)
        return
    end

    TriggerClientEvent(
        "17mov_Callbacks:receiveData" .. GetCurrentResourceName(),
        playerSource, callbackName, requestId,
        table.unpack(response, 2, response.n)
    )
end)

RegisterServerCallback("17mov_lumberjack:requestLogsData", function(playerId)
    return AttachedObjectsData
end)

RegisterServerCallback("17mov_lumberjack:GetTreesData", function(playerId)
    local deadline = GetGameTimer() + 5000
    while #TreesData == 0 and GetGameTimer() < deadline do
        Wait(100)
    end

    return TreesData
end)

RegisterServerCallback("17mov_Lumberjack:ReserveTree", function(playerId, treeId)
    if not IsIntegerInRange(treeId, 1, #TreesData) or not AllowAction(playerId, "reserveTree", 500) then
        return false
    end

    local _, lobby = GetLobbyForPlayer(playerId, true)
    local tree = TreesData[treeId]
    local now = GetGameTimer()
    if lobby == nil or tree == nil or not tree.isAvalible or not IsNearCoords(playerId, tree.coords, 8.0) then
        return false
    end
    if tree.reservedBy ~= nil and tree.reservedBy ~= playerId and (tree.reservedUntil or 0) >= now then
        return false
    end

    tree.reservedBy = playerId
    tree.reservedUntil = now + 30000
    return true
end)

RegisterServerCallback("17mov_Lumberjack:CompleteTree", function(playerId, treeId, fallHeading)
    if not IsIntegerInRange(treeId, 1, #TreesData) then return false end
    return CompleteReservedTree(playerId, treeId, fallHeading, true)
end)

RegisterNetEvent("17mov_Lumberjack:CancelTreeReservation", function(treeId)
    local tree = TreesData[treeId]
    if tree and tree.reservedBy == source then
        tree.reservedBy = nil
        tree.reservedUntil = nil
    end
end)

RegisterServerCallback("17mov_Lumberjack:GetPrice", function(playerId, stationIndex, stationType)
    if stationType ~= "sellChips" and stationType ~= "sellLogs" and stationType ~= "sellPlanks" then
        return nil
    end

    local stations = Config.Stations[stationType]
    if type(stations) ~= "table" or not IsIntegerInRange(stationIndex, 1, #stations) then
        return nil
    end

    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or not IsNearCoords(playerId, stations[stationIndex].coords, 25.0) then
        return nil
    end

    if stationType == "sellChips" then return stations[stationIndex].pricePerPercent end
    if stationType == "sellLogs" then return stations[stationIndex].pricePerLog end
    return stations[stationIndex].pricePerPallete
end)

RegisterServerCallback("17mov_lumberjack:CheckIfCanWithdrawTruck", function(playerId)
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil then return false end

    if lobby.logCarHidden then
        if not lobby.JobTruck then
            return true
        else
            Notify(playerId, Config.Lang.alreadyRentedOneTruck)
            return false
        end
    else
        Notify(playerId, Config.Lang.LogCarNotHidden)
        return false
    end
end)

RegisterNetEvent("17mov_Lumberjack:UpdateLogCounter")
AddEventHandler("17mov_Lumberjack:UpdateLogCounter", function()
    -- Compatibility-only event. The counter is changed only after the server
    -- validates a log attachment in AttachPropToHook.
    return
end)

RegisterServerCallback("17mov_lumberjack:getVehicles", function(playerId)
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil then return nil, nil end
    return lobby.JobVehicle, lobby.JobFlatbed
end)

RegisterServerCallback("17mov_lumberjack:CheckIfCanRentForklift", function(playerId)
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil then return false end

    if not lobby.JobForklift then
        return true
    else
        Notify(playerId, Config.Lang.alreadyRentedOneForklift)
        return false
    end
end)

RegisterServerCallback("17mov_lumberjack:CheckThisReward", function(playerId, rewardPercent, targetId)
    local _, lobby = GetLobbyForPlayer(playerId, false)
    if lobby == nil or not IsLobbyHost(playerId, lobby)
        or not IsIntegerInRange(rewardPercent, 0, 100)
        or not IsValidPlayer(targetId)
        or lobby.rewardsOptions[targetId] == nil then
        return false
    end

    local totalPercent = 0
    for memberId, percent in pairs(lobby.rewardsOptions) do
        if memberId ~= targetId then
            totalPercent = totalPercent + percent
        end
    end

    if totalPercent + rewardPercent > 100 then
        return false
    end

    lobby.rewardsOptions[targetId] = rewardPercent
    TriggerClientEvent("17mov_lumberjack:SetMyReward", targetId, rewardPercent)
    return true
end)

RegisterServerCallback("17mov_lumberjack:GetPlayersNames", function(playerId, playerIds)
    local players = {}
    if type(playerIds) ~= "table" or #playerIds > 32 then return players end

    for i = 1, #playerIds, 1 do
        local targetId = tonumber(playerIds[i])
        if targetId and targetId ~= playerId and IsValidPlayer(targetId)
            and IsNearCoords(playerId, GetEntityCoords(GetPlayerPed(targetId)), 20.0) then
            table.insert(players, {
                id = targetId,
                name = GetPlayerIdentity(targetId),
            })
        end
    end

    return players
end)

RegisterServerCallback("17mov_lumberjack:GetLobbyMembers", function(playerId, hostId)
    local _, lobby = GetLobbyForPlayer(playerId, false)
    if lobby == nil or hostId ~= lobby.host then return {} end

    local members = { lobby.host }
    for _, clientId in ipairs(lobby.clients) do table.insert(members, clientId) end

    return members
end)

RegisterServerCallback("17mov_lumberjack:IfPlayerOwnsTeam", function(playerId)
    local ownsTeam = false

    for index, lobby in pairs(Lobbies) do
        if lobby.host == playerId then
            ownsTeam = true
            break
        end
    end

    return ownsTeam
end)

RegisterServerCallback("17mov_lumberjack:IfPlayerIsHost", function(playerId)
    local _, lobby = GetLobbyForPlayer(playerId, false)
    return lobby == nil or lobby.host == playerId
end)

RegisterServerCallback("17mov_lumberjack:init", function(playerId)
    return {
        name = GetPlayerIdentity(playerId),
        source = playerId,
    }
end)

RegisterNetEvent("17mov_lumberjack:SendRequestToClient_sv")
AddEventHandler("17mov_lumberjack:SendRequestToClient_sv", function(targetId)
    local hostId = source
    targetId = tonumber(targetId)
    if not IsValidPlayer(targetId) or targetId == hostId or not AllowAction(hostId, "invite", 1000)
        or not IsNearCoords(hostId, GetEntityCoords(GetPlayerPed(targetId)), 20.0) then
        return
    end

    local _, hostLobby = GetLobbyForPlayer(hostId, false)
    if hostLobby ~= nil and hostLobby.host ~= hostId then
        Notify(hostId, Config.Lang.isBusy)
        return
    end
    if hostLobby ~= nil and hostLobby.working then
        Notify(hostId, Config.Lang.isBusy)
        return
    end

    local _, targetLobby = GetLobbyForPlayer(targetId, false)
    if targetLobby ~= nil then
        Notify(hostId, Config.Lang.isBusy)
        return
    end

    for index, invite in pairs(PendingInvites) do
        if invite.client == targetId then
            Notify(hostId, Config.Lang.hasActiveInvite)
            return
        end

        if invite.host == hostId then
            if invite.client ~= nil then
                Notify(hostId, Config.Lang.HaveActiveInvite)
                return
            end
        end
    end

    local hostClients = hostLobby and hostLobby.clients or {}

    if #hostClients + 1 >= MaxLobbyMembers then
        Notify(hostId, Config.Lang.partyIsFull)
        return
    end

    table.insert(PendingInvites, {
        host = hostId,
        client = targetId,
    })

    Notify(hostId, Config.Lang.inviteSent)
    TriggerClientEvent("17mov_lumberjack:SendRequestToClient_cl", targetId, GetPlayerIdentity(hostId))
end)

RegisterNetEvent("17mov_lumberjack:ClientReactRequest")
AddEventHandler("17mov_lumberjack:ClientReactRequest", function(accepted)
    local playerId = source
    local hostId = nil

    for index, invite in pairs(PendingInvites) do
        if invite.client == playerId then
            hostId = invite.host
            table.remove(PendingInvites, index)
            break
        end
    end

    if hostId == nil or not IsValidPlayer(hostId) then return end
    if accepted ~= true then
        Notify(hostId, Config.Lang.InviteDeclined)
        return
    end

    local _, existingLobby = GetLobbyForPlayer(playerId, false)
    local lobbyIndex, lobby = GetLobbyForPlayer(hostId, false)
    if existingLobby ~= nil or (lobby ~= nil and (lobby.host ~= hostId or lobby.working)) then
        Notify(playerId, Config.Lang.error)
        return
    end

    if lobby == nil then
        lobbyIndex = NextFreeIndex(Lobbies)
        Lobbies[lobbyIndex] = {
            host = hostId,
            clients = {},
        }
        lobby = Lobbies[lobbyIndex]
    end

    if #lobby.clients + 1 >= MaxLobbyMembers then
        Notify(playerId, Config.Lang.partyIsFull)
        return
    end

    table.insert(lobby.clients, playerId)
    RecalculateRewards(hostId)
    Notify(hostId, Config.Lang.InviteAccepted)
    TriggerForAllMembers(hostId, "17mov_lumberjack:RefreshMugs", GetAllPartyMugs(hostId))
end)

RegisterNetEvent("17mov_lumberjack:KickPlayerFromLobby")
AddEventHandler("17mov_lumberjack:KickPlayerFromLobby", function(targetId, notifyTarget, hostId)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, false)
    if lobby == nil or lobby.working then return end

    local kickedId
    if lobby.host == playerId then
        kickedId = tonumber(targetId)
    elseif tonumber(hostId) == playerId then
        kickedId = playerId
    else
        return
    end

    local removed = false
    for index, clientId in ipairs(lobby.clients) do
        if clientId == kickedId then
            table.remove(lobby.clients, index)
            removed = true
            break
        end
    end
    if not removed then return end

    if notifyTarget == true and IsValidPlayer(kickedId) then
        Notify(kickedId, Config.Lang.kickedOut)
    end

    local kickedMug = {
        {
            id = kickedId,
            name = GetPlayerIdentity(kickedId),
            isHost = true,
        },
    }
    TriggerClientEvent("17mov_lumberjack:RefreshMugs", kickedId, kickedMug, kickedId)
    TriggerClientEvent("17mov_lumberjack:clearMyLobby", kickedId)
    TriggerClientEvent("17mov_lumberjack:SetMyReward", kickedId, 100)

    if #lobby.clients == 0 then
        TriggerClientEvent("17mov_lumberjack:clearMyLobby", lobby.host)
        Lobbies[lobbyIndex] = nil
    else
        RecalculateRewards(lobby.host)
        TriggerForAllMembers(lobby.host, "17mov_lumberjack:RefreshMugs", GetAllPartyMugs(lobby.host))
    end
end)

RegisterNetEvent("17mov_lumberjack:UnloadThisLog")
AddEventHandler("17mov_lumberjack:UnloadThisLog", function(stationIndex, quantity)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    local stations = Config.Stations.sellLogs
    if lobby == nil or not IsIntegerInRange(stationIndex, 1, #stations)
        or not IsIntegerInRange(quantity, 1, 32)
        or not CanSellCheck(lobbyIndex, playerId, "logs", stationIndex) then return end

    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:UnloadThisLog", quantity)
    local pricePerLog = stations[stationIndex].pricePerLog

    for _, itemReward in pairs(stations[stationIndex].itemRewards) do
        if lobby.logsItems[itemReward.item_name] == nil then
            lobby.logsItems[itemReward.item_name] = 0
        end

        if math.random(100) <= itemReward.chance then
            lobby.logsItems[itemReward.item_name] = lobby.logsItems[itemReward.item_name] + itemReward.amountPerLog
        end
    end

    lobby.cash = lobby.cash + pricePerLog
end)

RegisterNetEvent("17mov_Lumberjack:ClearThisIDSkip")
AddEventHandler("17mov_Lumberjack:ClearThisIDSkip", function(entityId, vehicleNetId, slot)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not IsLobbyVehicle(lobby, vehicleNetId)
        or not IsIntegerInRange(slot, 1, 3) then return end
    local objectIndex = FindAttachedObject(vehicleNetId, slot, "skip")
    if objectIndex == nil then return end
    table.remove(AttachedObjectsData[vehicleNetId], objectIndex)
    TriggerClientEvent("17mov_Lumberjack:DeleteThisSlotObj", -1, slot, vehicleNetId, "skip")
end)

RegisterNetEvent("17mov_Lumberjack:ClearThisIDPlank")
AddEventHandler("17mov_Lumberjack:ClearThisIDPlank", function(entityId, vehicleNetId, slot)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not IsLobbyVehicle(lobby, vehicleNetId)
        or not IsIntegerInRange(slot, 1, 9) then return end
    local objectIndex = FindAttachedObject(vehicleNetId, slot, "planks")
    if objectIndex == nil then return end
    table.remove(AttachedObjectsData[vehicleNetId], objectIndex)
    TriggerClientEvent("17mov_Lumberjack:DeleteThisSlotObj", -1, slot, vehicleNetId, "planks")
end)

local function GetCargoTypeFromHash(contentType)
    if contentType == Config.Props.logs.hash or contentType == 1366334172 then return "logs" end
    if contentType == 1597396577 then return "planks" end
    if contentType == -1937513394 then return "skip" end
    return nil
end

local function GetAuthoritativeCargo(lobbyIndex, lobby)
    local craneIndex = GetCraneIndexFromLobbyIndex(lobbyIndex)
    local crane = craneIndex and CranesData[craneIndex]
    if crane and IsIntegerInRange(crane.contentQuantity, 1, 32) then
        return GetCargoTypeFromHash(crane.contentType), crane.contentQuantity
    end

    local counts = { logs = 0, planks = 0, skip = 0 }
    for _, object in pairs(AttachedObjectsData[lobby.JobFlatbed] or {}) do
        if counts[object.type] ~= nil then counts[object.type] = counts[object.type] + 1 end
    end
    for contentType, count in pairs(counts) do
        if count > 0 then return contentType, count end
    end
    return nil, 0
end

function CanSellCheck(lobbyIndex, playerId, expectedType, stationIndex)
    local lobby = Lobbies[lobbyIndex]
    local session = lobby and lobby.saleSession
    local stationTypeByCargo = { logs = "sellLogs", planks = "sellPlanks", skip = "sellChips" }
    local stationType = stationTypeByCargo[expectedType]
    if session == nil or session.contentType ~= expectedType or session.stationType ~= stationType
        or session.stationIndex ~= stationIndex or session.remaining < 1
        or not IsNearCoords(playerId, Config.Stations[stationType][stationIndex].coords, 25.0) then
        return false
    end

    session.remaining = session.remaining - 1
    if session.remaining == 0 then
        lobby.lastSoldRevision = session.revision
        lobby.saleSession = nil
    end
    return true
end

RegisterNetEvent("17mov_lumberjack:server:SetElementQuantity")
AddEventHandler("17mov_lumberjack:server:SetElementQuantity", function()
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.saleSession ~= nil or lobby.processingOwner ~= nil then return end

    local contentType, quantity = GetAuthoritativeCargo(lobbyIndex, lobby)
    local stationTypeByCargo = { logs = "sellLogs", planks = "sellPlanks", skip = "sellChips" }
    local stationType = stationTypeByCargo[contentType]
    if stationType == nil or quantity < 1 then return end

    local nearby, stationIndex = IsNearAnyStation(playerId, stationType, 25.0)
    local revision = lobby.cargoRevision or 0
    if not nearby or lobby.lastSoldRevision == revision then return end

    lobby.saleSession = {
        contentType = contentType,
        remaining = quantity,
        revision = revision,
        stationType = stationType,
        stationIndex = stationIndex,
    }
end)

RegisterNetEvent("17mov_lumberjack:UnloadThisPlank")
AddEventHandler("17mov_lumberjack:UnloadThisPlank", function(quantity, stationIndex)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    local stations = Config.Stations.sellPlanks
    if lobby == nil or not IsIntegerInRange(stationIndex, 1, #stations)
        or not IsIntegerInRange(quantity, 1, 9)
        or not CanSellCheck(lobbyIndex, playerId, "planks", stationIndex) then return end

    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:UnloadThisPlank", quantity)
    local pricePerPallete = stations[stationIndex].pricePerPallete
    lobby.cash = lobby.cash + pricePerPallete

    for _, itemReward in pairs(stations[stationIndex].itemRewards) do
        if lobby.plankItems[itemReward.item_name] == nil then
            lobby.plankItems[itemReward.item_name] = 0
        end

        if math.random(100) <= itemReward.chance then
            lobby.plankItems[itemReward.item_name] = lobby.plankItems[itemReward.item_name] + itemReward.amountPerPallete
        end
    end
end)

RegisterNetEvent("17mov_Lumberjack:RemoveLog")
AddEventHandler("17mov_Lumberjack:RemoveLog", function(logNetId)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not IsIntegerInRange(logNetId, 1, 2147483647) then return end
    local logEntity = NetworkGetEntityFromNetworkId(logNetId)
    if logEntity == 0 or not DoesEntityExist(logEntity) then return end
    local entityModel = GetEntityModel(logEntity)

    if (entityModel ~= Config.Props.logs.hash and entityModel ~= 1366334172)
        or not DoesThisLogExistsInSpawnedLogs(source, logNetId) then return end
    RemoveLogFromParty(source, logNetId)
    DeleteEntity(logEntity)
end)

RegisterNetEvent("17mov_lumberjack:UnloadThisSkip")
AddEventHandler("17mov_lumberjack:UnloadThisSkip", function(chipStationIndex, stationIndex)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    local stations = Config.Stations.sellChips
    local chipPercent = lobby and math.max(0, math.min(100, tonumber(lobby.skipsStatus[chipStationIndex]) or 0)) or 0
    if lobby == nil or not IsIntegerInRange(chipStationIndex, 1, 3)
        or not IsIntegerInRange(stationIndex, 1, #stations)
        or chipPercent <= 0
        or not CanSellCheck(lobbyIndex, playerId, "skip", stationIndex) then return end

    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:UnloadThisSkip", chipStationIndex)
    local price = stations[stationIndex].pricePerPercent * chipPercent

    for _, itemReward in pairs(stations[stationIndex].itemRewards) do
        if lobby.chipsItems[itemReward.item_name] == nil then
            lobby.chipsItems[itemReward.item_name] = 0
        end

        if math.random(100) <= itemReward.chance then
            lobby.chipsItems[itemReward.item_name] = lobby.chipsItems[itemReward.item_name] + itemReward.amountPerPercent * chipPercent
        end
    end

    lobby.skipsStatus[chipStationIndex] = 0
    lobby.cash = lobby.cash + price
end)

RegisterNetEvent("17mov_Lumberjack:ForkliftDeleted")
AddEventHandler("17mov_Lumberjack:ForkliftDeleted", function()
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.JobForklift == nil then return end
    DeleteNetworkEntity(lobby.JobForklift)
    lobby.JobForklift = nil
end)

RegisterNetEvent("17mov_Lumberjack:StartAnimation")
AddEventHandler("17mov_Lumberjack:StartAnimation", function(animationData)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.processingOwner ~= source or type(animationData) ~= "table"
        or not IsSafeVector(animationData[1])
        or not IsSafeVector(animationData[2]) or type(animationData[3]) ~= "table"
        or not IsSafeVector(animationData[3].coords)
        or not IsSafeVector(animationData[3].rotation)
        or not IsIntegerInRange(animationData[4], 50, 10000)
        or not IsIntegerInRange(animationData[5], 1, 100)
        or type(animationData[6]) ~= "boolean" or animationData[7] ~= nil
        or (animationData[8] ~= nil and animationData[8] ~= "chips")
        or animationData[5] ~= 1 then
        return
    end

    local isChips = animationData[8] == "chips"
    local expectedSpawn = isChips
        and { x = -469.596283, y = 5333.026, z = 82.56943 }
        or { x = -495.279846, y = 5346.84375, z = 80.76374 }
    local expectedPoint = { x = -499.269531, y = 5348.296, z = 80.46913 }
    local expectedDuration = isChips and 4200 or 1250
    if lobby.processingType ~= (isChips and "chips" or "planks")
        or animationData[4] ~= expectedDuration
        or not IsVectorNear(animationData[1], expectedSpawn, 0.25)
        or not IsVectorNear(animationData[3].coords, expectedPoint, 0.25) then return end

    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:StartAnimation", animationData)
end)

RegisterNetEvent("17mov_Lumberjack:SetProcessedPlanksCount")
AddEventHandler("17mov_Lumberjack:SetProcessedPlanksCount", function(planksCount)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.processingOwner ~= playerId or lobby.processingType ~= "planks"
        or lobby.plankCountCommitted then return end

    local logCount = 0

    if Config.EnableVehicleLegacyMode then
        for _, object in pairs(AttachedObjectsData[lobby.JobFlatbed] or {}) do
            if object.type == "logs" then logCount = logCount + 1 end
        end
    else
        local craneIndex = GetCraneIndexFromLobbyIndex(lobbyIndex)
        local crane = craneIndex and CranesData[craneIndex]
        if crane and (crane.contentType == Config.Props.logs.hash or crane.contentType == 1366334172) then
            logCount = math.floor(tonumber(crane.contentQuantity) or 0)
        end
    end

    local processedCount = math.floor(logCount / (Config.EnableVehicleLegacyMode and 6 or 8))
    if processedCount < 1 then return end
    lobby.plankCountCommitted = true
    lobby.planksToSpawn = processedCount
    lobby.planksReadyToLoad = 0
    TriggerForAllMembers(lobby.host, "17mov_lumberjack:SetProcessedPlanksCount", processedCount)
end)

RegisterNetEvent("17mov_lumberjack:StartLoopOnThisFlatbed")
AddEventHandler("17mov_lumberjack:StartLoopOnThisFlatbed", function(flatbedNetId)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.JobFlatbed ~= flatbedNetId then return end
    for objectListId, objectList in pairs(AttachedObjectsData) do
        if objectListId == flatbedNetId and objectList ~= nil then
            for i = 1, #objectList, 1 do
                if objectList[i].stopLoop ~= nil then
                    objectList[i].stopLoop = nil
                end
            end
        end
    end

    TriggerClientEvent("17mov_lumberjack:StartLoopOnThisFlatbed", -1, flatbedNetId)
end)

RegisterNetEvent("17mov_lumberjack:StopLoopOnThisFlatbed")
AddEventHandler("17mov_lumberjack:StopLoopOnThisFlatbed", function(flatbedNetId)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.JobFlatbed ~= flatbedNetId then return end
    for objectListId, objectList in pairs(AttachedObjectsData) do
        if objectListId == flatbedNetId then
            for i = 1, #objectList, 1 do
                objectList[i].stopLoop = nil
            end
        end
    end

    TriggerClientEvent("17mov_lumberjack:StopLoopOnThisFlatbed", -1, flatbedNetId)
end)

RegisterNetEvent("17mov_lumberjack:endJob_sv")
AddEventHandler("17mov_lumberjack:endJob_sv", function(withVehicle)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.host ~= playerId or lobby.ending
        or not IsNearCoords(playerId, Config.Locations.FinishJob.Coords[1], 25.0) then return end

    local playerVehicle = GetVehiclePedIsIn(GetPlayerPed(playerId), false)
    local returnedWithVehicle = false
    if playerVehicle and playerVehicle ~= 0 then
        local playerVehicleNetId = NetworkGetNetworkIdFromEntity(playerVehicle)
        returnedWithVehicle = IsLobbyVehicle(lobby, playerVehicleNetId)
            and GetPedInVehicleSeat(playerVehicle, -1) == GetPlayerPed(playerId)
    end

    lobby.ending = true
    lobby.working = false

    local members = { lobby.host }
    for _, clientId in ipairs(lobby.clients) do table.insert(members, clientId) end

    if type(lobby.rewardsOptions) ~= "table" then RecalculateRewards(playerId) end
    local totalCash = math.max(0, math.floor(tonumber(lobby.cash) or 0))
    if Config.multiplyRewardWhileWorkingInGroup and not Config.EnableVehicleLegacyMode then
        totalCash = math.floor(totalCash * #members)
    end

    for _, memberId in ipairs(members) do
        if IsValidPlayer(memberId) then
            local memberReward = totalCash
            if Config.letBossSplitReward then
                memberReward = math.floor(totalCash * ((lobby.rewardsOptions[memberId] or 0) / 100))
            end

            if not returnedWithVehicle then
                if PayPenalty(memberId, Config.PenaltyAmount) then
                    Notify(memberId, Config.Lang.penalty .. Config.PenaltyAmount)
                else
                    Notify(memberId, Config.Lang.wentWrong or Config.Lang.error)
                end
            end

            if returnedWithVehicle or Config.DontPayRewardWithoutVehicle == false then
                local paid = Pay(memberId, memberReward, lobby.logsItems, lobby.plankItems, lobby.chipsItems, #members)
                if paid then
                    Notify(memberId, Config.Lang.reward .. memberReward)
                else
                    Notify(memberId, Config.Lang.wentWrong or Config.Lang.error)
                end
            end
        end
    end

    TriggerForAllMembers(playerId, "17mov_lumberjack:endJob_cl", 0)

    for _, logNetId in ipairs(lobby.SpawnedLogs or {}) do DeleteNetworkEntity(logNetId) end
    for craneIndex, crane in pairs(CranesData) do
        if crane.lobbyIndex == lobbyIndex then CranesData[craneIndex] = nil end
    end
    TriggerClientEvent("17mov_Lumberjack:RefreshCranes", -1, CranesData)

    for vehicleRole in pairs(ValidVehicleRoles) do
        local netId = lobby[vehicleRole]
        if vehicleRole == "JobFlatbed" and netId then
            AttachedObjectsData[netId] = nil
            TriggerClientEvent("17mov_Lumberjack:ClearThisFlatbed", -1, netId)
        end
        DeleteNetworkEntity(netId)
        lobby[vehicleRole] = nil
    end

    lobby.cash = 0
    lobby.SpawnedLogs = {}
    lobby.saleSession = nil
    lobby.processingOwner = nil
    lobby.processingType = nil
    lobby.forkliftLogs = {}
    lobby.pendingTrailerLogs = {}
    lobby.ending = nil

    if #lobby.clients == 0 then
        Lobbies[lobbyIndex] = nil
        TriggerClientEvent("17mov_lumberjack:clearMyLobby", playerId)
    end
end)

CreateThread(function()
    for index, coords in ipairs(Config.TreeSpawningCoords) do
        TreesData[index] = {
            coords = coords,
            isAvalible = true,
        }
    end
end)

RegisterNetEvent("17mov_lumberjack:logCarHidden")
AddEventHandler("17mov_lumberjack:logCarHidden", function()
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not IsNearCoords(source, Config.Locations.ReturnLogCar.Coords[1], 25.0) then return end
    local playerVehicle = GetVehiclePedIsIn(GetPlayerPed(source), false)
    if playerVehicle == 0 or GetPedInVehicleSeat(playerVehicle, -1) ~= GetPlayerPed(source) then return end
    local vehicleNetId = NetworkGetNetworkIdFromEntity(playerVehicle)
    if vehicleNetId ~= lobby.JobVehicle and vehicleNetId ~= lobby.JobVehicle2 then return end

    DeleteNetworkEntity(vehicleNetId)
    if lobby.JobVehicle == vehicleNetId then lobby.JobVehicle = nil end
    if lobby.JobVehicle2 == vehicleNetId then lobby.JobVehicle2 = nil end
    lobby.logCarHidden = true
    Notify(source, Config.Lang.logCarHidden)
end)

function GetCraneIndexFromLobbyIndex(lobbyIndex)
    for craneIndex, crane in pairs(CranesData) do
        if crane.lobbyIndex == lobbyIndex then
            return craneIndex
        end
    end
end

local function ClearProcessedLogCargo(lobbyIndex, lobby)
    if Config.EnableVehicleLegacyMode then
        local flatbedObjects = AttachedObjectsData[lobby.JobFlatbed] or {}
        for objectIndex = #flatbedObjects, 1, -1 do
            local object = flatbedObjects[objectIndex]
            if object.type == "logs" then
                TriggerClientEvent("17mov_Lumberjack:DeleteThisSlotObj", -1, object.slot, lobby.JobFlatbed, "logs")
                table.remove(flatbedObjects, objectIndex)
            end
        end
    else
        local craneIndex = GetCraneIndexFromLobbyIndex(lobbyIndex)
        local crane = craneIndex and CranesData[craneIndex]
        if crane and (crane.contentType == Config.Props.logs.hash or crane.contentType == 1366334172) then
            crane.contentQuantity = 0
            crane.contentType = nil
            crane.attachedProp = nil
            TriggerClientEvent("17mov_Lumberjack:UpdateCrane", -1, 0, craneIndex, crane)
        end
    end
    IncrementCargoRevision(lobby)
end

RegisterNetEvent("17mov_lumberjack:SpawnLocalPlanks")
AddEventHandler("17mov_lumberjack:SpawnLocalPlanks", function(planksSlot)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.processingOwner ~= playerId or lobby.processingType ~= "planks"
        or not IsIntegerInRange(planksSlot, 1, 9)
        or not (lobby.planksToSpawn and lobby.planksToSpawn > 0) then return end

    lobby.producedPlankSlots = lobby.producedPlankSlots or {}
    if lobby.producedPlankSlots[planksSlot] then return end
    lobby.producedPlankSlots[planksSlot] = true
    lobby.planksToSpawn = lobby.planksToSpawn - 1
    lobby.planksReadyToLoad = (lobby.planksReadyToLoad or 0) + 1

    if lobby.planksToSpawn <= 0 then
        lobby.planksToSpawn = nil
        lobby.plankCountCommitted = nil
        ClearProcessedLogCargo(lobbyIndex, lobby)
        lobby.processingOwner = nil
        lobby.processingType = nil
    end
    local craneIndex = GetCraneIndexFromLobbyIndex(lobbyIndex)
    if craneIndex and CranesData[craneIndex] then
        CranesData[craneIndex].planksToLoad = (CranesData[craneIndex].planksToLoad or 0) + 1
    end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:SpawnLocalPlanks", planksSlot)
end)

RegisterNetEvent("17mov_Lumberjack:ForkliftUpdate")
AddEventHandler("17mov_Lumberjack:ForkliftUpdate", function(forkliftData, forkliftNetId)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.JobForklift == nil
        or not IsIntegerInRange(forkliftData, 1, 2147483647)
        or not IsIntegerInRange(forkliftNetId, 1, 9)
        or not (lobby.producedPlankSlots and lobby.producedPlankSlots[forkliftNetId]) then return end
    lobby.producedPlankSlots[forkliftNetId] = nil
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:ForkliftUpdate", forkliftData, forkliftNetId)
end)

RegisterNetEvent("17mov_Lumberjack:AttachLogToLumberCar")
AddEventHandler("17mov_Lumberjack:AttachLogToLumberCar", function(forksSlot, vehicleNetId, isSecondVehicle, sourceLogNetId)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    local expectedVehicle = isSecondVehicle and lobby and lobby.JobVehicle2 or lobby and lobby.JobVehicle
    if lobby == nil or vehicleNetId ~= expectedVehicle or type(isSecondVehicle) ~= "boolean"
        or not IsIntegerInRange(forksSlot, 1, 2)
        or not IsIntegerInRange(sourceLogNetId, 1, 2147483647)
        or not DoesThisLogExistsInSpawnedLogs(playerId, sourceLogNetId) then return end

    lobby.forkliftLogs = lobby.forkliftLogs or {}
    lobby.forkliftLogs[vehicleNetId] = lobby.forkliftLogs[vehicleNetId] or {}
    if lobby.forkliftLogs[vehicleNetId][forksSlot] then return end

    lobby.forkliftLogs[vehicleNetId][forksSlot] = true
    RemoveLogFromParty(playerId, sourceLogNetId)
    DeleteNetworkEntity(sourceLogNetId)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:AttachLogToLumberCar", forksSlot, vehicleNetId, isSecondVehicle)
end)

RegisterNetEvent("17mov_Lumberjack:DetachObjFromLumber")
AddEventHandler("17mov_Lumberjack:DetachObjFromLumber", function(forksSlot, isSecondVehicle, vehicleNetId)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    local expectedVehicle = isSecondVehicle and lobby and lobby.JobVehicle2 or lobby and lobby.JobVehicle
    local loadedSlots = lobby and lobby.forkliftLogs and lobby.forkliftLogs[vehicleNetId]
    if lobby == nil or vehicleNetId ~= expectedVehicle or type(isSecondVehicle) ~= "boolean"
        or not IsIntegerInRange(forksSlot, 1, 2) or loadedSlots == nil or not loadedSlots[forksSlot] then return end

    loadedSlots[forksSlot] = nil
    lobby.pendingTrailerLogs = lobby.pendingTrailerLogs or {}
    lobby.pendingTrailerLogs[playerId] = (lobby.pendingTrailerLogs[playerId] or 0) + 1
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:DetachObjFromLumber", forksSlot, isSecondVehicle, vehicleNetId)
end)

RegisterNetEvent("17mov_Lumberjack:PlaySound")
AddEventHandler("17mov_Lumberjack:PlaySound", function(soundName, coords, loopFlag)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not AllowedSounds[soundName] or not IsSafeVector(coords)
        or not IsNearCoords(source, coords, 15.0) or (loopFlag ~= nil and type(loopFlag) ~= "boolean")
        or not AllowAction(source, "sound:" .. soundName, 250) then return end
    TriggerClientEvent("17mov_Lumberjack:PlaySound", -1, soundName, coords, loopFlag == true)
end)

RegisterNetEvent("17mov_lumberjack:StartFallAnim")
AddEventHandler("17mov_lumberjack:StartFallAnim", function(treeId, animType)
    local tree = TreesData[treeId]
    if tree == nil or tree.completedBy ~= source or not tree.awaitingFallBroadcast
        or not IsFiniteNumber(animType) or animType < -360.0 or animType > 360.0 then return end
    tree.awaitingFallBroadcast = nil
    TriggerClientEvent("17mov_lumberjack:StartFallAnim", -1, treeId, animType)
end)

RegisterNetEvent("17mov_Lumberjack:3dBoxState")
AddEventHandler("17mov_Lumberjack:3dBoxState", function(state)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or type(state) ~= "boolean" then return end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:3dBoxState", state)
end)

RegisterNetEvent("17mov_Lumberjack:AttachLog")
AddEventHandler("17mov_Lumberjack:AttachLog", function(slot, vehicleNetId, staleEntityNetId)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    local hasSpawnedLog = IsIntegerInRange(staleEntityNetId, 1, 2147483647)
        and DoesThisLogExistsInSpawnedLogs(playerId, staleEntityNetId)
    local pendingTrailerLogs = lobby and lobby.pendingTrailerLogs
    local hasForkliftLog = pendingTrailerLogs and (pendingTrailerLogs[playerId] or 0) > 0
    if lobby == nil or lobby.JobFlatbed ~= vehicleNetId or not IsIntegerInRange(slot, 1, 32)
        or FindAttachedObject(vehicleNetId, slot, "logs") ~= nil
        or (not hasSpawnedLog and not hasForkliftLog) then return end

    if hasSpawnedLog then
        RemoveLogFromParty(playerId, staleEntityNetId)
    else
        pendingTrailerLogs[playerId] = pendingTrailerLogs[playerId] - 1
    end

    if AttachedObjectsData[vehicleNetId] == nil then
        AttachedObjectsData[vehicleNetId] = {}
    end

    table.insert(AttachedObjectsData[vehicleNetId], {
        netid = vehicleNetId,
        slot = slot,
        type = "logs",
    })

    TriggerClientEvent("17mov_Lumberjack:AttachLog_CL", -1, vehicleNetId, slot)
    IncrementCargoRevision(lobby)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:SaveObject", vehicleNetId, slot)
    if hasSpawnedLog then DeleteNetworkEntity(staleEntityNetId) end
end)

RegisterNetEvent("17mov_Lumberjack:AttachPallete")
AddEventHandler("17mov_Lumberjack:AttachPallete", function(vehicleNetId, slot)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.JobFlatbed ~= vehicleNetId or not IsIntegerInRange(slot, 1, 9)
        or FindAttachedObject(vehicleNetId, slot, "planks") ~= nil
        or not (lobby.planksReadyToLoad and lobby.planksReadyToLoad > 0) then return end

    if AttachedObjectsData[vehicleNetId] == nil then
        AttachedObjectsData[vehicleNetId] = {}
    end

    table.insert(AttachedObjectsData[vehicleNetId], {
        netid = vehicleNetId,
        slot = slot,
        type = "planks",
    })

    lobby.planksReadyToLoad = lobby.planksReadyToLoad - 1
    IncrementCargoRevision(lobby)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:SavePlankObject", vehicleNetId, slot)
    TriggerClientEvent("17mov_Lumberjack:AttachPallete", -1, vehicleNetId, slot)
end)

RegisterNetEvent("17mov_Lumberjack:AttachSkipToTrailer")
AddEventHandler("17mov_Lumberjack:AttachSkipToTrailer", function(vehicleNetId, slot, offset)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or lobby.JobFlatbed ~= vehicleNetId or not IsIntegerInRange(slot, 1, 3)
        or not IsBoundedVector(offset, 20.0) or FindAttachedObject(vehicleNetId, slot, "skip") ~= nil
        or not (lobby.skipsStatus[slot] and lobby.skipsStatus[slot] > 0) then return end

    if AttachedObjectsData[vehicleNetId] == nil then
        AttachedObjectsData[vehicleNetId] = {}
    end

    table.insert(AttachedObjectsData[vehicleNetId], {
        netid = vehicleNetId,
        slot = slot,
        type = "skip",
        offset = offset,
    })

    IncrementCargoRevision(lobby)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:SaveSkipObject", vehicleNetId, slot)
    TriggerClientEvent("17mov_Lumberjack:AttachLocalSkip", -1, vehicleNetId, slot, offset)
end)

RegisterNetEvent("17mov_lumberjack:AddChipsToQueue")
AddEventHandler("17mov_lumberjack:AddChipsToQueue", function()
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.processingOwner ~= playerId or lobby.processingType ~= "chips"
        or not (lobby.pendingChipDeliveries and lobby.pendingChipDeliveries > 0) then return end
    lobby.pendingChipDeliveries = lobby.pendingChipDeliveries - 1
    lobby.allowedChipLifts = (lobby.allowedChipLifts or 0) + (Config.EnableVehicleLegacyMode and 5 or 6)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:AddChipsToQueue")
end)

RegisterNetEvent("17mov_Lumberjack:AttachSkip")
AddEventHandler("17mov_Lumberjack:AttachSkip", function(vehicleNetId, slot, offset, extra)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.processingType ~= "chips"
        or not IsIntegerInRange(vehicleNetId, 1, 3)
        or not IsIntegerInRange(slot, 1, 2147483647)
        or not IsIntegerInRange(offset, 1, 2147483647)
        or type(extra) ~= "boolean" then return end
    local skipEntity = NetworkGetEntityFromNetworkId(slot)
    local chipsEntity = NetworkGetEntityFromNetworkId(offset)
    if skipEntity == 0 or chipsEntity == 0
        or GetEntityModel(skipEntity) ~= -1937513394
        or GetEntityModel(chipsEntity) ~= -195941584 then return end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:AttachSkip", vehicleNetId, slot, offset, extra)
end)

RegisterNetEvent("17mov_Lumberjack:LiftChips")
AddEventHandler("17mov_Lumberjack:LiftChips", function(chipStationIndex)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.processingOwner ~= playerId or lobby.processingType ~= "chips"
        or not IsIntegerInRange(chipStationIndex, 1, 3)
        or not (lobby.allowedChipLifts and lobby.allowedChipLifts > 0)
        or not AllowAction(playerId, "liftChips", 350) then return end
    lobby.allowedChipLifts = lobby.allowedChipLifts - 1
    lobby.skipsStatus[chipStationIndex] = math.min(100, (lobby.skipsStatus[chipStationIndex] or 0) + 1)
end)

RegisterNetEvent("17mov_Lumberjack:ClearThisIDLog")
AddEventHandler("17mov_Lumberjack:ClearThisIDLog", function(entityId, vehicleNetId, slot)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or lobby.JobFlatbed ~= vehicleNetId or not IsIntegerInRange(slot, 1, 32) then return end
    local objectIndex = FindAttachedObject(vehicleNetId, slot, "logs")
    if objectIndex == nil then return end
    table.remove(AttachedObjectsData[vehicleNetId], objectIndex)
    if lobby.processingOwner == playerId and lobby.processingType == "chips" then
        lobby.pendingChipDeliveries = (lobby.pendingChipDeliveries or 0) + 1
    end
    TriggerClientEvent("17mov_Lumberjack:DeleteThisSlotObj", -1, slot, vehicleNetId, "logs")
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:ClearThisIDLog", entityId)
end)

RegisterNetEvent("17mov_lumberjack:StartPlanksProcessing")
AddEventHandler("17mov_lumberjack:StartPlanksProcessing", function()
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or not IsNearAnyStation(playerId, "processToPlanks", 30.0)
        or lobby.processingOwner ~= nil then return end
    local contentType, quantity = GetAuthoritativeCargo(lobbyIndex, lobby)
    if contentType ~= "logs" or quantity < (Config.EnableVehicleLegacyMode and 6 or 8) then return end
    lobby.processingOwner = playerId
    lobby.processingType = "planks"
    lobby.plankCountCommitted = false
    lobby.planksProcessed = true
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:PlanksProcessed")
end)

RegisterNetEvent("17mov_lumberjack:StartChipsProcessing")
AddEventHandler("17mov_lumberjack:StartChipsProcessing", function(chipStationIndex)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or type(chipStationIndex) ~= "boolean" then return end
    if chipStationIndex then
        if not IsNearAnyStation(playerId, "processToChips", 30.0) or lobby.processingOwner ~= nil then return end
        local contentType, quantity = GetAuthoritativeCargo(lobbyIndex, lobby)
        if contentType ~= "logs" or quantity < 1 then return end
        lobby.processingOwner = playerId
        lobby.processingType = "chips"
        lobby.pendingChipDeliveries = 0
        lobby.allowedChipLifts = 0
    elseif lobby.processingOwner ~= playerId or lobby.processingType ~= "chips" then
        return
    else
        local finishingOwner = playerId
        CreateThread(function()
            Wait(60000)
            if lobby.processingOwner == finishingOwner and lobby.processingType == "chips" then
                lobby.processingOwner = nil
                lobby.processingType = nil
                lobby.pendingChipDeliveries = 0
                lobby.allowedChipLifts = 0
            end
        end)
    end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:StartChipsProcessing", playerId, chipStationIndex)
end)

RegisterNetEvent("17mov_Lumberjack:DisableViaAboveSpawn")
AddEventHandler("17mov_Lumberjack:DisableViaAboveSpawn", function(spawnIndex)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not IsIntegerInRange(spawnIndex, 1, 9) then return end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:DisableViaAboveSpawn", spawnIndex)
end)

RegisterNetEvent("17mov_Lumberjack:EnableViaAboveLift")
AddEventHandler("17mov_Lumberjack:EnableViaAboveLift", function(liftIndex)
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not IsIntegerInRange(liftIndex, 1, 9) then return end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:EnableViaAboveLift", liftIndex)
end)

RegisterNetEvent("17mov_Lumberjack:disableThisTree")
AddEventHandler("17mov_Lumberjack:disableThisTree", function(treeId)
    if not IsIntegerInRange(treeId, 1, #TreesData) then return end
    CompleteReservedTree(source, treeId, nil, false)
end)

RegisterNetEvent("17mov_Lumberjack:ResetTractors")
AddEventHandler("17mov_Lumberjack:ResetTractors", function()
    local _, lobby = GetLobbyForPlayer(source, true)
    if lobby == nil or not AllowAction(source, "resetTractors", 2000) then return end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:ResetTractors")
end)

RegisterNetEvent("17mov_lumberjack:StartJob_sv")
AddEventHandler("17mov_lumberjack:StartJob_sv", function(withVehicle)
    local playerId = source
    if not AllowAction(playerId, "startJob", 2000)
        or not IsNearCoords(playerId, Config.Locations.DutyToggle.Coords[1], 20.0) then return end

    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, false)
    if lobby ~= nil and (lobby.host ~= playerId or lobby.working) then
        return Notify(playerId, Config.Lang.isBusy)
    end

    local clients = lobby and lobby.clients or {}
    if Config.RequireOneFriendMinimum and #clients < 1 then
        return Notify(playerId, Config.Lang.RequireOneFriend)
    end
    if Config.RequiredJob ~= "none" and GetPlayerJob(playerId) ~= Config.RequiredJob then
        return Notify(playerId, Config.Lang.notEverybodyHasRequiredJob)
    end
    if not IsHaveRequiredItem(playerId) then
        return Notify(playerId, Config.Lang.dontHaveReqItem)
    end

    for _, clientId in ipairs(clients) do
        if not IsValidPlayer(clientId) then return Notify(playerId, Config.Lang.error) end
        if Config.RequireJobAlsoForFriends and Config.RequiredJob ~= "none"
            and GetPlayerJob(clientId) ~= Config.RequiredJob then
            return Notify(playerId, Config.Lang.notEverybodyHasRequiredJob)
        end
        if Config.RequireItemFromWholeTeam and not IsHaveRequiredItem(clientId) then
            return Notify(playerId, Config.Lang.dontHaveReqItem)
        end
        if Config.RequiredAllPlayerClose.enabled
            and not IsNearCoords(clientId, GetEntityCoords(GetPlayerPed(playerId)), Config.RequiredAllPlayerClose.distance) then
            return Notify(playerId, Config.Lang.notAllPlayersClose)
        end
    end

    local members = { playerId }
    for _, clientId in ipairs(clients) do table.insert(members, clientId) end
    local now = os.time()
    CooldownsTime = CooldownsTime or {}
    if Config.JobCooldown > 0 then
        for _, memberId in ipairs(members) do
            local identifier = GetPlayerIdentifierByType(memberId, "license") or ("source:%s"):format(memberId)
            local cooldownStarted = CooldownsTime[identifier]
            if cooldownStarted and now - cooldownStarted < Config.JobCooldown then
                local remaining = Config.JobCooldown - (now - cooldownStarted)
                local hours = math.floor(remaining / 3600)
                local minutes = math.floor((remaining % 3600) / 60)
                local seconds = remaining % 60
                local timeString = (hours > 0 and (hours .. Config.Lang.hours .. " ") or "")
                    .. (minutes > 0 and (minutes .. Config.Lang.minutes .. " ") or "")
                    .. seconds .. Config.Lang.seconds
                return Notify(playerId, string.format(Config.Lang.someoneIsOnCooldown, GetPlayerIdentity(memberId), timeString))
            end
        end
    end

    if lobby == nil then
        lobbyIndex = NextFreeIndex(Lobbies)
        Lobbies[lobbyIndex] = { host = playerId, clients = {} }
        lobby = Lobbies[lobbyIndex]
    end

    lobby.logCarHidden = false
    lobby.JobTruck = nil
    lobby.JobForklift = nil
    lobby.working = true
    lobby.cash = 0
    lobby.planksProcessed = false
    lobby.plankItems = {}
    lobby.chipsItems = {}
    lobby.logsItems = {}
    lobby.SpawnedLogs = {}
    lobby.skipsStatus = { 0, 0, 0 }
    lobby.cargoRevision = 0
    lobby.lastSoldRevision = nil
    lobby.saleSession = nil
    lobby.processingOwner = nil
    lobby.processingType = nil
    lobby.plankCountCommitted = nil
    lobby.planksToSpawn = nil
    lobby.planksReadyToLoad = 0
    lobby.pendingChipDeliveries = 0
    lobby.allowedChipLifts = 0
    lobby.producedPlankSlots = {}
    lobby.forkliftLogs = {}
    lobby.pendingTrailerLogs = {}
    RecalculateRewards(playerId)

    if Config.JobCooldown > 0 then
        for _, memberId in ipairs(members) do
            local identifier = GetPlayerIdentifierByType(memberId, "license") or ("source:%s"):format(memberId)
            CooldownsTime[identifier] = now
        end
    end

    TriggerForAllMembers(playerId, "17mov_lumberjack:StartJob_cl", playerId, #lobby.clients + 1, lobby.clients[1], lobby.clients[2])
end)

function GetAllPartyMugs(hostId)
    local mugs = {}
    local clients = {}
    local lobbyIndex = 0

    for index, lobby in pairs(Lobbies) do
        if hostId == lobby.host then
            lobbyIndex = index
            clients = lobby.clients
        end
    end

    for i = 1, #clients, 1 do
        table.insert(mugs, {
            id = clients[i],
            name = GetPlayerIdentity(clients[i]),
            isHost = false,
            rewardPercent = Lobbies[lobbyIndex].rewardsOptions[clients[i]],
        })
    end

    table.insert(mugs, {
        id = hostId,
        name = GetPlayerIdentity(hostId),
        isHost = true,
        rewardPercent = Lobbies[lobbyIndex].rewardsOptions[hostId],
    })

    return mugs
end

function GetLobbyIndex(playerId)
    local lobbyIndex = 0

    for index, lobby in pairs(Lobbies) do
        if lobby.host == playerId then
            lobbyIndex = index
            break
        end

        for i = 1, #lobby.clients, 1 do
            if lobby.clients[i] == playerId then
                lobbyIndex = index
                break
            end
        end
    end

    return lobbyIndex
end

function TriggerForAllMembers(hostId, eventName, arg1, arg2, arg3, arg4)
    local clients = {}

    for index, lobby in pairs(Lobbies) do
        if hostId == lobby.host then
            clients = lobby.clients
        end
    end

    for i = 1, #clients + 1, 1 do
        local recipient = clients[i]
        if i > #clients then
            recipient = hostId
        end

        if recipient ~= nil then
            if type(recipient) == "number" then
                if eventName == "17mov_lumberjack:RefreshMugs" then
                    TriggerClientEvent(eventName, recipient, arg1, recipient, arg2, arg3)
                elseif eventName == "17mov_lumberjack:StartJob_cl" then
                    TriggerClientEvent(eventName, recipient, arg1, recipient, arg2, arg3, arg4)
                elseif eventName == "17mov_lumberjackJob:sendMixer_cl" then
                    TriggerClientEvent(eventName, recipient, arg1, recipient, hostId)
                else
                    TriggerClientEvent(eventName, recipient, arg1, arg2, arg3, arg4)
                end
            end
        end
    end
end

RegisterServerCallback("17mov_Lumberjack:GetAllPlayersClose", function(playerId, coords)
    if not Config.RequiredAllPlayerClose.enabled then
        return true
    end

    local _, lobby = GetLobbyForPlayer(playerId, false)
    if lobby == nil then return false end
    local clients = lobby.clients or {}
    local hostCoords = GetEntityCoords(GetPlayerPed(playerId))

    for _, clientId in pairs(clients) do
        if not IsNearCoords(clientId, hostCoords, Config.RequiredAllPlayerClose.distance) then
            return false
        end
    end

    return true
end)

RegisterNetEvent("17mov_Lumberjack:SetLogsStatebag")
AddEventHandler("17mov_Lumberjack:SetLogsStatebag", function(logs)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    local batch = PendingLogBatches[playerId]
    if lobby == nil or batch == nil or batch.expiresAt < GetGameTimer()
        or type(logs) ~= "table" or #logs ~= 3 then return end

    local validated = {}
    local seen = {}
    for i = 1, 3 do
        local netId = type(logs[i]) == "table" and logs[i].netId
        if not IsIntegerInRange(netId, 1, 2147483647) or seen[netId] then return end
        seen[netId] = true

        local entity = 0
        local deadline = GetGameTimer() + 2000
        repeat
            entity = NetworkGetEntityFromNetworkId(netId)
            if entity == 0 then Wait(50) end
        until entity ~= 0 or GetGameTimer() >= deadline

        if entity == 0 or not DoesEntityExist(entity)
            or (GetEntityModel(entity) ~= Config.Props.logs.hash and GetEntityModel(entity) ~= 1366334172)
            or not IsVectorNear(GetEntityCoords(entity), batch.coords, 25.0) then return end
        table.insert(validated, { netId = netId, entity = entity })
    end

    PendingLogBatches[playerId] = nil
    for _, logData in ipairs(validated) do
        Entity(logData.entity).state:set("17mov_Lumberjack:LogOwnedBy", lobby.host, true)
        table.insert(lobby.SpawnedLogs, logData.netId)
    end
end)

RegisterNetEvent("17mov_lumberjack:SendVehicleToClients")
AddEventHandler("17mov_lumberjack:SendVehicleToClients", function(vehicleKey, vehicleNetId)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or not ValidVehicleRoles[vehicleKey] or lobby[vehicleKey] ~= nil
        or not IsIntegerInRange(vehicleNetId, 1, 2147483647) then return end

    local expectedModels = {
        JobVehicle = Config.EnableVehicleLegacyMode and Config.LegacyJobVehicleModel or Config.JobVehicleModel,
        JobVehicle2 = Config.LegacyJobVehicleModel,
        JobFlatbed = Config.LegacyJobFlatbedModel,
        JobTruck = Config.JobTruckModel,
        JobForklift = Config.JobForkliftModel,
        JobPickup = Config.PickupModel,
    }
    local expectedSpawns = {
        JobVehicle = Config.SpawnPoint,
        JobVehicle2 = Config.SpawnPoint2,
        JobFlatbed = Config.SpawnPointFlatbed,
        JobTruck = Config.SpawnPointTruck,
        JobForklift = Config.SpawnPointForklift,
        JobPickup = Config.SpawnPointPickup,
    }
    if (vehicleKey == "JobVehicle2" or vehicleKey == "JobFlatbed") and not Config.EnableVehicleLegacyMode then return end

    local entity = 0
    local deadline = GetGameTimer() + 2000
    repeat
        entity = NetworkGetEntityFromNetworkId(vehicleNetId)
        if entity == 0 then Wait(50) end
    until entity ~= 0 or GetGameTimer() >= deadline
    if entity == 0 or not DoesEntityExist(entity)
        or GetEntityModel(entity) ~= GetHashKey(expectedModels[vehicleKey])
        or not IsVectorNear(GetEntityCoords(entity), expectedSpawns[vehicleKey], 40.0) then return end

    lobby[vehicleKey] = vehicleNetId
    TriggerForAllMembers(lobby.host, "17mov_lumberjack:SendVehicleToClients", vehicleKey, vehicleNetId)
end)

RegisterNetEvent("17mov_Lumberjack:TreeFallen")
AddEventHandler("17mov_Lumberjack:TreeFallen", function(fallenTrees)
    -- Retained as a compatibility contract. Tree entities are created by the
    -- validated client flow; accepting arbitrary hashes/coordinates here
    -- allowed any client to spawn networked objects on the server.
    return
end)

local function CleanupLobbyEntities(lobbyIndex, lobby)
    for _, logNetId in ipairs(lobby.SpawnedLogs or {}) do DeleteNetworkEntity(logNetId) end
    for vehicleRole in pairs(ValidVehicleRoles) do
        if vehicleRole == "JobFlatbed" and lobby[vehicleRole] then
            AttachedObjectsData[lobby[vehicleRole]] = nil
            TriggerClientEvent("17mov_Lumberjack:ClearThisFlatbed", -1, lobby[vehicleRole])
        end
        DeleteNetworkEntity(lobby[vehicleRole])
    end
    for craneIndex, crane in pairs(CranesData) do
        if crane.lobbyIndex == lobbyIndex then CranesData[craneIndex] = nil end
    end
    TriggerClientEvent("17mov_Lumberjack:RefreshCranes", -1, CranesData)
end

local function CleanupPlayerState(playerId)
    ActionTimestamps[playerId] = nil
    PendingLogBatches[playerId] = nil
    ClearPlayerIdentityCache(playerId)

    for _, tree in pairs(TreesData) do
        if tree.reservedBy == playerId then
            tree.reservedBy = nil
            tree.reservedUntil = nil
        end
    end
    for index = #PendingInvites, 1, -1 do
        local invite = PendingInvites[index]
        if invite.host == playerId or invite.client == playerId then table.remove(PendingInvites, index) end
    end

    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, false)
    if lobby == nil then return end

    if lobby.host == playerId then
        local newHostIndex
        for index, clientId in ipairs(lobby.clients) do
            if IsValidPlayer(clientId) then newHostIndex = index break end
        end
        if newHostIndex then
            lobby.host = table.remove(lobby.clients, newHostIndex)
            Notify(lobby.host, Config.Lang.newBoss)
        else
            CleanupLobbyEntities(lobbyIndex, lobby)
            Lobbies[lobbyIndex] = nil
            return
        end
    else
        for index, clientId in ipairs(lobby.clients) do
            if clientId == playerId then table.remove(lobby.clients, index) break end
        end
    end

    if lobby.processingOwner == playerId then
        lobby.processingOwner = nil
        lobby.processingType = nil
        lobby.pendingChipDeliveries = 0
        lobby.allowedChipLifts = 0
    end

    if not lobby.working and #lobby.clients == 0 then
        TriggerClientEvent("17mov_lumberjack:clearMyLobby", lobby.host)
        Lobbies[lobbyIndex] = nil
        return
    end

    RecalculateRewards(lobby.host)
    TriggerForAllMembers(lobby.host, "17mov_lumberjack:RefreshMugs", GetAllPartyMugs(lobby.host))
end

AddEventHandler("playerDropped", function()
    CleanupPlayerState(source)
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    for lobbyIndex, lobby in pairs(Lobbies) do
        CleanupLobbyEntities(lobbyIndex, lobby)
    end

    Lobbies = {}
    AttachedObjectsData = {}
    CranesData = {}
    PendingInvites = {}
    PendingLogBatches = {}
    ActionTimestamps = {}
    CraneActionListeners = {}
end)

RegisterNetEvent("17mov_Lumberjack:PlayerUnloaded", function()
    CleanupPlayerState(source)
end)

function IsAuthorizedToCrane(playerId, craneIndex)
    if IsIntegerInRange(craneIndex, 1, 2147483647) and CranesData[craneIndex] then
        local lobbyIndex = CranesData[craneIndex].lobbyIndex
        local lobby = Lobbies[lobbyIndex]
        if lobby == nil or not lobby.working then return false end

        if playerId == lobby.host then
            return true
        end

        for i = 1, #lobby.clients, 1 do
            if lobby.clients[i] == playerId then
                return true
            end
        end
    end

    return false
end

function GetPlayerPedNetId(playerId)
    local ped = GetPlayerPed(playerId)

    if DoesEntityExist(ped) then
        local netId = NetworkGetNetworkIdFromEntity(ped)
        local attempts = 0

        while netId == 0 or netId == ped do
            Citizen.Wait(100)
            attempts = attempts + 1
            netId = NetworkGetNetworkIdFromEntity(ped)

            if attempts == 3 then
                break
            end
        end

        if netId ~= nil and netId ~= 0 and netId ~= ped then
            return netId
        else
            return 0
        end
    end
end

RegisterNetEvent("17mov_Lumberjack:SpawnCrane")
AddEventHandler("17mov_Lumberjack:SpawnCrane", function(craneNetId)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or (craneNetId ~= lobby.JobVehicle and craneNetId ~= lobby.JobVehicle2) then return end
    for _, crane in pairs(CranesData) do
        if crane.netId == craneNetId or crane.lobbyIndex == lobbyIndex then return end
    end

    local players = {}
    local craneIndex = NextFreeIndex(CranesData)

    table.insert(players, GetPlayerPedNetId(lobby.host))

    for i = 1, #lobby.clients, 1 do
        table.insert(players, GetPlayerPedNetId(lobby.clients[i]))
    end

    CranesData[craneIndex] = {
        owner = playerId,
        players = players,
        netId = craneNetId,
        contentQuantity = 0,
        lobbyIndex = lobbyIndex,
    }

    TriggerClientEvent("17mov_Lumberjack:RefreshCranes", -1, CranesData)
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:RemoteCreated", craneIndex)
end)

RegisterNetEvent("17mov_Lumberjack:UpdateCrane")
AddEventHandler("17mov_Lumberjack:UpdateCrane", function(craneIndex, hasControl, baseRotation, hookRotation, stick1Rotation, stick3Offset, grabRotation, recipients)
    local playerId = source

    if IsAuthorizedToCrane(playerId, craneIndex)
        and (hasControl == nil or hasControl == GetPlayerPedNetId(playerId))
        and IsBoundedVector(baseRotation, 10000.0) and IsBoundedVector(hookRotation, 10000.0)
        and IsBoundedVector(stick1Rotation, 10000.0) and IsBoundedVector(stick3Offset, 10000.0)
        and IsBoundedVector(grabRotation, 10000.0)
        and type(recipients) == "table" and #recipients <= 32 then
        CranesData[craneIndex].hasControl = hasControl
        CranesData[craneIndex].baseRotation = baseRotation
        CranesData[craneIndex].hookRotation = hookRotation
        CranesData[craneIndex].stick1Rotation = stick1Rotation
        CranesData[craneIndex].stick3Offset = stick3Offset
        CranesData[craneIndex].grabRotation = grabRotation

        TriggerClientEvent("17mov_Lumberjack:UpdateCrane", -1, playerId, craneIndex, CranesData[craneIndex])
    end
end)

RegisterServerCallback("17mov_Lumberjack:RequestCraneControl", function(playerId, craneIndex, hasControl)
    if IsAuthorizedToCrane(playerId, craneIndex) and hasControl == GetPlayerPedNetId(playerId) then
        if CranesData[craneIndex] then
            if CranesData[craneIndex].hasControl == nil then
                CranesData[craneIndex].hasControl = hasControl
                TriggerClientEvent("17mov_Lumberjack:UpdateCrane", -1, playerId, craneIndex, CranesData[craneIndex])
                return true
            end
        end
    end

    return false
end)

RegisterNetEvent("17mov_Lumberjack:DeleteCrane")
AddEventHandler("17mov_Lumberjack:DeleteCrane", function(craneIndex)
    local playerId = source
    local lobbyIndex, lobby = GetLobbyForPlayer(playerId, true)

    if lobby and lobby.host == playerId and CranesData[craneIndex]
        and CranesData[craneIndex].lobbyIndex == lobbyIndex then
        CraneActionListeners[craneIndex] = nil
        CranesData[craneIndex] = nil
        TriggerClientEvent("17mov_Lumberjack:RefreshCranes", -1, CranesData)
    end
end)

RegisterNetEvent("17mov_Lumberjack:RequestCranes")
AddEventHandler("17mov_Lumberjack:RequestCranes", function()
    local playerId = source

    TriggerClientEvent("17mov_Lumberjack:RefreshCranes", playerId, CranesData)
end)

RegisterNetEvent("17mov_Lumberjack:RunCraneAction")
AddEventHandler("17mov_Lumberjack:RunCraneAction", function(craneIndex, actionName, ...)
    local playerId = source
    local allowedActions = { Fold = true, Unfold = true }

    if IsAuthorizedToCrane(playerId, craneIndex) and allowedActions[actionName]
        and select("#", ...) == 0 then
        TriggerClientEvent("17mov_Lumberjack:RunCraneAction", -1, playerId, craneIndex, actionName, ...)
    end
end)

RegisterNetEvent("17mov_Lumberjack:StartCraneAction")
AddEventHandler("17mov_Lumberjack:StartCraneAction", function(craneIndex, actionName, recipients, ...)
    local playerId = source
    local args = table.pack(...)
    local allowedActions = {
        Rotate = true,
        AdjustHeight = true,
        ControlStickLength = true,
        RotateHook = true,
        ControlHookGrip = true,
    }

    if IsAuthorizedToCrane(playerId, craneIndex) and allowedActions[actionName]
        and type(recipients) == "table" and #recipients <= 32
        and args.n == 1 and IsFiniteNumber(args[1]) and math.abs(args[1]) <= 10.0
        and AllowAction(playerId, "craneAction:" .. actionName, 50) then
        if CraneActionListeners[craneIndex] == nil then
            CraneActionListeners[craneIndex] = {}
        end

        CraneActionListeners[craneIndex][actionName] = true
        TriggerClientEvent("17mov_Lumberjack:StartCraneAction", -1, playerId, craneIndex, actionName, ...)
    end
end)

RegisterNetEvent("17mov_Lumberjack:StopCraneAction")
AddEventHandler("17mov_Lumberjack:StopCraneAction", function(craneIndex, actionName)
    local playerId = source

    if IsAuthorizedToCrane(playerId, craneIndex) then
        local listeners = CraneActionListeners[craneIndex]
        if listeners and listeners[actionName] then
            listeners[actionName] = nil
            TriggerClientEvent("17mov_Lumberjack:StopCraneAction", -1, playerId, craneIndex, actionName)
        end
    end
end)

function DoesThisLogExistsInSpawnedLogs(playerId, logNetId)
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil then return false end

    for i = 1, #lobby.SpawnedLogs, 1 do
        if lobby.SpawnedLogs[i] == logNetId then
            return true
        end
    end

    return false
end

function RemoveLogFromParty(playerId, logNetId)
    local lobbyIndex = GetLobbyIndex(playerId)

    if Lobbies[lobbyIndex] then
        if Lobbies[lobbyIndex].SpawnedLogs then
            for i = 1, #Lobbies[lobbyIndex].SpawnedLogs, 1 do
                if Lobbies[lobbyIndex].SpawnedLogs[i] == logNetId then
                    table.remove(Lobbies[lobbyIndex].SpawnedLogs, i)
                    break
                end
            end
        end
    end
end

RegisterServerCallback("17mov_Lumberjack:AttachPropToHook", function(playerId, craneIndex, propHash, chipsOffset, logNetId)
    local authorized = IsAuthorizedToCrane(playerId, craneIndex)
    local maxQuantityByHash = {
        [1366334172] = 32,
        [1597396577] = 4,
        [-1937513394] = 2,
    }

    if not authorized or maxQuantityByHash[propHash] == nil then return false end
    if propHash == -1937513394 and not IsBoundedVector(chipsOffset, 20.0) then return false end
    local isLogProp = Config.Props.logs.hash == propHash or propHash == 1366334172

    if isLogProp then
        if not (logNetId ~= 0 and DoesThisLogExistsInSpawnedLogs(playerId, logNetId)) then
            return false
        end
    end

    local canAttach = false
    local sameContentType = CranesData[craneIndex].contentType == nil or CranesData[craneIndex].contentType == propHash
    if sameContentType and CranesData[craneIndex].contentQuantity < maxQuantityByHash[propHash] then
        canAttach = true
    end

    if not canAttach then
        return false
    end

    if isLogProp and logNetId ~= 0 then
        RemoveLogFromParty(playerId, logNetId)
        local _, lobby = GetLobbyForPlayer(playerId, true)
        if lobby then TriggerForAllMembers(lobby.host, "17mov_Lumberjack:UpdateLogCounter") end
    end

    CranesData[craneIndex].attachedProp = propHash
    CranesData[craneIndex].chipsOffset = chipsOffset

    return true
end)

RegisterNetEvent("17mov_Lumberjack:DeleteEntity")
AddEventHandler("17mov_Lumberjack:DeleteEntity", function(entityArg1, entityArg2)
    local playerId = source
    local _, lobby = GetLobbyForPlayer(playerId, true)
    if lobby == nil or (entityArg1 ~= "skips" and entityArg1 ~= "planks")
        or not IsIntegerInRange(entityArg2, 1, 9) then return end
    TriggerForAllMembers(lobby.host, "17mov_Lumberjack:DeleteEntity", entityArg1, entityArg2)
end)

RegisterServerCallback("17mov_Lumberjack:AttachPropToTrailer", function(playerId, craneIndex, propHash, chipsDataEntry)
    local authorized = IsAuthorizedToCrane(playerId, craneIndex)
    local maxQuantityByHash = {
        [1366334172] = 32,
        [1597396577] = 4,
        [-1937513394] = 2,
    }

    if not authorized or maxQuantityByHash[propHash] == nil then return false end
    if chipsDataEntry ~= nil and not IsBoundedVector(chipsDataEntry, 20.0) then return false end
    local sameContentType = CranesData[craneIndex].contentType == nil or CranesData[craneIndex].contentType == propHash
    local canAttach = sameContentType and CranesData[craneIndex].attachedProp == propHash
        and CranesData[craneIndex].contentQuantity < maxQuantityByHash[propHash]

    if not canAttach then
        return false
    end

    if propHash == 1597396577 then
        if not (CranesData[craneIndex].planksToLoad and CranesData[craneIndex].planksToLoad > 0) then
            return false
        end

        CranesData[craneIndex].planksToLoad = CranesData[craneIndex].planksToLoad - 1

        if CranesData[craneIndex].planksToLoad <= 0 then
            CranesData[craneIndex].planksToLoad = nil
        end
    end

    if CranesData[craneIndex].chipsData == nil then
        CranesData[craneIndex].chipsData = {}
    end

    table.insert(CranesData[craneIndex].chipsData, chipsDataEntry)
    CranesData[craneIndex].contentType = propHash
    CranesData[craneIndex].contentQuantity = CranesData[craneIndex].contentQuantity + 1
    CranesData[craneIndex].attachedProp = nil
    local lobby = Lobbies[CranesData[craneIndex].lobbyIndex]
    if lobby then IncrementCargoRevision(lobby) end

    return true
end)

RegisterNetEvent("17mov_Lumberjack:DeleteTrailerProp")
AddEventHandler("17mov_Lumberjack:DeleteTrailerProp", function(craneIndex)
    local playerId = source

    if IsAuthorizedToCrane(playerId, craneIndex) and CranesData[craneIndex] then
        if CranesData[craneIndex].contentQuantity > 0 then
            local lobby = Lobbies[CranesData[craneIndex].lobbyIndex]
            if lobby and lobby.processingOwner == playerId and lobby.processingType == "chips"
                and (CranesData[craneIndex].contentType == Config.Props.logs.hash or CranesData[craneIndex].contentType == 1366334172) then
                lobby.pendingChipDeliveries = (lobby.pendingChipDeliveries or 0) + 1
            end
            CranesData[craneIndex].contentQuantity = CranesData[craneIndex].contentQuantity - 1

            if CranesData[craneIndex].contentQuantity < 1 then
                CranesData[craneIndex].contentType = nil
            end

            TriggerClientEvent("17mov_Lumberjack:UpdateCrane", -1, playerId, craneIndex, CranesData[craneIndex])
        end
    end
end)
