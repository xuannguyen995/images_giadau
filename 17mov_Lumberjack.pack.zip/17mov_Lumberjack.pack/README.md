# 17Movement Lumberjack

Version: 2.0.75

## Package contents

- `17mov_Lumberjack` — gameplay, configuration, integrations, and NUI
- `17mov_Lumberjack_assets` — required streamed maps, props, and vehicles

Both resources are required. Keep their folder names unchanged.

## Installation

1. Copy both resource folders into your FiveM server's resources directory.
2. Add the following lines to `server.cfg` in this order:

   ```cfg
   ensure 17mov_Lumberjack_assets
   ensure 17mov_Lumberjack
   ```

3. Review `17mov_Lumberjack/Config.lua` before starting the resource.
4. Restart the server or ensure both resources from the server console.

No SQL import is required. The default configuration is an open/public job because
`Config.RequiredJob` and `Config.RequiredItem` are both set to `"none"`.

## Framework support

- QBCore
- ESX
- Standalone/custom hooks
- Qbox/QBX through its `qb-core` compatibility bridge (no native `qbx_core` adapter)

Framework selection is automatic, with QBCore taking priority when both frameworks
are running. Standalone servers must configure their own payment/inventory behavior
in the provided server functions before using payouts.

## Optional integrations

Targets: `qb-target`, `qtarget`, or `ox_target`. Native markers are used when no
supported target resource is available.

Vehicle keys: `qs-vehiclekeys`, `0r-vehiclekeys`, `cd_garage`, `vehicles_keys`, or
`qb-vehiclekeys`.

Fuel: `LegacyFuel`, `cdn-fuel`, `ps-fuel`, or `lc_fuel`. The vehicle fuel state bag
is also initialized.

The chopping flow can use a custom global `ChainsawMinigame` function. When it is
not configured, the built-in timed chopping animation is used.

## Important configuration notes

- `Config.UseTarget` selects target interactions when a supported provider exists.
- `Config.RequiredJob` can restrict the activity to a framework job.
- `Config.RequiredItem` can require a server-defined inventory item.
- Modern vehicle mode is the default. Legacy tractor/trailer mode remains available.
- Item reward tables are empty by default; configure only item identifiers that exist
  on your server.
- Work clothing hooks may require configuration for the server's clothing resource.

## Validation

This buyer package was statically validated and regression tested before delivery:

- All Lua and JavaScript parsed successfully.
- All 23 XML/meta files parsed successfully.
- All manifest and NUI paths resolved.
- All 83 streamed binary assets passed RSC7 signature checks.
- Server regression tests: 24 passed, 0 failed, 3 not-applicable.
- NUI regression tests: 12 passed, 0 failed.
- Public contract SHA-256:
  `D1BA80FA6AADCDA52FE2056D5B2974FE22C21B272F620EE33F3A42A98E289ABE`

The three not-applicable tests cover axe inventory possession, axe durability, and
database failure; those subsystems are not part of this resource.

Always test third-party framework, target, key, fuel, clothing, and minigame adapters
on a staging server before moving the resource to production.
