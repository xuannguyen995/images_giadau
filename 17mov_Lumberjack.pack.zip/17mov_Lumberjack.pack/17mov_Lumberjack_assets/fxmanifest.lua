fx_version "cerulean"
game "gta5"
author "Malizniak - 17Movement"
this_is_a_map 'yes'
version "1.0.0"

files {
    'stream/**/**/handling.meta',
    'stream/**/**/vehicles.meta',
    'stream/**/**/carvariations.meta',
    'stream/**/**/vehiclelayouts.meta',
}

data_file 'DLC_ITYP_REQUEST' 'stream/17mov_chainsaw.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/17mov_woodpallet.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/17_movement_convo.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/17movement_hintskip.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/17move_crane.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/17mov_belts.ytyp'

data_file 'HANDLING_FILE'            'stream/**/**/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE'     'stream/**/**/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE'    'stream/**/**/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE'   'stream/**/**/carvariations.meta'
